// CPU-only wrapper around the uploaded and historically tested Ibex sources.
// Original CPU RTL is preserved byte for byte in the other files.
// Native Ibex instruction/data request interfaces; these ports are not AXI.
module ibex_cpu_only_ip #(
  parameter [31:0] BOOT_ADDR = 32'h00100000,
  parameter [31:0] HART_ID = 32'h00000000
) (
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 clk_i CLK",
     X_INTERFACE_PARAMETER = "XIL_INTERFACENAME clk_i, ASSOCIATED_RESET rst_ni" *)
  input logic clk_i,
  (* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 rst_ni RST",
     X_INTERFACE_PARAMETER = "XIL_INTERFACENAME rst_ni, POLARITY ACTIVE_LOW" *)
  input logic rst_ni,
  output logic instr_req_o,
  input logic instr_gnt_i,
  input logic instr_rvalid_i,
  output logic [31:0] instr_addr_o,
  input logic [31:0] instr_rdata_i,
  input logic instr_err_i,
  output logic data_req_o,
  input logic data_gnt_i,
  input logic data_rvalid_i,
  output logic data_we_o,
  output logic [3:0] data_be_o,
  output logic [31:0] data_addr_o,
  output logic [31:0] data_wdata_o,
  input logic [31:0] data_rdata_i,
  input logic data_err_i,
  input logic irq_software_i,
  input logic irq_timer_i,
  input logic irq_external_i,
  input logic [14:0] irq_fast_i,
  input logic irq_nm_i,
  input logic debug_req_i,
  output logic core_sleep_o
);
  ibex_top #(
    .SecureIbex(1'b0), .ICacheScramble(1'b0),
    .PMPEnable(1'b0), .PMPGranularity(0), .PMPNumRegions(4),
    .MHPMCounterNum(0), .MHPMCounterWidth(40),
    .RV32E(1'b0), .RV32M(ibex_pkg::RV32MFast),
    .RV32B(ibex_pkg::RV32BNone), .RegFile(ibex_pkg::RegFileFF),
    .BranchTargetALU(1'b0), .WritebackStage(1'b0),
    .ICache(1'b0), .ICacheECC(1'b0),
    .BranchPredictor(1'b0), .DbgTriggerEn(1'b0),
    .DmHaltAddr(32'h00100000), .DmExceptionAddr(32'h00100000)
  ) u_ibex (
    .clk_i(clk_i), .clk_i_fast(clk_i), .rst_ni(rst_ni),
    .test_en_i(1'b0), .scan_rst_ni(1'b1), .ram_cfg_i('0),
    .hart_id_i(HART_ID), .boot_addr_i(BOOT_ADDR),
    .instr_req_o(instr_req_o), .instr_gnt_i(instr_gnt_i),
    .instr_rvalid_i(instr_rvalid_i), .instr_addr_o(instr_addr_o),
    .instr_rdata_i(instr_rdata_i), .instr_rdata_intg_i(7'b0), .instr_err_i(instr_err_i),
    .data_req_o(data_req_o), .data_gnt_i(data_gnt_i),
    .data_rvalid_i(data_rvalid_i), .data_we_o(data_we_o),
    .data_be_o(data_be_o), .data_addr_o(data_addr_o),
    .data_wdata_o(data_wdata_o), .data_wdata_intg_o(),
    .data_rdata_i(data_rdata_i), .data_rdata_intg_i(7'b0), .data_err_i(data_err_i),
    .irq_software_i(irq_software_i), .irq_timer_i(irq_timer_i),
    .irq_external_i(irq_external_i), .irq_fast_i(irq_fast_i), .irq_nm_i(irq_nm_i),
    .scramble_key_valid_i(1'b0), .scramble_key_i('0), .scramble_nonce_i('0), .scramble_req_o(),
    .debug_req_i(debug_req_i), .crash_dump_o(), .double_fault_seen_o(),
    .fetch_enable_i(ibex_pkg::IbexMuBiOn),
    .alert_minor_o(), .alert_major_internal_o(), .alert_major_bus_o(),
    .core_sleep_o(core_sleep_o)
  );
endmodule
