# Vivado 2022.2.x. Run with no project open after saving the original project.
# Creates isolated projects; never opens or edits cpu_pure.xpr.
# Remove the previous revision's command, which shadowed Tcl's built-in package.
# This also repairs an existing Vivado session before any IP GUI is initialized.
if {[llength [info procs ::cpu_pure_bundle::package]]} {
    rename ::cpu_pure_bundle::package {}
}
namespace eval ::cpu_pure_bundle {
    variable root [file normalize [file dirname [info script]]]
    variable part xc7z020clg484-1
    variable vlnv soc.local:user:ibex_cpu_only_ip:1.0
}
source [file join $::cpu_pure_bundle::root rtl_files.tcl]

proc ::cpu_pure_bundle::read_text {path} {
    if {![file isfile $path]} { error "REQUIRED_FILE_MISSING=$path" }
    set f [open $path r]; set text [read $f]; close $f; return $text
}
proc ::cpu_pure_bundle::write_text {path text} {
    file mkdir [file dirname $path]
    set f [open $path w]; fconfigure $f -encoding utf-8
    puts -nonewline $f $text; close $f
}
proc ::cpu_pure_bundle::headers {dir} {
    return [lsort [glob -nocomplain -directory $dir *]]
}
proc ::cpu_pure_bundle::rtl_paths {dir {wrapper 0}} {
    variable rtl_names
    set result {}
    foreach n $rtl_names { lappend result [file join $dir $n] }
    if {$wrapper} { lappend result [file join $dir ibex_cpu_only_ip.sv] }
    foreach p $result { if {![file isfile $p]} { error "RTL_MISSING=$p" } }
    return $result
}
proc ::cpu_pure_bundle::add_headers {dir} {
    set paths [headers $dir]
    add_files -norecurse $paths
    foreach p $paths { set_property file_type {Verilog Header} [get_files $p] }
    set_property include_dirs [list $dir] [get_filesets sources_1]
}
proc ::cpu_pure_bundle::new_project {name directory} {
    variable part
    create_project $name $directory -part $part
    set_property target_simulator XSim [current_project]
    set_property simulator_language Mixed [current_project]
}
proc ::cpu_pure_bundle::setup_tests {mode generated} {
    variable root
    foreach test {cpu12 isa23} {
        if {$test eq "cpu12"} {
            set fw cpu_pure_12tc.vmem; set gold golden_outputs_12.hex
            set top tb_cpu_pure_12tc
        } else {
            set fw isa23.vmem; set gold isa_golden.hex; set top tb_cpu_only_isa_e2e
        }
        set template [read_text [file join $root verification tb ${test}_${mode}.sv.in]]
        set fwpath [file normalize [file join $root verification firmware $fw]]
        set goldpath [file normalize [file join $root verification firmware $gold]]
        set template [string map [list @FIRMWARE@ $fwpath @GOLDEN@ $goldpath] $template]
        set tbfile [file join $generated ${test}_${mode}.sv]
        write_text $tbfile $template
        set fs sim_$test
        create_fileset -simset $fs
        add_files -fileset $fs -norecurse $tbfile
        set_property file_type SystemVerilog [get_files $tbfile]
        set_property SOURCE_SET sources_1 [get_filesets $fs]
        set_property TOP $top [get_filesets $fs]
        set_property TOP_AUTO_SET 0 [get_filesets $fs]
        # Empty runtime loads the snapshot without an automatic initial run.
        set_property xsim.simulate.runtime {} [get_filesets $fs]
        set_property xsim.elaborate.debug_level all [get_filesets $fs]
        update_compile_order -fileset $fs
    }
}
proc ::cpu_pure_bundle::run_test {test mode evidence} {
    variable root
    set pname [get_property NAME [current_project]]
    set pdir [get_property DIRECTORY [current_project]]
    set simdir [file join $pdir ${pname}.sim sim_$test behav xsim]
    puts "\nRUNNING=$mode/$test"
    launch_simulation -simset sim_$test -mode behavioral
    # Log before run; the waveform belongs to this fresh simulation.
    log_wave -r /
    if {$test eq "cpu12"} { run 100 us } else { run 10 us }
    close_sim
    set log [read_text [file join $simdir simulate.log]]
    if {[regexp -nocase {(^|\n)\s*(fatal|error)\s*:|\$fatal|CPU_ISA_E2E_STATUS=FAIL} $log]} {
        error "SIMULATION_FAILED=$mode/$test; inspect $simdir/simulate.log"
    }
    if {$test eq "cpu12"} {
        set csvfile cpu_pure_12tc_actual.csv
        set rows [split [string trim [read_text [file join $simdir $csvfile]]] \n]
        if {[llength $rows] != 13} { error "CPU12_ROW_COUNT_FAILED" }
        set gold [split [string trim [read_text [file join $root verification firmware golden_outputs_12.hex]]] \n]
        set i 0
        foreach row [lrange $rows 1 end] {
            set cols [split [string trim $row] ,]
            if {[llength $cols] != 7 || [lindex $cols 6] ne "1" ||
                ![string equal -nocase [lindex $cols 2] [string trim [lindex $gold $i]]]} {
                error "CPU12_DATA_FAILED=$mode/index_$i"
            }
            incr i
        }
        foreach marker {"CPU_PURE_12TC_SUMMARY PASS=12/12" "CPU12_PHYSICAL_SRAM_PASS=12/12 INSTR_X=0"} {
            if {[string first $marker $log] < 0} { error "CPU12_PROOF_MISSING=$marker" }
        }
    } else {
        set csvfile CPU_ISA_E2E_RESULTS.csv
        set status [read_text [file join $simdir CPU_ISA_E2E_STATUS.txt]]
        foreach marker {ISA_BUS_GOLDEN=23/23 ISA_RAM_PORT_A=23/23 ISA_SRAM_GOLDEN=23/23 ISA_INSTR_X_ERRORS=0 ISA_ERROR_COUNT=0 CPU_ISA_E2E_STATUS=PASS} {
            if {[lsearch -exact [split [string map [list \r {}] $status] \n] $marker] < 0} {
                error "ISA23_PROOF_MISSING=$marker"
            }
        }
        set rows [split [string trim [read_text [file join $simdir $csvfile]]] \n]
        if {[llength $rows] != 24} { error "ISA23_ROW_COUNT_FAILED" }
        foreach row [lrange $rows 1 end] {
            set cols [split [string trim $row] ,]
            if {[llength $cols] != 12 || [lindex $cols 11] ne "PASS"} { error "ISA23_ROW_FAILED" }
        }
    }
    set dst [file join $evidence ${mode}_${test}]; file mkdir $dst
    foreach name [list $csvfile simulate.log compile.log elaborate.log CPU_ISA_E2E_STATUS.txt] {
        if {[file isfile [file join $simdir $name]]} { file copy [file join $simdir $name] $dst }
    }
    puts "TEST_PASS=$mode/$test"
}
proc ::cpu_pure_bundle::package_cpu_ip {work} {
    variable root
    set ipdir [file join $work ip_repo ibex_cpu_only_ip]
    set hdl [file join $ipdir hdl]; file mkdir $hdl
    foreach p [concat [rtl_paths [file join $root rtl] 1] [headers [file join $root include]]] {
        file copy $p $hdl
    }
    new_project cpu_pack [file join $work pack_project]
    add_files -norecurse [rtl_paths $hdl 1]
    set header_names {}
    foreach p [headers [file join $root include]] { lappend header_names [file join $hdl [file tail $p]] }
    add_files -norecurse $header_names
    foreach p $header_names { set_property file_type {Verilog Header} [get_files $p] }
    set_property include_dirs [list $hdl] [get_filesets sources_1]
    set_property top ibex_cpu_only_ip [get_filesets sources_1]
    update_compile_order -fileset sources_1
    # All referenced files already reside inside ipdir; keep metadata paths relative.
    ipx::package_project -root_dir $ipdir -vendor soc.local -library user -taxonomy /UserIP -set_current true
    set core [ipx::current_core]
    set_property name ibex_cpu_only_ip $core
    set_property display_name {Ibex CPU Only - tested cpu_pure sources} $core
    set_property description {RV32MFast CPU with native instruction/data interfaces; no Neural, system RAM, timer or bus.} $core
    set_property version 1.0 $core
    set_property core_revision 1 $core
    set_property supported_families {zynq Production} $core
    # Explicitly populate BOTH groups with the same source/header set.
    foreach group_name {xilinx_anylanguagesynthesis xilinx_anylanguagebehavioralsimulation} {
        if {[llength [ipx::get_file_groups $group_name -of_objects $core]]} {
            ipx::remove_file_group $group_name $core
        }
        set group [ipx::add_file_group $group_name $core]
        set_property model_name ibex_cpu_only_ip $group
        foreach p [rtl_paths $hdl 1] {
            set f [ipx::add_file hdl/[file tail $p] $group]
            set_property type systemVerilogSource $f
        }
        foreach p $header_names {
            set f [ipx::add_file hdl/[file tail $p] $group]
            set_property type systemVerilogSource $f
            set_property is_include true $f
        }
    }
    ipx::create_xgui_files $core
    ipx::update_checksums $core
    ipx::check_integrity $core
    ipx::save_core $core
    # Reject portable-package regressions before attempting catalog instantiation.
    set xml [read_text [file join $ipdir component.xml]]
    foreach name [regexp -all -inline {<[^>]*name>[^<]+</[^>]*name>} $xml] {
        if {[regexp {>[A-Za-z]:[/\\]|>/} $name]} { error "ABSOLUTE_IP_PATH=$name" }
    }
    close_project
    return [file dirname $ipdir]
}
proc ::cpu_pure_bundle::go {} {
    variable root; variable vlnv
    if {![llength [info commands create_project]]} { error "Run this script inside Vivado Tcl Console." }
    if {![catch {current_project -quiet} p] && $p ne ""} {
        error "Save and close the current project first. This script uses separate clean projects."
    }
    set work [file join $root work run_[clock format [clock seconds] -format %Y%m%d_%H%M%S]_[clock clicks]]
    file mkdir $work
    set ::CPU_ONLY_BUILD_DIR $work
    puts "CPU_ONLY_BUILD_DIR=$work"
    set evidence [file join $work evidence]
    new_project cpu_rtl [file join $work rtl_project]
    add_files -norecurse [rtl_paths [file join $root rtl]]
    add_headers [file join $root include]
    set syspaths {}
    foreach name {bus_neural.sv ram_2p.sv timer.sv ibex_simple_system_cpu_pure.sv} {
        lappend syspaths [file join $root verification original $name]
    }
    add_files -norecurse $syspaths
    set_property top ibex_simple_system_cpu_pure [get_filesets sources_1]
    update_compile_order -fileset sources_1
    setup_tests rtl [file join $work generated]
    foreach test {cpu12 isa23} { run_test $test rtl $evidence }
    close_project
    set repo [package_cpu_ip $work]
    new_project cpu_ip [file join $work ip_project]
    set_property ip_repo_paths [list $repo] [current_project]
    update_ip_catalog
    create_ip -vlnv $vlnv -module_name ibex_cpu_only_0
    generate_target all [get_ips ibex_cpu_only_0]
    # No loose CPU RTL is added here: the CPU must come through the generated IP.
    set syspaths {}
    foreach name {bus_neural.sv ram_2p.sv timer.sv} {
        lappend syspaths [file join $root verification original $name]
    }
    lappend syspaths [file join $root verification cpu_only_test_system.sv]
    add_files -norecurse $syspaths
    # ram_2p/timer/bus assertions include the same original header dependencies.
    add_headers [file join $root include]
    set_property top cpu_only_test_system [get_filesets sources_1]
    update_compile_order -fileset sources_1
    setup_tests ip [file join $work generated]
    foreach test {cpu12 isa23} { run_test $test ip $evidence }
    foreach pair {{cpu12 cpu_pure_12tc_actual.csv} {isa23 CPU_ISA_E2E_RESULTS.csv}} {
        lassign $pair test name
        set before [string trim [string map [list \r {}] [read_text [file join $evidence rtl_$test $name]]]]
        set after [string trim [string map [list \r {}] [read_text [file join $evidence ip_$test $name]]]]
        if {$before ne $after} { error "BEFORE_AFTER_MISMATCH=$test; compare result values and CPU cycle columns" }
    }
    write_text [file join $evidence PACKAGE_STATUS.txt] "RTL_CPU12=PASS\nRTL_ISA23=PASS\nIP_CPU12=PASS\nIP_ISA23=PASS\nIP_REPOSITORY=$repo\nCPU_ONLY_PACKAGE_AND_REGRESSION_PASS=1\n"
    puts "\nCPU_ONLY_PACKAGE_AND_REGRESSION_PASS=1"
    puts "IP_REPOSITORY=$repo"
    puts "RESULTS_DIR=$evidence"
    puts "Final IP test project remains open. These are fresh results from this invocation."
}
::cpu_pure_bundle::go
