"""Execute the uploaded RV32 firmware independently of RTL; no cycle claims.

This is an instruction-level check of the firmware, not an RTL simulator or
a substitute for the Vivado tests. Uses the Python standard library only.
"""
from pathlib import Path
from collections import Counter
import json

MASK = 0xffffffff
BASE = Path(__file__).resolve().parent

def sx(n, bits):
    return (n & ((1 << (bits-1))-1)) - (n & (1 << (bits-1)))

def execute(firmware, golden, result_base):
    words = [int(x, 16) for x in firmware.read_text().split()]
    expected = [int(x, 16) for x in golden.read_text().split()]
    mem = {}
    for i, word in enumerate(words):
        for j in range(4):
            mem[0x100000 + 4*i+j] = (word >> (8*j)) & 255
    def load(addr, size):
        return sum(mem[(addr+j)&MASK] << (8*j) for j in range(size))
    regs = [0]*32
    pc = 0x100080
    counts = Counter()
    outputs = []
    input_reads = 0
    for step in range(100000):
        insn = load(pc, 4)
        if insn & 3 != 3:
            raise ValueError(f'Compressed/invalid instruction at {pc:08x}')
        opcode = insn & 127
        rd, f3, a, b, f7 = (insn>>7)&31, (insn>>12)&7, (insn>>15)&31, (insn>>20)&31, insn>>25
        av, bv = regs[a], regs[b]
        npc = (pc + 4) & MASK
        val = None
        name = ''
        if opcode == 0x37:
            val=insn & 0xfffff000; name='LUI'
        elif opcode == 0x17:
            val=pc+(insn & 0xfffff000); name='AUIPC'
        elif opcode == 0x6f:
            imm=((insn>>31)<<20)|(((insn>>12)&255)<<12)|(((insn>>20)&1)<<11)|(((insn>>21)&1023)<<1)
            val=npc; npc=(pc+sx(imm,21))&MASK; name='JAL'
        elif opcode == 0x67:
            assert f3==0
            val=npc; npc=(av+sx(insn>>20,12))&0xfffffffe; name='JALR'
        elif opcode == 0x63:
            imm=((insn>>31)<<12)|(((insn>>7)&1)<<11)|(((insn>>25)&63)<<5)|(((insn>>8)&15)<<1)
            taken={0:av==bv,1:av!=bv,4:sx(av,32)<sx(bv,32),5:sx(av,32)>=sx(bv,32),6:av<bv,7:av>=bv}[f3]
            name={0:'BEQ',1:'BNE',4:'BLT',5:'BGE',6:'BLTU',7:'BGEU'}[f3]
            if taken: npc=(pc+sx(imm,13))&MASK
        elif opcode == 0x03:
            addr=(av+sx(insn>>20,12))&MASK
            size={0:1,1:2,2:4,4:1,5:2}[f3]
            val=load(addr,size)
            if f3<4: val=sx(val,size*8)
            if 0x1003b8 <= addr < 0x100448: input_reads+=1
            name={0:'LB',1:'LH',2:'LW',4:'LBU',5:'LHU'}[f3]
        elif opcode == 0x23:
            size={0:1,1:2,2:4}[f3]
            addr=(av+sx(((insn>>25)<<5)|((insn>>7)&31),12))&MASK
            for j in range(size): mem[(addr+j)&MASK]=(bv>>(8*j))&255
            name={0:'SB',1:'SH',2:'SW'}[f3]
            if result_base <= addr < result_base+4*len(expected):
                assert size==4 and addr==result_base+4*len(outputs), 'Unexpected result store'
                assert bv==expected[len(outputs)], f'Mismatch at {addr:08x}: {bv:08x}'
                outputs.append(bv)
        elif opcode == 0x13:
            imm=sx(insn>>20,12)
            if f3==0:val=av+imm;name='ADDI'
            elif f3==1:assert f7==0;val=av<<b;name='SLLI'
            elif f3==2:val=int(sx(av,32)<imm);name='SLTI'
            elif f3==3:val=int(av<(imm&MASK));name='SLTIU'
            elif f3==4:val=av^(imm&MASK);name='XORI'
            elif f3==5:
                assert f7 in (0,32)
                val=(sx(av,32) if f7 else av)>>b;name='SRAI' if f7 else 'SRLI'
            elif f3==6:val=av|(imm&MASK);name='ORI'
            elif f3==7:val=av&(imm&MASK);name='ANDI'
        elif opcode == 0x33:
            if f7==1:
                # The supplied CPU12 firmware uses MUL, not DIV/REM.
                if f3==0: val=av*bv;name='MUL'
                elif f3==1:val=(sx(av,32)*sx(bv,32))>>32;name='MULH'
                elif f3==2:val=(sx(av,32)*bv)>>32;name='MULHSU'
                elif f3==3:val=(av*bv)>>32;name='MULHU'
                else:raise ValueError('DIV/REM not needed by these firmware checks')
            elif f3==0:
                assert f7 in (0,32)
                val=av-bv if f7 else av+bv;name='SUB' if f7 else 'ADD'
            elif f3==1:assert f7==0;val=av<<(bv&31);name='SLL'
            elif f3==2:assert f7==0;val=int(sx(av,32)<sx(bv,32));name='SLT'
            elif f3==3:assert f7==0;val=int(av<bv);name='SLTU'
            elif f3==4:assert f7==0;val=av^bv;name='XOR'
            elif f3==5:
                assert f7 in (0,32)
                val=(sx(av,32) if f7 else av)>>(bv&31);name='SRA' if f7 else 'SRL'
            elif f3==6:assert f7==0;val=av|bv;name='OR'
            elif f3==7:assert f7==0;val=av&bv;name='AND'
        else:
            raise ValueError(f'Unsupported opcode {opcode:02x} at {pc:08x}')
        if val is not None and rd: regs[rd]=val&MASK
        regs[0]=0
        counts[name]+=1
        pc=npc
        if len(outputs)==len(expected):
            return dict(status='PASS', matched=len(outputs), executed_instructions=step+1,
                        instruction_counts=dict(sorted(counts.items())), stimulus_word_reads=input_reads,
                        outputs=[f'{x:08x}' for x in outputs])
    raise RuntimeError('Firmware execution timed out')

if __name__=='__main__':
    fw=BASE/'firmware'
    report={
        'scope':'Instruction-level firmware check only; not RTL verification or cycle measurement',
        'cpu12':execute(fw/'cpu_pure_12tc.vmem',fw/'golden_outputs_12.hex',0x103f00),
        'isa23':execute(fw/'isa23.vmem',fw/'isa_golden.hex',0x103e00),
    }
    print(json.dumps(report,indent=2))
