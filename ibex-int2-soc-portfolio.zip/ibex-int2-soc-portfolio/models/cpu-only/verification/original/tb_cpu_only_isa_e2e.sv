`timescale 1ns/1ps
module tb_cpu_only_isa_e2e;
  localparam integer N = 23;
  localparam [31:0] BASE = 32'h00103E00;
  reg clk = 1'b0;
  reg rst_n = 1'b0;
  always #10 clk = ~clk;  // 50 MHz, 20 ns/clock

  wire [31:0] debug_pc, debug_cpu_addr, debug_cpu_wdata, debug_neural_rdata;
  wire debug_instr_req, debug_neural_rvalid;
  ibex_simple_system_cpu_pure #(
    .SRAMInitFile("C:/Users/admin/final_soc_compat/DEMO/01_CPU_ONLY/CPU_ONLY_ISA_23TC/runs/20261101_181239_0/firmware.vmem")
  ) dut (
    .IO_CLK(clk), .IO_CLK_FAST(clk), .IO_RST_N(rst_n),
    .DEBUG_PC(debug_pc), .DEBUG_INSTR_REQ(debug_instr_req),
    .DEBUG_CPU_ADDR(debug_cpu_addr), .DEBUG_CPU_WDATA(debug_cpu_wdata),
    .DEBUG_NEURAL_RDATA(debug_neural_rdata), .DEBUG_NEURAL_RVALID(debug_neural_rvalid)
  );

  reg [31:0] golden [0:N-1];
  reg [31:0] bus_data [0:N-1];
  reg [31:0] port_data [0:N-1];
  reg [31:0] mem_data [0:N-1];
  integer write_cycle [0:N-1];
  reg bus_match [0:N-1];
  reg port_match [0:N-1];
  reg ram_match [0:N-1];
  reg [N-1:0] seen = {N{1'b0}};

  integer cycles=0, first_fetch=-1, last_write=-1;
  integer bus_pass=0, port_pass=0, sram_pass=0, errors=0, instr_x=0;
  integer fd=0, evfd=0, statusfd=0;
  integer i, idx, ram_cycle;
  reg [31:0] addr, data;
  reg is_bus_ok, is_port_ok;

  function automatic string isa_name(input integer n);
    begin
      case (n)
          0: isa_name = "AND";
          1: isa_name = "OR";
          2: isa_name = "XOR";
          3: isa_name = "NOT_XORI";
          4: isa_name = "ADD";
          5: isa_name = "SUB";
          6: isa_name = "SLL";
          7: isa_name = "SRL";
          8: isa_name = "SRA";
          9: isa_name = "SLT";
          10: isa_name = "SLTU";
          11: isa_name = "ANDI";
          12: isa_name = "ORI";
          13: isa_name = "XORI";
          14: isa_name = "SLLI";
          15: isa_name = "SRLI";
          16: isa_name = "SRAI";
          17: isa_name = "BEQ_TAKEN";
          18: isa_name = "BNE_TAKEN";
          19: isa_name = "SW_LW";
          20: isa_name = "LUI";
          21: isa_name = "JAL";
          22: isa_name = "SRA_NEG";
        default: isa_name = "UNKNOWN";
      endcase
    end
  endfunction

  initial begin
    $readmemh("C:/Users/admin/final_soc_compat/DEMO/01_CPU_ONLY/CPU_ONLY_ISA_23TC/runs/20261101_181239_0/golden.hex", golden);
    fd = $fopen("CPU_ISA_E2E_RESULTS.csv", "w");
    evfd = $fopen("CPU_ISA_E2E_EVENTS.csv", "w");
    if (fd == 0 || evfd == 0) $fatal(1, "ISA_E2E cannot open CSV outputs");
    $fdisplay(fd, "INDEX,INSTRUCTION,SRAM_ADDRESS,CPU_BUS,SRAM_PORT_A,SRAM_MEMORY,GOLDEN,CPU_CYCLE,BUS_MATCH,PORT_A_MATCH,SRAM_MATCH,STATUS");
    $fdisplay(evfd, "REGION,INDEX,INSTRUCTION,CYCLE,ADDRESS,VALUE,GOLDEN,STATUS");
    $display("CPU_ISA_E2E_START firmware=FIXED_TC23_UNCHANGED golden=ORIGINAL SRAM=PHYSICAL_MEM_ARRAY clock=50MHz");
    repeat (10) @(negedge clk);
    rst_n = 1'b1;
  end

  // All transaction sampling uses the same posedge convention as the ISA testbench
  // which previously passed 23/23. No force/deposit and no writes to DUT memory.
  always @(posedge clk) begin
    if (rst_n) begin
      cycles = cycles + 1;
      if (first_fetch < 0 && debug_instr_req === 1'b1) first_fetch = cycles;
      if (dut.instr_rvalid === 1'b1 &&
          $isunknown(dut.instr_rdata)) begin
        instr_x = instr_x + 1;
        errors = errors + 1;
        $error("CPU_ISA_E2E_INSTR_X cycle=%0d pc=%08h", cycles, debug_pc);
      end

      if (dut.device_req[0] === 1'b1 &&
          dut.device_gnt[0] === 1'b1 &&
          dut.device_we[0] === 1'b1 &&
          dut.device_addr[0] >= BASE &&
          dut.device_addr[0] < BASE+4*N) begin
        addr = dut.device_addr[0];
        idx = (addr-BASE)>>2;
        data = dut.device_wdata[0];
        last_write = cycles;

        if (addr !== BASE+4*idx || seen[idx]) begin
          errors = errors+1;
          $error("CPU_ISA_E2E_DUPLICATE_OR_MISALIGNED index=%0d address=%08h",idx+1,addr);
        end
        seen[idx] = 1'b1;
        bus_data[idx] = data;
        port_data[idx] = dut.u_ram.a_wdata_i;
        write_cycle[idx] = cycles;

        is_bus_ok = (data === golden[idx]);
        // Verify actual physical SRAM Port A inputs, not only bus outputs.
        is_port_ok = (dut.u_ram.a_req_i === 1'b1 &&
                      dut.u_ram.a_we_i === 1'b1 &&
                      dut.u_ram.a_be_i === 4'hf &&
                      dut.u_ram.a_wdata_i === data &&
                      dut.u_ram.a_addr_i[13:2] === addr[13:2]);
        bus_match[idx] = is_bus_ok;
        port_match[idx] = is_port_ok;
        if (is_bus_ok) bus_pass=bus_pass+1;
        else begin
          errors=errors+1;
          $error("CPU_ISA_E2E_BUS_FAIL %s index=%0d actual=%08h golden=%08h",isa_name(idx),idx+1,data,golden[idx]);
        end
        if (is_port_ok) port_pass=port_pass+1;
        else begin
          errors=errors+1;
          $error("CPU_ISA_E2E_PORT_A_FAIL %s index=%0d bus=%08h port=%08h",isa_name(idx),idx+1,data,port_data[idx]);
        end
        $display("CPU_ISA_E2E_WRITE %-12s idx=%0d addr=%08h bus=%08h port_a=%08h golden=%08h cycle=%0d",isa_name(idx),idx+1,addr,data,port_data[idx],golden[idx],cycles);
        $fdisplay(evfd,"CPU_BUS,%0d,%s,%0d,%08h,%08h,%08h,%s",idx+1,isa_name(idx),cycles,addr,data,golden[idx],is_bus_ok?"MATCH":"FAIL");
        $fdisplay(evfd,"SRAM_PORT_A,%0d,%s,%0d,%08h,%08h,%08h,%s",idx+1,isa_name(idx),cycles,addr,port_data[idx],golden[idx],is_port_ok?"MATCH":"FAIL");
      end
      if (cycles > 10000) $fatal(1,"CPU_ISA_E2E_TIMEOUT seen=%h, writes=%0d",seen,bus_pass);
    end
  end

  initial begin
    wait (&seen);
    // Give synchronous SRAM write nonblocking assignments time to commit.
    @(negedge clk);
    #1;
    ram_cycle = cycles; // inspection checkpoint, NOT each word's write cycle
    for (i=0; i<N; i=i+1) begin
      // 0x00103E00 starts at memory index 3968 (0xF80) for a 4096-word SRAM.
      mem_data[i] = dut.u_ram.u_ram.mem[((BASE>>2)+i)&12'hfff];
      ram_match[i] = (mem_data[i] === golden[i]);
      if (ram_match[i]) sram_pass=sram_pass+1;
      else begin
        errors=errors+1;
        $error("CPU_ISA_E2E_SRAM_FAIL %s index=%0d addr=%08h stored=%08h golden=%08h",isa_name(i),i+1,BASE+4*i,mem_data[i],golden[i]);
      end
      $display("CPU_ISA_E2E_SRAM %-12s idx=%0d addr=%08h stored=%08h golden=%08h %s",isa_name(i),i+1,BASE+4*i,mem_data[i],golden[i],ram_match[i]?"MATCH":"FAIL");
      $fdisplay(evfd,"SRAM_MEMORY,%0d,%s,%0d,%08h,%08h,%08h,%s",i+1,isa_name(i),ram_cycle,BASE+4*i,mem_data[i],golden[i],ram_match[i]?"MATCH":"FAIL");
      $fdisplay(fd,"%0d,%s,%08h,%08h,%08h,%08h,%08h,%0d,%s,%s,%s,%s",i+1,isa_name(i),BASE+4*i,bus_data[i],port_data[i],mem_data[i],golden[i],write_cycle[i],bus_match[i]?"PASS":"FAIL",port_match[i]?"PASS":"FAIL",ram_match[i]?"PASS":"FAIL",(bus_match[i] && port_match[i] && ram_match[i])?"PASS":"FAIL");
    end
    statusfd = $fopen("CPU_ISA_E2E_STATUS.txt","w");
    if (statusfd == 0) $fatal(1,"ISA_E2E status file open failed");
    $fdisplay(statusfd,"ISA_CASES=%0d",N);
    $fdisplay(statusfd,"ISA_BUS_GOLDEN=%0d/%0d",bus_pass,N);
    $fdisplay(statusfd,"ISA_RAM_PORT_A=%0d/%0d",port_pass,N);
    $fdisplay(statusfd,"ISA_SRAM_GOLDEN=%0d/%0d",sram_pass,N);
    $fdisplay(statusfd,"ISA_INSTR_X_ERRORS=%0d",instr_x);
    $fdisplay(statusfd,"ISA_ERROR_COUNT=%0d",errors);
    $fdisplay(statusfd,"ISA_FIRST_FETCH_CYCLE=%0d",first_fetch);
    $fdisplay(statusfd,"ISA_LAST_SRAM_WRITE_CYCLE=%0d",last_write);
    $fdisplay(statusfd,"ISA_TOTAL_CYCLES=%0d",(first_fetch>0)?last_write-first_fetch+1:-1);
    $display("CPU_ISA_E2E_SUMMARY BUS=%0d/%0d PORT_A=%0d/%0d SRAM=%0d/%0d INSTR_X=%0d ERRORS=%0d",bus_pass,N,port_pass,N,sram_pass,N,instr_x,errors);
    if (bus_pass==N && port_pass==N && sram_pass==N && errors==0 && instr_x==0 && first_fetch>0) begin
      $fdisplay(statusfd,"CPU_ISA_E2E_STATUS=PASS");
      $display("CPU_ISA_E2E_STATUS=PASS");
    end else begin
      $fdisplay(statusfd,"CPU_ISA_E2E_STATUS=FAIL");
      $display("CPU_ISA_E2E_STATUS=FAIL");
    end
    $fclose(statusfd);
    $fclose(fd);
    $fclose(evfd);
    #1;
    $finish;
  end
endmodule
