
`timescale 1ns/1ps
module cpu12_fresh_independent_probe (
    input logic clk, rst_n,
    input logic cpu_req, cpu_gnt, cpu_we,
    input logic [3:0] cpu_be,
    input logic [31:0] cpu_addr, cpu_wdata,
    input logic ram_req, ram_we,
    input logic [3:0] ram_be,
    input logic [31:0] ram_addr, ram_wdata,
    input logic [31:0] id_pc, id_instr,
    input logic id_valid, id_lsu_req, id_lsu_we,
    input logic lsu_req, lsu_gnt, lsu_we,
    input logic [31:0] lsu_addr, lsu_wdata
);
    integer fd;
    integer cycles;
    integer count;
    logic [11:0] seen;
    integer ix;
    integer wi;
    logic [31:0] sampled_addr, sampled_bus;
    logic [31:0] sampled_ram_addr, sampled_ram_wdata;
    logic [31:0] sampled_id_pc, sampled_id_instr;
    logic [31:0] sampled_lsu_addr, sampled_lsu_wdata;
    logic [31:0] readback;
    logic sampled_ram_req, sampled_ram_we;
    logic [3:0] sampled_ram_be;
    logic [3:0] sampled_cpu_be;
    logic sampled_id_valid, sampled_id_lsu_req, sampled_id_lsu_we;
    logic sampled_lsu_req, sampled_lsu_gnt, sampled_lsu_we;
    logic pc_same_edge_match;
    integer sampled_cycle;

    initial begin
        fd = $fopen("C:/Users/admin/Downloads/CPU12_FRESH_20261102_234447_1912/cpu12_live_raw.csv", "w");
        if (fd == 0) $fatal(1, "FRESH_CPU12_MONITOR: failed to create new raw CSV");
        $fdisplay(fd,"INDEX,CPU_ADDR,CPU_WDATA,CPU_BE,RAM_ADDR,RAM_WDATA,RAM_REQ,RAM_WE,RAM_BE,READBACK,ID_PC,ID_INSTR,PC_MATCH,ID_VALID,ID_LSU_REQ,ID_LSU_WE,LSU_REQ,LSU_GNT,LSU_WE,LSU_ADDR,LSU_WDATA,CYCLE,TIME_NS");
        cycles=0;
        count=0;
        seen=12'b0;
    end
    always @(posedge clk) begin
        if (!rst_n) begin
            cycles = 0;
            seen = 12'b0;
        end else begin
            cycles = cycles + 1;
            if (cpu_req === 1'b1 && cpu_gnt === 1'b1 && cpu_we === 1'b1 &&
                cpu_addr >= 32'h00103F00 && cpu_addr <= 32'h00103F2C &&
                cpu_addr[1:0] === 2'b00) begin
                ix = (cpu_addr - 32'h00103F00) >> 2;
                if (!seen[ix]) begin
                    seen[ix]=1'b1;
                    count=count+1;
                    wi=4032+ix;  // (0x00103F00-0x00100000)/4 + ix
                    sampled_addr=cpu_addr;
                    sampled_bus=cpu_wdata;
                    sampled_cpu_be=cpu_be;
                    sampled_ram_addr=ram_addr;
                    sampled_ram_wdata=ram_wdata;
                    sampled_ram_req=ram_req;
                    sampled_ram_we=ram_we;
                    sampled_ram_be=ram_be;
                    sampled_id_pc=id_pc;
                    sampled_id_instr=id_instr;
                    sampled_id_valid=id_valid;
                    sampled_id_lsu_req=id_lsu_req;
                    sampled_id_lsu_we=id_lsu_we;
                    sampled_lsu_req=lsu_req;
                    sampled_lsu_gnt=lsu_gnt;
                    sampled_lsu_we=lsu_we;
                    sampled_lsu_addr=lsu_addr;
                    sampled_lsu_wdata=lsu_wdata;
                    sampled_cycle=cycles;
                    // PC is linked only under a live SAME-EDGE ID/LSU/bus match.
                    pc_same_edge_match =
                        (sampled_id_valid === 1'b1) &&
                        (sampled_id_lsu_req === 1'b1) &&
                        (sampled_id_lsu_we === 1'b1) &&
                        (sampled_id_instr[6:0] === 7'h23) &&
                        (sampled_lsu_req === 1'b1) &&
                        (sampled_lsu_gnt === 1'b1) &&
                        (sampled_lsu_we === 1'b1) &&
                        (sampled_lsu_addr === sampled_addr) &&
                        (sampled_lsu_wdata === sampled_bus) &&
                        ((^sampled_id_pc) !== 1'bx);
                    // 10ps after rising edge: read real SRAM array after NBA update.
                    #0.01;
                    readback=$root.tb_cpu_pure_12tc.dut.u_ram.u_ram.mem[wi];
                    $fdisplay(fd,"%0d,%08h,%08h,%01h,%08h,%08h,%0d,%0d,%01h,%08h,%08h,%08h,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%08h,%08h,%0d,%0.3f",
                        ix,sampled_addr,sampled_bus,sampled_cpu_be,sampled_ram_addr,
                        sampled_ram_wdata,sampled_ram_req,sampled_ram_we,sampled_ram_be,
                        readback,sampled_id_pc,sampled_id_instr,pc_same_edge_match,
                        sampled_id_valid,sampled_id_lsu_req,sampled_id_lsu_we,
                        sampled_lsu_req,sampled_lsu_gnt,sampled_lsu_we,
                        sampled_lsu_addr,sampled_lsu_wdata,sampled_cycle,$realtime);
                    $fflush(fd);
                    $display("FRESH_STORE index=%0d addr=%08h bus=%08h ram=%08h mem=%08h pc=%08h pc_link=%0d cycle=%0d",
                        ix,sampled_addr,sampled_bus,sampled_ram_wdata,readback,
                        sampled_id_pc,pc_same_edge_match,sampled_cycle);
                end
            end
        end
    end
    final begin
        $display("FRESH_MONITOR_FINAL captured=%0d/12 mask=%03h",count,seen);
        if (fd != 0) $fclose(fd);
    end
endmodule

bind ibex_simple_system_cpu_pure cpu12_fresh_independent_probe u_cpu12_fresh_independent_probe (
    .clk(IO_CLK), .rst_n(IO_RST_N),
    .cpu_req(device_req[0]), .cpu_gnt(device_gnt[0]),
    .cpu_we(device_we[0]), .cpu_be(device_be[0]),
    .cpu_addr(device_addr[0]), .cpu_wdata(device_wdata[0]),
    .ram_req(u_ram.a_req_i), .ram_we(u_ram.a_we_i),
    .ram_be(u_ram.a_be_i), .ram_addr(u_ram.a_addr_i),
    .ram_wdata(u_ram.a_wdata_i),
    .id_pc(u_top.u_ibex_core.id_stage_i.pc_id_i),
    .id_instr(u_top.u_ibex_core.id_stage_i.instr_rdata_i),
    .id_valid(u_top.u_ibex_core.id_stage_i.instr_valid_i),
    .id_lsu_req(u_top.u_ibex_core.id_stage_i.lsu_req_o),
    .id_lsu_we(u_top.u_ibex_core.id_stage_i.lsu_we_o),
    .lsu_req(u_top.u_ibex_core.load_store_unit_i.data_req_o),
    .lsu_gnt(u_top.u_ibex_core.load_store_unit_i.data_gnt_i),
    .lsu_we(u_top.u_ibex_core.load_store_unit_i.data_we_o),
    .lsu_addr(u_top.u_ibex_core.load_store_unit_i.data_addr_o),
    .lsu_wdata(u_top.u_ibex_core.load_store_unit_i.data_wdata_o)
);
