`timescale 1ns/1ps
/*
 * CPU PURE 12TC, observation-only; no force, no expected-value injection.
 * Testbench compares genuine CPU SRAM writes against independent golden list.
 * C:/Users/admin/Downloads/CPU_PURE_12TC_BUILD/firmware/cpu_pure_12tc.vmem is substituted by Vivado Tcl at runtime.
 */
module tb_cpu_pure_12tc;
    logic clk = 1'b0;
    logic rst_n = 1'b0;
    always #10 clk = ~clk;  // 50MHz, same as Full SoC 12TC

    wire [31:0] debug_pc;
    wire debug_instr_req;
    wire [31:0] debug_cpu_addr, debug_cpu_wdata;
    wire [31:0] debug_neural_rdata;
    wire debug_neural_rvalid;

    ibex_simple_system_cpu_pure #(
        .SRAMInitFile("C:/Users/admin/Downloads/CPU_PURE_12TC_BUILD/firmware/cpu_pure_12tc.vmem")
    ) dut (
        .IO_CLK(clk), .IO_CLK_FAST(clk), .IO_RST_N(rst_n),
        .DEBUG_PC(debug_pc), .DEBUG_INSTR_REQ(debug_instr_req),
        .DEBUG_CPU_ADDR(debug_cpu_addr), .DEBUG_CPU_WDATA(debug_cpu_wdata),
        .DEBUG_NEURAL_RDATA(debug_neural_rdata),
        .DEBUG_NEURAL_RVALID(debug_neural_rvalid)
    );

    integer cycle_count = 0;
    integer first_fetch = -1;
    integer case_index = 0;
    integer read_count = 0;
    integer fd;
    logic complete = 1'b0;

    function automatic integer tc_number(input integer idx);
        case (idx)
          0:tc_number=1; 1:tc_number=2; 2:tc_number=3; 3:tc_number=4;
          4:tc_number=5; 5:tc_number=6; 6:tc_number=8; 7:tc_number=10;
          8:tc_number=11; 9:tc_number=13; 10:tc_number=14; 11:tc_number=17;
          default:tc_number=-1;
        endcase
    endfunction

    function automatic logic [31:0] golden_result(input integer idx);
        case (idx)
          0:golden_result=32'h09040404;
          1:golden_result=32'h05000000;
          2:golden_result=32'h05000000;
          3:golden_result=32'h0D080808;
          4:golden_result=32'hFDF8F8F8;
          5:golden_result=32'h0F0A0A0A;
          6:golden_result=32'h7F7F7F7F;
          7:golden_result=32'h7F7F7F7F;
          8:golden_result=32'h80808080;
          9:golden_result=32'h05000000;
         10:golden_result=32'h8080007F;
         11:golden_result=32'h80808080;
         default:golden_result=32'hXXXXXXXX;
        endcase
    endfunction

    initial begin
        fd = $fopen("cpu_pure_12tc_actual.csv", "w");
        if (fd == 0) $fatal(1,"Cannot create output CSV");
        $fdisplay(fd,"TC,SRAM_ADDR,ACTUAL,EXPECTED,CPU_CYCLE,FETCH_TO_WRITE_CYCLES,MATCH");
        $display("CPU_PURE_12TC_START: RV32IM software compute; no neural accelerator");
        repeat (10) @(negedge clk);
        rst_n = 1'b1;
    end

    always @(posedge clk) begin
        if (rst_n && !complete) begin
            cycle_count = cycle_count + 1;
            if (first_fetch < 0 && debug_instr_req === 1'b1)
                first_fetch = cycle_count;

            // Distinct CPU data reads of stimuli from 0x001003B8-0x00100447.
            // This is a witness of data use, not a synthetic result source.
            if (dut.device_req[0] && dut.device_gnt[0] && !dut.device_we[0] &&
                dut.device_addr[0] >= 32'h001003B8 &&
                dut.device_addr[0] < 32'h00100448)
                read_count = read_count + 1;

            if (dut.device_req[0] && dut.device_gnt[0] && dut.device_we[0] &&
                dut.device_addr[0] >= 32'h00103F00 &&
                dut.device_addr[0] < 32'h00103F30) begin
                if (case_index >= 12) $fatal(1,"More than 12 writes");
                if (dut.device_addr[0] !== (32'h00103F00 + 4*case_index))
                    $fatal(1,"Out-of-order CPU write addr=%h expected=%h",
                       dut.device_addr[0], 32'h00103F00+4*case_index);
                $display("CPU_PURE TC%02d SRAM_WRITE ADDR=%08h ACTUAL=%08h EXPECTED=%08h CYCLES=%0d %s",
                    tc_number(case_index),dut.device_addr[0],dut.device_wdata[0],
                    golden_result(case_index),
                    (first_fetch>=0 ? cycle_count-first_fetch+1 : -1),
                    (dut.device_wdata[0] === golden_result(case_index)) ? "MATCH" : "MISMATCH");
                $fdisplay(fd,"TC%02d,%08h,%08h,%08h,%0d,%0d,%0d",
                    tc_number(case_index),dut.device_addr[0],dut.device_wdata[0],
                    golden_result(case_index),cycle_count,
                    (first_fetch>=0 ? cycle_count-first_fetch+1 : -1),
                    dut.device_wdata[0] === golden_result(case_index));
                $fflush(fd);
                if (dut.device_wdata[0] !== golden_result(case_index))
                    $fatal(1,"CPU PURE math mismatch at TC%02d",tc_number(case_index));
                case_index = case_index + 1;
                if (case_index == 12) begin
                    complete = 1'b1;
                    $display("CPU_PURE_12TC_SUMMARY PASS=12/12 FIRST_FETCH=%0d LAST_CYCLE=%0d TOTAL_CYCLES=%0d DATA_READS=%0d",
                        first_fetch, cycle_count,
                        (first_fetch>=0 ? cycle_count-first_fetch+1 : -1),read_count);
                    $fclose(fd);
                    if (first_fetch<0 || read_count<36)
                        $fatal(1,"Insufficient fetch/input read evidence");
                    #1;
                    $finish;
                end
            end
            if (cycle_count > 200000) begin
                $fclose(fd);
                $fatal(1,"CPU_PURE_12TC_TIMEOUT: completed=%0d/12 at PC=%08h",
                   case_index,debug_pc);
            end
        end
    end
endmodule
