# Đóng IP CPU-only từ đúng project cpu_pure

Gói này được tách từ `CPU_ONLY_INFO_20261105_120447_1867674113.zip` bạn gửi ngày 05/11/2026. Không sử dụng nguồn CPU lấy từ project 4 IP ở lần chuẩn bị trước.

Bản sửa Tcl: đổi thủ tục `package` thành `package_cpu_ip` để không che lệnh Tcl có sẵn mà IP GUI cần. Khi source lại, script tự xóa thủ tục cùng tên của bản cũ khỏi namespace. RTL, firmware, golden và điều kiện PASS không thay đổi. Khi cập nhật, giải nén ghi đè các file của gói; không cần xóa thư mục `work` đã có.

## Chạy trong Vivado 2022.2.x

1. Giải nén vào `D:/SoC_Projects/`.
2. Lưu và đóng project Vivado đang mở. Script tạo các project riêng, không sửa `cpu_pure.xpr`.
3. Trong Tcl Console chạy:

```tcl
source {D:/soc/models/cpu-only/RUN_FROM_TESTED_RTL.tcl}
```

Nếu giải nén nơi khác, sửa đường dẫn trong lệnh `source` tương ứng.

Script thực hiện theo thứ tự:

1. Tạo project sạch bằng đúng RTL CPU trong gói; chạy CPU12 và ISA23.
2. Tạo IP `soc.local:user:ibex_cpu_only_ip:1.0`.
3. Tạo project khác; dùng `create_ip` để lấy CPU qua IP Catalog, không thêm RTL CPU rời vào project này.
4. Chạy lại CPU12 và ISA23 qua instance IP.
5. Kiểm tra golden, giao dịch ghi, SRAM vật lý, instruction X; so CSV trước/sau gồm cả cột chu kỳ.

Khi tất cả bước trên đạt, mới in:

```text
CPU_ONLY_PACKAGE_AND_REGRESSION_PASS=1
IP_REPOSITORY=.../work/run_.../ip_repo
RESULTS_DIR=.../work/run_.../evidence
```

Kết quả mới nằm trong `work/run_.../evidence`. Project dùng IP vẫn mở sau khi chạy. Nếu có lỗi, gửi toàn bộ Tcl Console từ lỗi đầu tiên và thư mục `work/run_.../evidence` nếu đã được tạo. Chưa có dòng PASS cuối nghĩa là chưa xác nhận toàn bộ luồng.

Thêm đường dẫn `IP_REPOSITORY` được in vào Settings → IP → Repository của project đích để tìm IP. IP không có AXI slave/master; cần nối giao tiếp lấy lệnh và dữ liệu native tới bộ nhớ/bus thích hợp.

## Ranh giới IP

IP chứa 54 file RTL CPU gốc, 10 header/phụ thuộc được giữ nguyên và wrapper mới `ibex_cpu_only_ip.sv`. Cấu hình cố định theo test cũ: `RV32MFast`, `RV32BNone`, `RegFileFF`, SecureIbex/PMP/ICache/WritebackStage/BranchPredictor tắt.

RAM, bus, Timer, firmware và testbench ở ngoài IP. Hệ thống ngoài CPU được giữ để test. `bus_neural.sv` trong hệ thống test chỉ giải mã địa chỉ RAM/SimCtrl/Timer theo top CPU-only; tên file không có nghĩa IP CPU chứa Neural.

Wrapper dùng một clock `clk_i`; nối cả hai chân clock cũ của lõi vào clock này, giống bài test cũ vốn cấp cùng clock 50 MHz cho `IO_CLK` và `IO_CLK_FAST`. Đây không phải xác nhận timing phần cứng ở 50 MHz hay tần số khác.

`BOOT_ADDR` mặc định `0x00100000`; với cấu hình Ibex này firmware bắt đầu thực thi tại `0x00100080`. `HART_ID` mặc định 0. Reset `rst_ni` tích cực thấp. Có các đầu vào ngắt và debug request; khi không dùng, nối mức 0.

## Bằng chứng và giới hạn

- `evidence/original/` chứa log/CSV từ gói bạn gửi, **không phải** kết quả chạy gói mới.
- `evidence/FIRMWARE_INSTRUCTION_CHECK.json`: thực thi firmware ở mức tập lệnh bằng Python; không mô phỏng RTL và không đo chu kỳ CPU.
- `evidence/STATIC_SV_CHECK.json`: kiểm tra tĩnh bằng pyslang, không phải Vivado/XSim.
- `docs/SOURCE_PROVENANCE.csv`: đường dẫn nguồn và SHA-256 của các file giữ nguyên.
- `docs/AUDIT_CPU_PURE.md`: kết quả đối chiếu chi tiết.

Vivado không có trong môi trường chuẩn bị này. Vì vậy `component.xml`, kết quả IP Packager và kết quả XSim mới sẽ được tạo khi chạy Tcl trên máy bạn. Gói hiện tại là nguồn và luồng đóng IP đã chuẩn bị, chưa được tuyên bố đã qua Vivado.

Hai bài test chưa bao phủ toàn bộ RV32IMC, mọi trường hợp MULH/DIV/REM, ngắt, debug, bus chờ hoặc lỗi bus. Chúng kiểm tra lại những bài toán đã có trong gói gốc. Muốn công bố hỗ trợ đầy đủ tập lệnh cần bộ kiểm chứng rộng hơn.

Không dùng trực tiếp Package Current Project trên project cũ nếu chỉ muốn IP CPU: top `ibex_simple_system_cpu_pure` còn chứa RAM, bus và Timer. Top đóng gói của gói mới là `ibex_cpu_only_ip`.
