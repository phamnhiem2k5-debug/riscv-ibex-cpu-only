# Kết quả kiểm tra project CPU-only — 05/11/2026

Nguồn: `CPU_ONLY_INFO_20261105_120447_1867674113.zip`, 681 file được collector sao chép.

## Kết luận

Đủ nguồn để chuẩn bị đóng IP CPU-only từ nhánh `cpu_pure`. Lõi đang dùng là nhánh Ibex đã chỉnh sửa, đã loại đường Neural khỏi khối thực thi và vô hiệu giải mã opcode Neural. Không nên gọi đây là bản upstream Ibex nguyên trạng.

| Nội dung | Bằng chứng trong gói tải lên |
|---|---|
| Vivado / thiết bị | 2022.2.2 / `xc7z020clg484-1` |
| Top tổng hợp | `ibex_simple_system_cpu_pure` |
| CPU | `u_top`, module `ibex_top` |
| Cấu hình CPU trong top | RV32MFast, RV32BNone, RegFileFF; SecureIbex/PMP/ICache/WritebackStage/BranchPredictor tắt |
| Bộ nhớ vật lý | `ram_2p`, Depth=4096 từ × 32 bit = 16 KiB |
| CPU-only 12 case | Log `sim_CPU12_FRESH_PROOF`: PASS=12/12, DATA_READS=36 |
| ISA23 CPU-only | BUS=23/23, PORT_A=23/23, SRAM=23/23, INSTR_X=0, ERRORS=0, STATUS=PASS |
| Chu kỳ CPU12 | FIRST_FETCH=3, LAST_CYCLE=2778, tổng từ lần fetch đầu đến lần ghi cuối, tính cả hai đầu = 2776 |
| Chu kỳ ISA23 | FIRST_FETCH=3, LAST_WRITE=90, tổng theo quy ước trên = 88 |
| Trạng thái run cũ | synth_design Complete, route_design Complete; riêng trạng thái này không chứng minh gói IP mới đã qua synthesis/implementation |

## CPU không có Neural hoạt động

- Top CPU-only chỉ chọn ba thiết bị: RAM, SimCtrl và Timer; không có slot MMIO Neural.
- `ibex_ex_block.sv` chọn kết quả ALU hoặc bộ MUL/DIV; không tạo instance `neural_unit` hay bộ nhân dùng chung với Neural.
- `ibex_multdiv_fast.sv` tính bằng các phép nhân bên trong CPU. Với RV32MFast, đường được chọn là bộ nhân nhiều chu kỳ của CPU.
- `ibex_decoder.sv` gán các tín hiệu kích hoạt Neural bằng 0 và bỏ giải mã opcode Neural.
- Snapshot thiết kế RTL đang mở có `u_top/u_ibex_core/ex_block_i/gen_multdiv_fast.multdiv_i`, REF_NAME `ibex_multdiv_fast`.

Một số tên cổng/tín hiệu Neural cũ vẫn còn trong nguồn CPU nhưng không tạo đường tăng tốc Neural trong cấu hình này. Ở top hệ thống, `DEBUG_NEURAL_RDATA` và `DEBUG_NEURAL_RVALID` nối tới phản hồi RAM. Chưa đổi các tên này để giữ nguyên nguồn kiểm thử.

## Firmware thật sự tính bằng CPU

Thực thi độc lập firmware `cpu_pure_12tc.vmem` bằng trình thông dịch RV32 ở mức tập lệnh cho kết quả:

- 12 giá trị ghi vào `0x00103F00` đến `0x00103F2C` khớp golden trong gói.
- 2180 lệnh thực thi đến lần ghi kết quả cuối, trong đó có 192 lệnh MUL.
- Đọc 36 từ dữ liệu trong vùng kích thích `0x001003B8`–`0x00100447`.
- Firmware ISA23 tạo 23 giá trị khớp golden trong gói.

Đây là kiểm tra chương trình độc lập với RTL; không xác nhận số chu kỳ của mạch. Con số 2776/88 chu kỳ ở bảng trên lấy từ log XSim đã tải lên, không suy từ trình thông dịch.

| Case | Kết quả | FETCH_TO_WRITE_CYCLES trong log CPU12 |
|---|---|---:|
| TC01 | 09040404 | 250 |
| TC02 | 05000000 | 481 |
| TC03 | 05000000 | 712 |
| TC04 | 0D080808 | 943 |
| TC05 | FDF8F8F8 | 1174 |
| TC06 | 0F0A0A0A | 1405 |
| TC08 | 7F7F7F7F | 1632 |
| TC10 | 7F7F7F7F | 1859 |
| TC11 | 80808080 | 2088 |
| TC13 | 05000000 | 2319 |
| TC14 | 8080007F | 2547 |
| TC17 | 80808080 | 2776 |

Các số trên là số chu kỳ cộng dồn tính từ fetch đầu tiên, không phải độ trễ riêng của mỗi phép MAC. Chưa so tốc độ với bộ Neural trong project 4 IP vì gói hiện tại không cung cấp kết quả Neural được đo theo cùng điều kiện để đối chiếu.

## Vấn đề project cũ

1. Có Block Design `soc_system.bd` và XCI Neural trong danh sách file đăng ký. Chúng không nằm trong compile order tổng hợp top CPU-only được collector xuất ra. Không đưa chúng vào IP mới.
2. Có hai đăng ký file bị thiếu:
   - `C:/Users/admin/Downloads/CPU_ONLY_12TC_V3_PC_STORE/results/cpu_pure_12tc_v3_live_probe_generated.sv`
   - `C:/Users/admin/Downloads/CPU_PURE_TC18/tb_cpu_pure_tc18.sv`
   Chúng không cần cho luồng sạch được tạo trong gói này; chưa xóa hay sửa project gốc.
3. `sim_1` hiện chọn `tb_CPU_AUDIT_04`; fileset test TC18 hiện chọn `prim_onehot_mux`. Không dựa vào Run Simulation mặc định của project cũ để chạy CPU12/ISA23.
4. Nhiều file phụ thuộc vào C:/D: và thư mục Downloads. Gói mới mang theo nguồn/firmware, tạo project riêng và thay đường dẫn testbench lúc chạy.
5. Một số thư mục run khác có CSV rỗng hoặc chỉ có header. Kết luận PASS trong báo cáo chỉ dựa vào `sim_CPU12_FRESH_PROOF` và `sim_CPU_ONLY_ISA_20261101_181239_0`, không suy cho mọi run cũ.
6. Bộ giải mã SRAM ở top hiện chọn vùng 1 MiB, nhưng SRAM vật lý chỉ 16 KiB và dùng 12 bit chỉ số từ. Địa chỉ ngoài 16 KiB có thể alias về SRAM. Gói đóng CPU không thay đổi bus/RAM này; firmware kiểm thử hiện dùng vùng 16 KiB đầu.

## Lựa chọn đóng IP

Chọn **đóng mới từ RTL của `cpu_pure`** để kiểm tra lại trước/sau trên nguồn đã xác định. IP chỉ chứa CPU; môi trường RAM/bus/Timer/firmware nằm ngoài.

Nếu tiếp tục dùng IP cũ, phải đối chiếu và thay đúng bộ RTL CPU/headers tương ứng, đặc biệt ba file `ibex_decoder.sv`, `ibex_ex_block.sv`, `ibex_multdiv_fast.sv`. Đổi tên IP hoặc sửa metadata riêng chưa chứng minh IP cũ dùng đúng nhánh CPU-only này. Lần kiểm tra hiện tại tập trung vào snapshot `cpu_pure`; chưa kiểm tra lại gói IP cũ trong lượt này.

## Kiểm tra đã thực hiện tại môi trường chuẩn bị

- 54 file RTL CPU và 10 header được sao chép nguyên byte; có SHA-256 và đường dẫn gốc.
- Wrapper mới được liên kết với toàn bộ bộ nguồn bằng pyslang 12.1.0: không lỗi, không cảnh báo.
- Bốn tổ hợp RTL/IP-adapter × CPU12/ISA23 qua kiểm tra tĩnh SystemVerilog: không lỗi, không cảnh báo. Với nhánh IP-adapter, dùng giao diện wrapper để kiểm tra cách nối; không có output IP thực của Vivado tại đây.
- Firmware kiểm tra độc lập đạt 12/12 và 23/23 theo golden đã tải lên.
- Tcl được kiểm tra cấu trúc, đường dẫn nguồn và template; các lệnh Vivado/IPX vẫn cần chạy bằng Vivado.

Kết quả gói IP mới chỉ được xác nhận khi Tcl in `CPU_ONLY_PACKAGE_AND_REGRESSION_PASS=1` sau cả bốn lần XSim và phép so sánh CSV trước/sau.

Tài liệu quy trình Vivado tham chiếu: [UG896: IP Tcl flow](https://docs.amd.com/r/2022.2-English/ug896-vivado-ip/Using-IP-Tcl-Commands-In-Design-Flows), [UG900: Simulation options](https://docs.amd.com/r/2022.2-English/ug900-vivado-logic-simulation/Vivado-Simulator-Simulation-Options).
