# Vivado 2022.2.x: rerun ISA23 using the IP in the open cpu_ip project.
# A new simulation fileset/output directory preserves earlier result files.
namespace eval ::isa23_ip_demo {}
proc ::isa23_ip_demo::signal {group label path {radix hex}} {
    if {![llength [get_objects -quiet $path]]} {
        puts "WAVE_OBJECT_MISSING=$path"
        return
    }
    add_wave -into $group -name $label -radix $radix $path
    log_wave $path
}
proc ::isa23_ip_demo::check_results {directory} {
    set status_path [file join $directory CPU_ISA_E2E_STATUS.txt]
    if {![file isfile $status_path]} { error "ISA23_DID_NOT_FINISH: inspect simulation messages; $status_path missing" }
    set fh [open $status_path r]; set status [read $fh]; close $fh
    set lines [split [string map [list \r {}] $status] \n]
    foreach marker {ISA_CASES=23 ISA_BUS_GOLDEN=23/23 ISA_RAM_PORT_A=23/23 ISA_SRAM_GOLDEN=23/23 ISA_INSTR_X_ERRORS=0 ISA_ERROR_COUNT=0 CPU_ISA_E2E_STATUS=PASS} {
        if {[lsearch -exact $lines $marker] < 0} { error "ISA23_CHECK_FAILED=$marker\n$status" }
    }
    set csv_path [file join $directory CPU_ISA_E2E_RESULTS.csv]
    set fh [open $csv_path r]; set rows [split [string trim [read $fh]] \n]; close $fh
    if {[llength $rows] != 24} { error "ISA23_CSV_ROW_COUNT_FAILED" }
    foreach row [lrange $rows 1 end] {
        set fields [split [string trim $row] ,]
        if {[llength $fields] != 12 || [lindex $fields 11] ne "PASS"} { error "ISA23_CSV_FAILED=$row" }
    }
    puts $status
    puts "ISA23_IP_RERUN_PASS=23/23"
    puts "RESULT_CSV=$csv_path"
}
proc ::isa23_ip_demo::go {} {
    if {[catch {current_project} project] || $project eq ""} { error "Open cpu_ip.xpr first." }
    if {[get_property NAME $project] ne "cpu_ip"} { error "Open the tested cpu_ip project first; current project is $project" }
    set base [get_filesets -quiet sim_isa23]
    if {[llength $base] != 1 || [get_property TOP $base] ne "tb_cpu_only_isa_e2e"} {
        error "Expected sim_isa23 with top tb_cpu_only_isa_e2e."
    }
    set tb_sources [get_files -quiet -of_objects $base]
    if {![llength $tb_sources]} { error "ISA23_TESTBENCH_SOURCES_MISSING" }
    foreach source_path $tb_sources {
        if {![file isfile $source_path]} { error "ISA23_SOURCE_MISSING=$source_path" }
    }
    catch {close_sim}
    set fs sim_ISA23_WAVE_[clock format [clock seconds] -format %Y%m%d_%H%M%S]_[clock clicks]
    create_fileset -simset -clone_properties sim_isa23 $fs
    set_property SOURCE_SET sources_1 [get_filesets $fs]
    add_files -fileset $fs -norecurse $tb_sources
    set_property TOP tb_cpu_only_isa_e2e [get_filesets $fs]
    set_property TOP_AUTO_SET 0 [get_filesets $fs]
    set_property xsim.simulate.runtime {0ns} [get_filesets $fs]
    set_property xsim.elaborate.debug_level all [get_filesets $fs]
    update_compile_order -fileset $fs
    set project_dir [get_property DIRECTORY $project]
    set project_name [get_property NAME $project]
    set directory [file join $project_dir ${project_name}.sim $fs behav xsim]
    if {[file exists [file join $directory CPU_ISA_E2E_STATUS.txt]]} { error "EXPECTED_FRESH_SIM_DIRECTORY=$directory" }
    set ::ISA23_IP_WAVE_DIR $directory
    puts "ISA23_NEW_SIMSET=$fs"
    puts "ISA23_RESULTS_DIR=$directory"
    launch_simulation -simset $fs -mode behavioral
    # Return explicitly to time zero even if a GUI default runtime was applied.
    restart
    create_wave_config
    set top /tb_cpu_only_isa_e2e
    set dut $top/dut
    set g [add_wave_group {01_CLOCK_AND_RESULTS}]
    foreach name {clk rst_n} { signal $g $name $top/$name bin }
    foreach name {cycles first_fetch last_write bus_pass port_pass sram_pass errors instr_x} {
        signal $g $name $top/$name unsigned
    }
    signal $g SEEN_23_CASES $top/seen hex
    set g [add_wave_group {02_INSTRUCTION_FETCH}]
    foreach name {instr_req instr_gnt instr_rvalid instr_err} { signal $g $name $dut/$name bin }
    foreach name {instr_addr instr_rdata} { signal $g $name $dut/$name hex }
    set g [add_wave_group {03_CPU_DATA_BUS}]
    foreach {name radix} {host_req bin host_gnt bin host_we bin host_be hex host_addr hex host_wdata hex host_rvalid bin host_rdata hex} {
        signal $g $name [format {%s/%s[0]} $dut $name] $radix
    }
    set g [add_wave_group {04_SRAM_PORT_A}]
    foreach {name radix} {a_req_i bin a_we_i bin a_be_i hex a_addr_i hex a_wdata_i hex a_rvalid_o bin a_rdata_o hex} {
        signal $g $name $dut/u_ram/$name $radix
    }
    set names {AND OR XOR NOT_XORI ADD SUB SLL SRL SRA SLT SLTU ANDI ORI XORI SLLI SRLI SRAI BEQ_TAKEN BNE_TAKEN SW_LW LUI JAL SRA_NEG}
    for {set i 0} {$i < 23} {incr i} {
        set g [add_wave_group [format {TC%02d_%s} [expr {$i+1}] [lindex $names $i]]]
        foreach {name label radix} {
            bus_data CPU_BUS_CAPTURED hex
            port_data SRAM_PORT_A_CAPTURED hex
            mem_data SRAM_END_CHECK_CAPTURED hex
            golden GOLDEN hex
            write_cycle STORE_CYCLE unsigned
            bus_match BUS_MATCH bin
            port_match PORT_A_MATCH bin
            ram_match SRAM_MATCH bin
        } {
            signal $g $label [format {%s/%s[%d]} $top $name $i] $radix
        }
        signal $g PHYSICAL_SRAM_WORD [format {%s/u_ram/u_ram/mem[%d]} $dut [expr {3968+$i}]] hex
    }
    set config [file join $directory ISA23_IP_WAVE.wcfg]
    save_wave_config $config
    run 10 us
    save_wave_config $config
    check_results $directory
    puts "WAVE_CONFIG=$config"
    puts "WAVE_DATABASES=[glob -nocomplain -directory $directory *.wdb]"
    puts "ISA23_IP_WAVE_DIR=$directory"
    puts "Simulation remains open. Click Zoom Fit and expand the TC groups."
    puts "instr_addr is a fetch address. SRAM_END_CHECK_CAPTURED is sampled after all 23 stores."
}
::isa23_ip_demo::go
