# Run the two configurations

Use **Vivado 2022.2.x** with XSim. For Windows, extract the repository to a short path, for example `D:/soc`. Replace that path in the examples with your checkout location. Run commands in the Vivado Tcl Console. Save and close any unrelated open simulation or project before running.

## CPU-only baseline

The script builds the CPU-only system from the bundled RTL and runs the 12-case workload and ISA23. It also packages Ibex as a local IP and repeats the checks through that IP.

```tcl
source {D:/soc/models/cpu-only/RUN_FROM_TESTED_RTL.tcl}
```

Look for `CPU_ONLY_PACKAGE_AND_REGRESSION_PASS=1` and the printed `RESULTS_DIR`. The script writes generated projects and evidence under `models/cpu-only/work/`. For details, see the [CPU-only README](../models/cpu-only/README.md).

## Ibex + INT2 MMIO

Run Neural12 first. ISA23 reuses the source list produced by a successful Neural12 run.

```tcl
source {D:/soc/models/ibex-int2-mmio/soc_4ip_build/DEMO_SOC4IP_NEURAL12.tcl}
source {D:/soc/models/ibex-int2-mmio/soc_4ip_build/run_soc4ip_isa23.tcl}
```

- Neural12 prints `DEMO_RESULTS_DIR` and `BUS_TO_SRAM_CHECK=12/12` when its capture checks pass. Compare its `NEURAL12_RESULTS.csv` against the golden values in [the saved comparison](../results/neural12-comparison.csv).
- ISA23 prints `ISA23_PASS=23/23` and `ISA_RESULTS_DIR` when the included checks pass.
- Run outputs are under `models/ibex-int2-mmio/soc_4ip_build/bd_project/` in `sim_demo_*` or `isa23_run_*`.

The MMIO scripts now read the XSim source manifest and library map from `soc_4ip_build/sim_inputs/`. Its manifest uses paths relative to that directory. The retained native RTL snapshot and packaged IP contain inputs referenced by the scripts. The original project files and legacy utility scripts may still refer to older project paths. Use the entry points above for simulation.

## Preflight and implementation

To check the MMIO source list without compiling HDL, set `::SOC4IP_PREFLIGHT_ONLY` before sourcing the Neural12 script. Unset it before starting a full simulation.

```tcl
set ::SOC4IP_PREFLIGHT_ONLY 1
source {D:/soc/models/ibex-int2-mmio/soc_4ip_build/DEMO_SOC4IP_NEURAL12.tcl}
unset ::SOC4IP_PREFLIGHT_ONLY
```

For FPGA work, the manuscript specifies **XC7Z020CLG484-1** and a **20 ns** target constraint. If opening the retained block design project for implementation, recheck the IP repository paths and regenerate the ILA output products if that build requires them. This source package carries the ILA configuration and omits two large generated block-memory library files from the earlier archive. Full Vivado runs and physical board validation are pending for this package.
