# RISC-V Ibex SoC with an INT2 Neural Accelerator

SystemVerilog SoC integration and RTL verification using a 32-bit Ibex core. The project compares a CPU-only firmware baseline with an external INT2 accelerator accessed through memory-mapped registers over AXI4-Lite.

**2.34× speedup on the 12-case workload in RTL simulation.** Execution decreased from **2,776 to 1,188 cycles**, a **57.2% reduction**.

[Research manuscript](docs/RISC-V.pdf) · [Simulation guide](docs/RUN_SIMULATION.md) · [Verification evidence](results/README.md)

## Architecture

| Configuration | Compute path |
| --- | --- |
| [CPU-only](models/cpu-only/) | Ibex executes the workload in firmware and writes results to SRAM. |
| [Ibex + INT2 MMIO](models/ibex-int2-mmio/) | Ibex configures the external INT2 accelerator over AXI4-Lite, reads the result register, and writes the result to SRAM. |

![System-level architecture of Ibex with a memory-mapped INT2 accelerator](docs/figures/ibex-int2-soc.png)

*Accelerator-integrated configuration. Figure 1 from the research manuscript.*

The accelerator uses signed 2-bit weights. Firmware accesses the accelerator at `0x00040000`, reads the result at `0x0004002C`, and stores the workload outputs starting at SRAM address `0x00103F00`. Both configurations use the Ibex soft core in programmable logic.

## My contribution

**Phạm Văn Nhiệm · RTL and SoC integration**

- Integrated Ibex, the AXI4-Lite MMIO path, INT2 accelerator, and dual-port SRAM in SystemVerilog and Vivado IP Integrator.
- Developed firmware and testbench flows for the 12-case workload and 23 ISA checks. Used Tcl to automate simulation and organized evidence across the CPU bus, SRAM write port, and SRAM readback.
- Compared workload cycles, FPGA resource use, and post-placement timing for the two configurations.

## Results

| Metric | CPU-only | Ibex + INT2 MMIO |
| --- | ---: | ---: |
| ISA checks in saved simulation records | 23/23 | 23/23 |
| Workload outputs matching golden data | 12/12 | 12/12 |
| Execution cycles for 12 cases | 2,776 | 1,188 |
| Latency normalized to 50 MHz | 55.52 µs | 23.76 µs |
| Placed setup WNS at 20 ns, as reported in the manuscript | +1.714 ns | +0.506 ns |

Cycle counts span the first instruction fetch through the final SRAM result write, inclusive. Latency uses the manuscript's nominal 50 MHz conversion. The archived MMIO demo records its own simulation clocks separately. These results cover the included workload and ISA checks. Timing values are from the manuscript's post-placement report. See the [evidence notes](results/README.md) and manuscript Tables 5–6.

## Repository layout

| Path | Contents |
| --- | --- |
| `models/cpu-only/` | Baseline RTL, headers, firmware, testbenches, and Tcl entry points |
| `models/ibex-int2-mmio/` | Accelerator SoC, packaged IP, block design, and XSim inputs |
| `docs/` | Research manuscript, architecture figure, and simulation instructions |
| `results/` | Saved simulation CSVs, status files, waveform configurations, and a cross-model output comparison |

Use Vivado 2022.2.x with XSim for the included flows. The MMIO Tcl source preflight passed after repackaging. Full Vivado/XSim runs and board testing remain to be verified for this package.

## Attribution

Ibex is an upstream open-source RISC-V core. The bundled [license](models/cpu-only/LICENSE) and source copyright notices are retained. The work highlighted here is SoC integration, accelerator interfacing, and verification.
