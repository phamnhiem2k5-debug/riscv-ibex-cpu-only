
`timescale 1ns/1ps

module tb_ibex_axi_bridge;

    logic clk = 0;
    logic rst_n = 0;

    always #5 clk = ~clk;

    logic req, gnt, we;
    logic [3:0] be;
    logic [31:0] addr, wdata;
    logic rvalid, err;
    logic [31:0] rdata;

    logic [31:0] awaddr, axi_wdata, araddr, axi_rdata;
    logic [3:0] wstrb;
    logic awvalid, awready, wvalid, wready;
    logic bvalid, bready;
    logic [1:0] bresp, rresp;
    logic arvalid, arready, axi_rvalid, axi_rready;

    ibex_to_axi_lite bridge (
        .clk_i(clk),
        .rst_ni(rst_n),

        .req_i(req),
        .gnt_o(gnt),
        .we_i(we),
        .be_i(be),
        .addr_i(addr),
        .wdata_i(wdata),
        .rvalid_o(rvalid),
        .rdata_o(rdata),
        .err_o(err),

        .m_axi_awaddr(awaddr),
        .m_axi_awvalid(awvalid),
        .m_axi_awready(awready),

        .m_axi_wdata(axi_wdata),
        .m_axi_wstrb(wstrb),
        .m_axi_wvalid(wvalid),
        .m_axi_wready(wready),

        .m_axi_bresp(bresp),
        .m_axi_bvalid(bvalid),
        .m_axi_bready(bready),

        .m_axi_araddr(araddr),
        .m_axi_arvalid(arvalid),
        .m_axi_arready(arready),

        .m_axi_rdata(axi_rdata),
        .m_axi_rresp(rresp),
        .m_axi_rvalid(axi_rvalid),
        .m_axi_rready(axi_rready)
    );

    neural_axi_wrapper accelerator (
        .s_axi_aclk(clk),
        .s_axi_aresetn(rst_n),

        .s_axi_awaddr(awaddr),
        .s_axi_awvalid(awvalid),
        .s_axi_awready(awready),

        .s_axi_wdata(axi_wdata),
        .s_axi_wstrb(wstrb),
        .s_axi_wvalid(wvalid),
        .s_axi_wready(wready),

        .s_axi_bresp(bresp),
        .s_axi_bvalid(bvalid),
        .s_axi_bready(bready),

        .s_axi_araddr(araddr),
        .s_axi_arvalid(arvalid),
        .s_axi_arready(arready),

        .s_axi_rdata(axi_rdata),
        .s_axi_rresp(rresp),
        .s_axi_rvalid(axi_rvalid),
        .s_axi_rready(axi_rready)
    );

    task automatic access(
        input logic write_enable,
        input logic [31:0] address,
        input logic [31:0] value
    );
        int cycles;

        @(negedge clk);
        req = 1;
        we = write_enable;
        addr = address;
        wdata = value;
        be = 4'hF;

        cycles = 0;
        do begin
            @(posedge clk);
            cycles++;
            if (cycles > 100)
                $fatal(1, "TIMEOUT WAITING FOR GRANT");
        end while (!gnt);

        @(negedge clk);
        req = 0;

        cycles = 0;
        do begin
            @(posedge clk);
            cycles++;
            if (cycles > 100)
                $fatal(1, "TIMEOUT WAITING FOR RESPONSE");
        end while (!rvalid);

        if (err)
            $fatal(1, "AXI RESPONSE ERROR");

        if (!write_enable) begin
            if (rdata !== value)
                $fatal(1, "READ MISMATCH: got=%h expected=%h",
                       rdata, value);
            $display("PASS READ: address=%h data=%h", address, rdata);
        end else begin
            $display("PASS WRITE: address=%h data=%h", address, value);
        end

        @(negedge clk);
    endtask

    initial begin
        req = 0;
        we = 0;
        be = 0;
        addr = 0;
        wdata = 0;

        repeat (5) @(posedge clk);
        @(negedge clk);
        rst_n = 1;

        access(1, 32'h08, 32'h12345678);
        access(0, 32'h08, 32'h12345678);

        $display("BRIDGE TEST PASSED");
        $finish;
    end

    initial begin
        #10000;
        $fatal(1, "GLOBAL TEST TIMEOUT");
    end

endmodule
