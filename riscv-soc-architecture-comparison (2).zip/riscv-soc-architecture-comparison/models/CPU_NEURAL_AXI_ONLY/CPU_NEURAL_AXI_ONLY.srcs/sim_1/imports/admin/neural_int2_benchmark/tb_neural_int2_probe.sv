
`timescale 1ns/1ps

module tb_neural_int2_probe;

    logic clk = 0;
    logic rst_n = 0;

    wire [31:0] debug_pc;
    wire debug_instr_req;
    wire [31:0] debug_cpu_addr;
    wire [31:0] debug_cpu_wdata;
    wire [31:0] debug_neural_rdata;
    wire debug_neural_rvalid;

    integer cycles = 0;
    integer neural_reads = 0;
    integer neural_result_reads = 0;

    logic pending_result = 0;
    logic [31:0] neural_result = 0;

    always #10 clk = ~clk;

    ibex_simple_system_neural_synth #(
        .SRAMInitFile(
            "C:/Users/admin/neural_int2_benchmark/neural_int2_probe.vmem"
        )
    ) dut (
        .IO_CLK(clk),
        .IO_CLK_FAST(clk),
        .IO_RST_N(rst_n),
        .DEBUG_PC(debug_pc),
        .DEBUG_INSTR_REQ(debug_instr_req),
        .DEBUG_CPU_ADDR(debug_cpu_addr),
        .DEBUG_CPU_WDATA(debug_cpu_wdata),
        .DEBUG_NEURAL_RDATA(debug_neural_rdata),
        .DEBUG_NEURAL_RVALID(debug_neural_rvalid)
    );

    initial begin
        $display("===== NEURAL INT2 PROBE START =====");

        repeat (10) @(negedge clk);
        rst_n = 1;

        repeat (3000) @(posedge clk);

        $display("===== NEURAL INT2 PROBE REPORT =====");
        $display("TOTAL_CYCLES = %0d", cycles);
        $display("NEURAL_READ_RESPONSES = %0d", neural_reads);
        $display("RESULT_READS_OBSERVED = %0d", neural_result_reads);
        $display("LAST_NEURAL_RDATA = %08h", neural_result);
        $display("FINAL_PC = %08h", debug_pc);
        $display("NEURAL_INT2_PROBE_TIMEOUT_OR_END");
        $finish;
    end

    always @(posedge clk) begin
        if (rst_n) begin
            cycles <= cycles + 1;

            if (debug_neural_rvalid) begin
                neural_reads <= neural_reads + 1;
                neural_result <= debug_neural_rdata;

                $display(
                    "NEURAL_RVALID cycle=%0d addr=%08h data=%08h",
                    cycles,
                    debug_cpu_addr,
                    debug_neural_rdata
                );
            end

            if (debug_cpu_addr == 32'h0004002C &&
                debug_neural_rvalid) begin

                neural_result_reads <= neural_result_reads + 1;

                $display(
                    "POSSIBLE_RESULT cycle=%0d data=%08h",
                    cycles,
                    debug_neural_rdata
                );
            end
        end
    end



    always @(posedge clk) begin
        if (rst_n &&
            debug_neural_rvalid &&
            debug_cpu_addr == 32'h0004002C) begin

            $display("===== NEURAL INTERNAL MAC =====");

            for (int i = 0; i < 4; i++) begin
                $display(
                    "OUT_REG_%0d = %0d HEX=%08h",
                    i,
                    $signed(dut.u_neural_accelerator.u_neural.out_reg[i]),
                    dut.u_neural_accelerator.u_neural.out_reg[i]
                );
            end

            $display("MODE = %0d",
                dut.u_neural_accelerator.u_neural.mode_reg);

            $display("===== END NEURAL INTERNAL MAC =====");
        end
    end



    always @(negedge clk) begin
        if (rst_n &&
            dut.u_neural_accelerator.u_neural.mab_valid) begin

            $display("===== NEURAL MAC TRACE =====");
            $display("CYCLE = %0d", cycles);

            for (int i = 0; i < 4; i++) begin
                $display(
                    "MAB_RESULT_%0d = %0d",
                    i,
                    $signed(dut.u_neural_accelerator.u_neural.mab_results[i])
                );
            end

            $display("===== END NEURAL MAC TRACE =====");
        end
    end



    always @(posedge clk) begin
        if (rst_n &&
            dut.u_neural_accelerator.u_neural.valid_in_reg[1]) begin

            $display("===== MAC OPERANDS =====");
            $display("CYCLE = %0d", cycles);

            $display("WEIGHTS_REG = %08h",
                dut.u_neural_accelerator.u_neural.weight_reg);

            $display("INPUT_REG = %08h",
                dut.u_neural_accelerator.u_neural.input_reg);

            for (int i = 0; i < 8; i++) begin
                $display(
                    "DECODED_%0d WEIGHT=%0d ACT=%0d",
                    i,
                    $signed(dut.u_neural_accelerator.u_neural.weight_vals_reg[i]),
                    $signed(dut.u_neural_accelerator.u_neural.activations_reg[i])
                );
            end

            $display("===== END MAC OPERANDS =====");
        end
    end

endmodule
