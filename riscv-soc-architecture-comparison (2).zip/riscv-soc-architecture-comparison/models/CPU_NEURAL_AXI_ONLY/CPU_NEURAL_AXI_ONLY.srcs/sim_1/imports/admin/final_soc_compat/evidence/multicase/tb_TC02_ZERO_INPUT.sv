
`timescale 1ns/1ps

module tb_TC02_ZERO_INPUT;

    logic clk = 0;
    logic rst_n = 0;

    wire [31:0] debug_pc;
    wire debug_instr_req;
    wire [31:0] debug_cpu_addr;
    wire [31:0] debug_cpu_wdata;
    wire [31:0] debug_neural_rdata;
    wire debug_neural_rvalid;

    integer cycles = 0;
    integer writes = 0;
    integer reads = 0;
    integer result_reads = 0;
    integer finish_delay = 0;

    logic pending_result = 0;
    logic got_result = 0;
    logic [31:0] actual_result = 0;

    always #10 clk = ~clk;

    ibex_simple_system_neural_synth #(
        .SRAMInitFile("C:/Users/admin/final_soc_compat/evidence/multicase/TC02_ZERO_INPUT.vmem")
    ) dut (
        .IO_CLK(clk),
        .IO_CLK_FAST(clk),
        .IO_RST_N(rst_n),
        .DEBUG_PC(debug_pc),
        .DEBUG_INSTR_REQ(debug_instr_req),
        .DEBUG_CPU_ADDR(debug_cpu_addr),
        .DEBUG_CPU_WDATA(debug_cpu_wdata),
        .DEBUG_NEURAL_RDATA(debug_neural_rdata),
        .DEBUG_NEURAL_RVALID(debug_neural_rvalid)
    );

    initial begin
        $display("====================================");
        $display("MULTICASE TEST: TC02_ZERO_INPUT");
        $display("VMEM: C:/Users/admin/final_soc_compat/evidence/multicase/TC02_ZERO_INPUT.vmem");
        $display("====================================");

        repeat (10) @(negedge clk);
        rst_n = 1;
    end

    always @(posedge clk) begin
        if (rst_n) begin
            cycles <= cycles + 1;

            if (dut.device_req[3] &&
                dut.device_gnt[3]) begin

                if (dut.device_we[3]) begin
                    writes <= writes + 1;

                    $display(
                        "CPU_WRITE addr=%08h data=%08h",
                        dut.device_addr[3],
                        dut.device_wdata[3]
                    );

                end else begin
                    reads <= reads + 1;

                    if (dut.device_addr[3] ==
                        32'h0004002C) begin

                        pending_result <= 1;
                        result_reads <= result_reads + 1;
                    end
                end
            end

            if (debug_neural_rvalid &&
                pending_result) begin

                pending_result <= 0;
                got_result <= 1;
                actual_result <= debug_neural_rdata;

                $display(
                    "ACTUAL_RESULT = %08h",
                    debug_neural_rdata
                );
            end

            if (got_result) begin
                finish_delay <= finish_delay + 1;

                if (finish_delay == 10) begin
                    $display("");
                    $display("====================================");
                    $display("CASE = TC02_ZERO_INPUT");
                    $display("CYCLES = %0d", cycles);
                    $display("CPU_WRITES = %0d", writes);
                    $display("CPU_READS = %0d", reads);
                    $display("RESULT_READS = %0d", result_reads);
                    $display("ACTUAL = %08h", actual_result);
                    $display("STATUS = RESULT_OBSERVED");
                    $display("GOLDEN_CHECK = NOT_YET_PERFORMED");
                    $display("====================================");

                    if (writes == 0 || result_reads == 0)
                        $fatal(1, "NO_VALID_SOC_ACTIVITY");

                    $finish;
                end
            end

            if (cycles >= 20000)
                $fatal(1, "MULTICASE_TIMEOUT");
        end
    end

    // AUTO_RESULT_LOG
    integer result_fd;
    initial begin
        result_fd = $fopen("C:/Users/admin/final_soc_compat/evidence/multicase/logs/TC02_ZERO_INPUT.log", "w");
        if (result_fd == 0)
            $fatal(1, "CANNOT_OPEN_RESULT_LOG");
    end

    final begin
        if (result_fd != 0) begin
            $fdisplay(result_fd, "CASE = TC02_ZERO_INPUT");
            $fdisplay(result_fd, "CYCLES = %0d", cycles);
            $fdisplay(result_fd, "CPU_WRITES = %0d", writes);
            $fdisplay(result_fd, "CPU_READS = %0d", reads);
            $fdisplay(result_fd, "RESULT_READS = %0d", result_reads);
            $fdisplay(result_fd, "ACTUAL = %08h", actual_result);
            $fdisplay(result_fd, "STATUS = %s", got_result ? "RESULT_OBSERVED" : "NO_RESULT");
            $fclose(result_fd);
        end
    end
endmodule


