
`timescale 1ns/1ps

module tb_neural_signed_mac;

    logic signed [16:0] weights [4];
    logic signed [16:0] acts [4];
    logic signed [33:0] products [4];

    integer passed = 0;
    integer failed = 0;

    for (genvar k = 0; k < 4; k++) begin : gen_mul
        assign products[k] = weights[k] * acts[k];
    end

    task automatic check_mul(
        input integer lane,
        input integer w,
        input integer a
    );
        logic signed [33:0] expected;
        begin
            weights[lane] = w;
            acts[lane] = a;
            #1;

            expected = w * a;

            if (products[lane] === expected) begin
                passed++;
                $display("PASS lane=%0d W=%0d A=%0d RESULT=%0d",
                         lane, w, a, $signed(products[lane]));
            end else begin
                failed++;
                $display("FAIL lane=%0d W=%0d A=%0d RESULT=%0d EXPECTED=%0d",
                         lane, w, a,
                         $signed(products[lane]), expected);
            end
        end
    endtask

    initial begin
        for (int i = 0; i < 4; i++) begin
            weights[i] = 0;
            acts[i] = 0;
        end

        check_mul(0, 5, 3);
        check_mul(1, -5, 3);
        check_mul(2, 5, -3);
        check_mul(3, -5, -3);

        check_mul(0, -8, 7);
        check_mul(1, -128, -128);
        check_mul(2, 127, 127);
        check_mul(3, -8, -8);

        $display("================================");
        $display("PASSED = %0d", passed);
        $display("FAILED = %0d", failed);
        $display("================================");

        $finish;
    end

endmodule

