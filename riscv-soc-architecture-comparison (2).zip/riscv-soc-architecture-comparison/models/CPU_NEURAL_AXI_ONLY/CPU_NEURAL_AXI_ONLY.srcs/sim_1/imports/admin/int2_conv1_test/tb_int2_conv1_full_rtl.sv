
`timescale 1ns/1ps

module tb_int2_conv1_full_rtl;

    logic clk_i = 0;
    logic clk_i_fast = 0;

    always #10 clk_i = ~clk_i;
    always #5 clk_i_fast = ~clk_i_fast;

    logic rstn_i = 0;
    logic bias_in = 0;
    logic valid_in = 0;
    logic get_res = 0;

    logic [31:0] bias_shift_mode = 0;
    logic [31:0] weights = 0;
    logic [31:0] input_val = 0;
    logic [31:0] out_mul_vals = 0;
    logic [31:0] out_shift_rl = 0;

    wire [16:0] weights_out[4];
    wire [16:0] act_out[4];

    logic [31:0] par_prods_in[4];

    wire [31:0] output_val;
    wire valid_out;
    wire compressed_valid;

    neural_unit dut (
        .clk_i(clk_i),
        .clk_i_fast(clk_i_fast),
        .rstn_i(rstn_i),
        .bias_in(bias_in),
        .valid_in(valid_in),
        .get_res(get_res),
        .bias_shift_mode(bias_shift_mode),
        .weights(weights),
        .input_val(input_val),
        .out_mul_vals(out_mul_vals),
        .out_shift_rl(out_shift_rl),
        .par_prods_in(par_prods_in),
        .weights_out(weights_out),
        .act_out(act_out),
        .output_val(output_val),
        .valid_out(valid_out),
        .compressed_valid(compressed_valid)
    );

    // External multipliers used by the original RTL.
    always_comb begin
        for (int i = 0; i < 4; i++) begin
            par_prods_in[i] =
                {15'b0, weights_out[i]} *
                {15'b0, act_out[i]};
        end
    end


    integer mab_pulses = 0;

    always @(negedge clk_i) begin
        if (!rstn_i)
            mab_pulses = 0;
        else if (dut.mab_valid)
            mab_pulses = mab_pulses + 1;
    end



    initial begin : full_conv1_test

        reg [31:0] wmem [0:11];
        reg [7:0] amem [0:117599];
        reg [31:0] emem [0:4703];

        integer signed biases [0:5];

        integer f, p, idx, k;
        integer signed w, a;
        integer signed ref_sum;
        integer signed expected, actual;
        integer pulses_before, pulse_count;

        integer pass_count, fail_count;
        integer ref_fail_count, rtl_fail_count;
        integer pulse_fail_count;
        integer filter_pass, filter_fail;

        reg [1:0] wbits;

        biases[0] = 24;
        biases[1] = 11;
        biases[2] = 6;
        biases[3] = -8;
        biases[4] = 74;
        biases[5] = 19;

        $readmemh(
            "C:/Users/admin/int2_conv1_test/int2_conv1_weights_rtl.mem",
            wmem
        );

        $readmemh(
            "C:/Users/admin/int2_conv1_test/int2_conv1_activations.mem",
            amem
        );

        $readmemh(
            "C:/Users/admin/int2_conv1_test/int2_conv1_expected_mac.mem",
            emem
        );

        pass_count = 0;
        fail_count = 0;
        ref_fail_count = 0;
        rtl_fail_count = 0;
        pulse_fail_count = 0;

        $display("CONV1_FULL_RTL_START");

        for (f = 0; f < 6; f = f + 1) begin

            filter_pass = 0;
            filter_fail = 0;

            for (p = 0; p < 784; p = p + 1) begin

                idx = f*784 + p;
                expected = $signed(emem[idx]);
                ref_sum = biases[f];

                // Reset RTL for each output
                @(negedge clk_i);
                rstn_i = 0;
                bias_in = 0;
                valid_in = 0;
                weights = 0;
                input_val = 0;

                repeat (5) @(negedge clk_i);
                rstn_i = 1;

                // Load signed 8-bit bias into lane 3
                @(negedge clk_i);
                bias_in = 1;
                weights = {24'b0, biases[f][7:0]};
                bias_shift_mode = 32'h00000003;

                @(negedge clk_i);
                bias_in = 0;

                #1;
                pulses_before = mab_pulses;

                // Execute all 25 INT2 MAC transactions
                for (k = 0; k < 25; k = k + 1) begin

                    wbits = (wmem[f*2 + k/16]
                             >> (30 - 2*(k%16))) & 3;

                    w = (wbits >= 2)
                        ? (integer'(wbits) - 4)
                        : integer'(wbits);

                    a = amem[idx*25+k];

                    ref_sum = ref_sum + w*a;

                    @(negedge clk_i);
                    weights = {2'b00, wbits, 28'b0};
                    input_val = {a[7:0], 24'b0};
                    valid_in = 1;

                    @(negedge clk_i);
                    valid_in = 0;
                    weights = 0;
                    input_val = 0;

                    repeat (14) @(negedge clk_i);
                end

                #1;

                actual = $signed(dut.out_reg[3]);
                pulse_count = mab_pulses - pulses_before;

                if (ref_sum != expected)
                    ref_fail_count = ref_fail_count + 1;

                if (actual != ref_sum)
                    rtl_fail_count = rtl_fail_count + 1;

                if (pulse_count != 25)
                    pulse_fail_count = pulse_fail_count + 1;

                if (ref_sum == expected &&
                    actual == ref_sum &&
                    pulse_count == 25) begin

                    pass_count = pass_count + 1;
                    filter_pass = filter_pass + 1;

                end
                else begin

                    fail_count = fail_count + 1;
                    filter_fail = filter_fail + 1;

                    // Only print first 15 failing outputs
                    if (fail_count <= 15) begin
                        $display(
                            "FAIL INDEX=%0d FILTER=%0d REF=%0d EXPECTED=%0d RTL=%0d PULSES=%0d",
                            idx, f, ref_sum,
                            expected, actual, pulse_count
                        );
                    end
                end
            end

            $display(
                "FILTER=%0d PASS=%0d FAIL=%0d",
                f, filter_pass, filter_fail
            );
        end

        $display("================================");
        $display("CONV1_FULL_RTL_REPORT");
        $display("TOTAL_OUTPUTS = 4704");
        $display("PASS_COUNT = %0d", pass_count);
        $display("FAIL_COUNT = %0d", fail_count);
        $display("REFERENCE_FAIL = %0d", ref_fail_count);
        $display("RTL_FAIL = %0d", rtl_fail_count);
        $display("PULSE_FAIL = %0d", pulse_fail_count);

        if (pass_count == 4704 &&
            fail_count == 0 &&
            ref_fail_count == 0 &&
            rtl_fail_count == 0 &&
            pulse_fail_count == 0)
            $display("CONV1_FULL_RTL_PASS");
        else
            $display("CONV1_FULL_RTL_FAIL");

        $display("================================");
        $finish;
    end

endmodule
