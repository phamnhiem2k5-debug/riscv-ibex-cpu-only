
`timescale 1ns/1ps

module tb_int2_neural_mac;

    // =================================================
    // 1. CLOCK AND CONTROL
    // =================================================

    logic clk_i = 0;
    logic clk_i_fast = 0;
    logic rstn_i = 0;

    logic bias_in = 0;
    logic valid_in = 0;
    logic get_res = 0;

    logic [31:0] bias_shift_mode = 0;
    logic [31:0] weights = 0;
    logic [31:0] input_val = 0;

    logic [31:0] out_mul_vals = 0;
    logic [31:0] out_shift_rl = 0;

    logic [31:0] par_prods_in [4];

    wire [16:0] weights_out [4];
    wire [16:0] act_out [4];

    wire [31:0] output_val;
    wire valid_out;
    wire compressed_valid;

    logic [31:0] weights_mem [0:11];

    logic [31:0] expected_acc [4];

    integer mac_count = 0;
    integer checks = 0;
    integer failures = 0;

    // Slow clock: 20 ns
    always #10 clk_i = ~clk_i;

    // Fast clock: 10 ns
    always #5 clk_i_fast = ~clk_i_fast;

    // =================================================
    // 2. DUT
    // =================================================

    neural_unit dut (
        .clk_i(clk_i),
        .clk_i_fast(clk_i_fast),
        .rstn_i(rstn_i),

        .bias_in(bias_in),
        .valid_in(valid_in),
        .get_res(get_res),

        .bias_shift_mode(bias_shift_mode),

        .weights(weights),
        .input_val(input_val),

        .out_mul_vals(out_mul_vals),
        .out_shift_rl(out_shift_rl),

        .par_prods_in(par_prods_in),

        .weights_out(weights_out),
        .act_out(act_out),

        .output_val(output_val),
        .valid_out(valid_out),
        .compressed_valid(compressed_valid)
    );

    // =================================================
    // 3. EXTERNAL SIGNED MULTIPLIERS
    // =================================================

    always_comb begin
        for (int i = 0; i < 4; i++) begin
            par_prods_in[i] =
                $signed(weights_out[i])
                * $signed(act_out[i]);
        end
    end

    // =================================================
    // 4. SCOREBOARD
    //
    // Sample mab_valid and mab_results at slow posedge.
    // Check out_reg after the NBA updates, at negedge.
    // =================================================

    logic check_pending = 0;

    always @(posedge clk_i) begin
        if (!rstn_i) begin
            check_pending = 0;
        end
        else begin
            check_pending = 0;

            if (dut.mab_valid === 1'b1) begin
                mac_count++;

                for (int i = 0; i < 4; i++) begin
                    expected_acc[i] =
                        expected_acc[i] + dut.mab_results[i];
                end

                check_pending = 1;
            end
        end
    end

    always @(negedge clk_i) begin
        if (rstn_i && check_pending) begin

            $display(
                "MAC_EVENT=%0d TIME=%0t",
                mac_count, $time
            );

            for (int i = 0; i < 4; i++) begin
                checks++;

                if (dut.out_reg[i] !== expected_acc[i]) begin
                    failures++;

                    $display(
                        "FAIL ACC lane=%0d got=%0d exp=%0d",
                        i,
                        $signed(dut.out_reg[i]),
                        $signed(expected_acc[i])
                    );
                end
                else begin
                    $display(
                        "PASS ACC lane=%0d value=%0d",
                        i,
                        $signed(dut.out_reg[i])
                    );
                end
            end

            check_pending = 0;
        end
    end

    // =================================================
    // 5. MAIN TEST
    // =================================================

    initial begin

        for (int i = 0; i < 4; i++)
            expected_acc[i] = 0;

        $readmemh(
            "C:/Users/admin/int2_conv1_test/int2_conv1_weights_rtl.mem",
            weights_mem
        );

        $display("====================================");
        $display(" INT2 NEURAL MAC TEST START");
        $display("====================================");

        // ---------------------------------------------
        // RESET
        // ---------------------------------------------

        #23;
        rstn_i = 1;

        // ---------------------------------------------
        // LOAD BIAS
        //
        // out_reg[0] = 24
        // out_reg[1] = 0
        // out_reg[2] = 0
        // out_reg[3] = 0
        //
        // bias_shift_mode[2:0] = 011 (INT2 UINT8)
        // All bias shifts = 0
        // ---------------------------------------------

        @(negedge clk_i);

        weights = 32'h18000000;
        bias_shift_mode = 32'h00000003;
        bias_in = 1;

        @(negedge clk_i);
        bias_in = 0;

        expected_acc[0] = 24;
        expected_acc[1] = 0;
        expected_acc[2] = 0;
        expected_acc[3] = 0;

        #1;

        $display(
            "BIAS_LOADED=%0d,%0d,%0d,%0d",
            $signed(dut.out_reg[0]),
            $signed(dut.out_reg[1]),
            $signed(dut.out_reg[2]),
            $signed(dut.out_reg[3])
        );

        for (int i = 0; i < 4; i++) begin
            checks++;

            if (dut.out_reg[i] !== expected_acc[i]) begin
                failures++;
                $display("FAIL BIAS lane=%0d", i);
            end
        end

        // ---------------------------------------------
        // SEND ONE REAL CONV1 WEIGHT WORD
        // ---------------------------------------------

        @(negedge clk_i);

        weights = weights_mem[0];
        input_val = 32'h01020304;
        valid_in = 1;

        @(negedge clk_i);
        valid_in = 0;

        $display(
            "WEIGHT_WORD=%h INPUT=%h",
            weights, input_val
        );

        // Wait for MAC pipeline
        repeat (15) @(negedge clk_i);

        // ---------------------------------------------
        // CHECK OUTPUT PORT
        // ---------------------------------------------

        checks++;

        if (output_val !== expected_acc[0]) begin
            failures++;
            $display(
                "FAIL OUTPUT got=%0d exp=%0d",
                $signed(output_val),
                $signed(expected_acc[0])
            );
        end
        else begin
            $display(
                "PASS OUTPUT value=%0d",
                $signed(output_val)
            );
        end

        // =================================================
        // 6. FINAL REPORT
        // =================================================

        $display("");
        $display("====================================");
        $display(" INT2 NEURAL MAC FINAL REPORT");
        $display("====================================");

        $display("MAC_COUNT = %0d", mac_count);
        $display("TOTAL_CHECKS = %0d", checks);
        $display("TOTAL_FAILURES = %0d", failures);
        $display("TOTAL_PASSED = %0d", checks - failures);

        $display(
            "FINAL_ACC = %0d,%0d,%0d,%0d",
            $signed(dut.out_reg[0]),
            $signed(dut.out_reg[1]),
            $signed(dut.out_reg[2]),
            $signed(dut.out_reg[3])
        );

        if (mac_count > 0 && failures == 0) begin
            $display("INT2_NEURAL_MAC_ACCUM_PASS");
        end
        else begin
            $display("INT2_NEURAL_MAC_ACCUM_FAIL");
            $fatal(1, "Neural MAC accumulation failed");
        end

        $finish;
    end

endmodule
