
`timescale 1ns/1ps

module tb_BENCH_TC04_INPUT_2;

    logic clk = 0;
    logic rst_n = 0;

    wire [31:0] debug_pc;
    wire debug_instr_req;
    wire [31:0] debug_cpu_addr;
    wire [31:0] debug_cpu_wdata;
    wire [31:0] debug_neural_rdata;
    wire debug_neural_rvalid;

    integer cycles = 0;
    integer writes = 0;
    integer reads = 0;
    integer result_reads = 0;
    integer finish_delay = 0;

    logic pending_result = 0;
    logic got_result = 0;
    logic [31:0] actual_result = 0;

    always #10 clk = ~clk;

    ibex_simple_system_neural_synth #(
        .SRAMInitFile("C:/Users/admin/final_soc_compat/evidence/multicase/TC04_INPUT_2.vmem")
    ) dut (
        .IO_CLK(clk),
        .IO_CLK_FAST(clk),
        .IO_RST_N(rst_n),
        .DEBUG_PC(debug_pc),
        .DEBUG_INSTR_REQ(debug_instr_req),
        .DEBUG_CPU_ADDR(debug_cpu_addr),
        .DEBUG_CPU_WDATA(debug_cpu_wdata),
        .DEBUG_NEURAL_RDATA(debug_neural_rdata),
        .DEBUG_NEURAL_RVALID(debug_neural_rvalid)
    );

    initial begin
        $display("====================================");
        $display("MULTICASE TEST: TC04_INPUT_2");
        $display("VMEM: C:/Users/admin/final_soc_compat/evidence/multicase/TC04_INPUT_2.vmem");
        $display("====================================");

        repeat (10) @(negedge clk);
        rst_n = 1;
    end

    always @(posedge clk) begin
        if (rst_n) begin
            cycles <= cycles + 1;

            if (dut.device_req[3] &&
                dut.device_gnt[3]) begin

                if (dut.device_we[3]) begin
                    writes <= writes + 1;

                    $display(
                        "CPU_WRITE addr=%08h data=%08h",
                        dut.device_addr[3],
                        dut.device_wdata[3]
                    );

                end else begin
                    reads <= reads + 1;

                    if (dut.device_addr[3] ==
                        32'h0004002C) begin

                        pending_result <= 1;
                        result_reads <= result_reads + 1;
                    end
                end
            end

            if (debug_neural_rvalid &&
                pending_result) begin

                pending_result <= 0;
                got_result <= 1;
                actual_result <= debug_neural_rdata;

                $display(
                    "ACTUAL_RESULT = %08h",
                    debug_neural_rdata
                );
            end

            if (got_result) begin
                finish_delay <= finish_delay + 1;

                if (finish_delay == 10) begin
                    $display("");
                    $display("====================================");
                    $display("CASE = TC04_INPUT_2");
                    $display("CYCLES = %0d", cycles);
                    $display("CPU_WRITES = %0d", writes);
                    $display("CPU_READS = %0d", reads);
                    $display("RESULT_READS = %0d", result_reads);
                    $display("ACTUAL = %08h", actual_result);
                    $display("STATUS = RESULT_OBSERVED");
                    $display("GOLDEN_CHECK = NOT_YET_PERFORMED");
                    $display("====================================");

                    if (writes == 0 || result_reads == 0)
                        $fatal(1, "NO_VALID_SOC_ACTIVITY");

                    $finish;
                end
            end

            if (cycles >= 20000)
                $fatal(1, "MULTICASE_TIMEOUT");
        end
    end

    // AUTO_RESULT_LOG
    integer result_fd;
    initial begin
        result_fd = $fopen("C:/Users/admin/final_soc_compat/evidence/multicase/logs/TC04_INPUT_2.log", "w");
        if (result_fd == 0)
            $fatal(1, "CANNOT_OPEN_RESULT_LOG");
    end

    final begin
        if (result_fd != 0) begin
            $fdisplay(result_fd, "CASE = TC04_INPUT_2");
            $fdisplay(result_fd, "CYCLES = %0d", cycles);
            $fdisplay(result_fd, "CPU_WRITES = %0d", writes);
            $fdisplay(result_fd, "CPU_READS = %0d", reads);
            $fdisplay(result_fd, "RESULT_READS = %0d", result_reads);
            $fdisplay(result_fd, "ACTUAL = %08h", actual_result);
            $fdisplay(result_fd, "STATUS = %s", got_result ? "RESULT_OBSERVED" : "NO_RESULT");
            $fclose(result_fd);
        end
    end


// BENCH_V1: observational monitor. Original design and firmware untouched.
localparam [31:0] BENCH_RESULT_ADDR = 32'h0004002C;
integer bfd, bcycle=0, bfetch=-1, breset=-1, bmmio=-1, bresult=-1, bwrites=0, breads=0;
reg bpending=0, bdone=0;
initial begin
  bfd = $fopen("C:/Users/admin/final_soc_compat/evidence/multicase/benchmark_neural/raw/TC04_INPUT_2.txt", "w");
  if (bfd==0) $fatal(1, "BENCH LOG OPEN FAILED");
  $fdisplay(bfd, "CASE = TC04_INPUT_2");
  $fflush(bfd);
end
always @(posedge clk) begin
  if (rst_n && !bdone) begin
    bcycle=bcycle+1;
    if (breset<0) breset=bcycle;
    if (bfetch<0 && debug_instr_req===1'b1) bfetch=bcycle;
    if (debug_neural_rvalid===1'b1 && bpending) begin
      bresult=bcycle;
      bdone=1;
      $fdisplay(bfd,"STATUS = RESULT_OBSERVED");
      $fdisplay(bfd,"ACTUAL = %08h",debug_neural_rdata);
      $fdisplay(bfd,"RESET_START = %0d",breset);
      $fdisplay(bfd,"FETCH_START = %0d",bfetch);
      $fdisplay(bfd,"MMIO_START = %0d",bmmio);
      $fdisplay(bfd,"RESULT_CYCLE = %0d",bresult);
      $fdisplay(bfd,"RESET_TO_RESULT = %0d",bresult-breset+1);
      $fdisplay(bfd,"FETCH_TO_RESULT = %0d",bfetch<0 ? -1 : bresult-bfetch+1);
      $fdisplay(bfd,"MMIO_TO_RESULT = %0d",bmmio<0 ? -1 : bresult-bmmio+1);
      $fdisplay(bfd,"CPU_WRITES = %0d",bwrites);
      $fdisplay(bfd,"CPU_READS = %0d",breads);
      $fdisplay(bfd,"RESULT_PC = %08h",debug_pc);
      $fflush(bfd);
      $fclose(bfd);
      $display("BENCH_RESULT TC04_INPUT_2 FETCH_CYCLES=%0d ACTUAL=%08h",bfetch<0 ? -1 : bresult-bfetch+1,debug_neural_rdata);
    end
    if (dut.device_req[3] && dut.device_gnt[3]) begin
      if (dut.device_we[3]) begin
        bwrites=bwrites+1;
        if (bmmio<0) bmmio=bcycle;
      end else begin
        breads=breads+1;
        if (dut.device_addr[3]==BENCH_RESULT_ADDR) bpending=1;
      end
    end
  end
end
// END_BENCH_V1

endmodule


