
`timescale 1ns/1ps

module tb_integrated_mac;

    logic clk = 0;
    logic rst_ni = 0;
    logic enable = 0;

    logic [1:0] iteration = 0;
    logic [2:0] mode = 0;
    logic [31:0] weights_dec = 0;
    logic [31:0] input_vals = 0;

    logic [16:0] weight_vals[8];
    logic [16:0] activations[8];

    logic [16:0] weights_out[4];
    logic [16:0] act_out[4];

    logic [31:0] par_prods_in[4];
    logic [31:0] results[4];

    logic occupied;
    logic valid_out;

    integer passed = 0;
    integer failed = 0;

    always #5 clk = ~clk;

    neur_decoder decoder (
        .iteration(iteration),
        .mode(mode),
        .weights_dec(weights_dec),
        .input_vals(input_vals),
        .weight_vals(weight_vals),
        .activations(activations)
    );

    for (genvar i = 0; i < 4; i++) begin : MULTIPLIERS
        assign par_prods_in[i] =
            $signed(weights_out[i]) * $signed(act_out[i]);
    end

    mul_add_block mac (
        .rst_ni(rst_ni),
        .clk_i(clk),
        .clk_i_fast(clk),
        .enable(enable),
        .weight_vals(weight_vals),
        .activations(activations),
        .mode(mode[1:0]),
        .par_prods_in(par_prods_in),
        .weights_out(weights_out),
        .act_out(act_out),
        .results(results),
        .occupied(occupied),
        .valid_out(valid_out)
    );

    task automatic reset_mac;
        begin
            @(negedge clk);
            rst_ni = 0;
            enable = 0;
            repeat (3) @(negedge clk);
            rst_ni = 1;
        end
    endtask

    task automatic run_case(
        input string name,
        input logic [2:0] test_mode,
        input logic [31:0] test_weights,
        input logic [31:0] test_inputs
    );
        integer cycles;
        bit found_valid;
        begin
            reset_mac();

            mode = test_mode;
            weights_dec = test_weights;
            input_vals = test_inputs;
            iteration = 0;

            @(negedge clk);
            enable = 1;

            @(negedge clk);
            enable = 0;

            found_valid = 0;

            for (cycles = 0; cycles < 12; cycles++) begin
                @(negedge clk);

                if (valid_out) begin
                    found_valid = 1;

                    $display(
                        "CASE=%s MODE=%0d CYCLE=%0d",
                        name, test_mode, cycles
                    );

                    for (int i = 0; i < 4; i++) begin
                        $display(
                            "RESULT[%0d]=%0d HEX=%08h",
                            i, $signed(results[i]), results[i]
                        );
                    end
                end
            end

            if (!found_valid) begin
                failed++;
                $display("PIPELINE_FAIL %s: NO VALID", name);
            end else if (name == "INT8_SIGNED") begin
                if ($signed(results[0]) === -15 &&
                    $signed(results[1]) === 9 &&
                    $signed(results[2]) === -24 &&
                    $signed(results[3]) === 21) begin
                    passed++;
                    $display("MAC_PASS %s", name);
                end else begin
                    failed++;
                    $display("MAC_FAIL %s", name);
                end
            end else if (name == "INT4_SIGNED") begin
                if ($signed(results[0]) === -24 &&
                    $signed(results[1]) === -3 &&
                    $signed(results[2]) === 9 &&
                    $signed(results[3]) === 21) begin
                    passed++;
                    $display("MAC_PASS %s", name);
                end else begin
                    failed++;
                    $display("MAC_FAIL %s", name);
                end
            end else begin
                $display("INT2_REQUIRES_REFERENCE_MODEL");
            end
        end
    endtask

    initial begin
        repeat (2) @(negedge clk);

        run_case(
            "INT8_SIGNED",
            3'b101,
            32'hFB03F807,
            32'h03030303
        );

        run_case(
            "INT4_SIGNED",
            3'b110,
            32'h8F370000,
            32'h03030303
        );

        run_case(
            "INT2_PACKED",
            3'b111,
            32'h55555555,
            32'h03030303
        );

        $display("================================");
        $display("PIPELINE_PASSED=%0d", passed);
        $display("PIPELINE_FAILED=%0d", failed);
        $display("================================");

        $finish;
    end

endmodule

