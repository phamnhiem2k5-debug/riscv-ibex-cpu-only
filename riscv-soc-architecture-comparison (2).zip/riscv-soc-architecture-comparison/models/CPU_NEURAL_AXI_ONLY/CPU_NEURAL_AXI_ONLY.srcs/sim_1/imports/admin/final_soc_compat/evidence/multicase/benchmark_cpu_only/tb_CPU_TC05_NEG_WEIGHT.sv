`timescale 1ns/1ps
// Pure CPU-only. Result is a CPU store into SRAM, never an accelerator read.
module tb_CPU_TC05_NEG_WEIGHT;
  logic clk = 1'b0;
  logic rst_n = 1'b0;
  wire [31:0] debug_pc, debug_cpu_addr, debug_cpu_wdata;
  wire [31:0] debug_neural_rdata;
  wire debug_instr_req, debug_neural_rvalid;
  localparam logic [31:0] RESULT_ADDR = 32'h00103FFC;
  localparam logic [31:0] EXPECTED = 32'hB9F8B4F8;
  localparam integer TIMEOUT_CYCLES = 30000;
  integer fd;
  integer bcycle=0, bfetch=-1, bresult=-1;
  integer writes=0;
  logic done=1'b0;
  always #10 clk = ~clk; // 50 MHz

  ibex_simple_system_cpu_only #(
      .SRAMInitFile("C:/Users/admin/final_soc_compat/evidence/multicase/benchmark_cpu_only/firmware/TC05_NEG_WEIGHT.vmem")
  ) dut (
      .IO_CLK(clk), .IO_CLK_FAST(clk), .IO_RST_N(rst_n),
      .DEBUG_PC(debug_pc), .DEBUG_INSTR_REQ(debug_instr_req),
      .DEBUG_CPU_ADDR(debug_cpu_addr), .DEBUG_CPU_WDATA(debug_cpu_wdata),
      .DEBUG_NEURAL_RDATA(debug_neural_rdata),
      .DEBUG_NEURAL_RVALID(debug_neural_rvalid)
  );

  initial begin
    fd=$fopen("C:/Users/admin/final_soc_compat/evidence/multicase/benchmark_cpu_only/results/TC05_NEG_WEIGHT.txt","w");
    if (!fd) $fatal(1,"CANNOT_OPEN_RESULTS_FILE");
    $fdisplay(fd,"CASE = TC05_NEG_WEIGHT");
    repeat (10) @(negedge clk);
    rst_n=1'b1;
  end

  always @(posedge clk) begin
    if (rst_n && !done) begin
      bcycle=bcycle+1;
      // Same start criterion used in neural_bench.py.
      if (bfetch<0 && debug_instr_req===1'b1) bfetch=bcycle;
      if (dut.device_req[0] === 1'b1 && dut.device_gnt[0] === 1'b1 &&
          dut.device_we[0] === 1'b1) begin
        writes=writes+1;
        if (dut.device_addr[0] == RESULT_ADDR) begin
          bresult=bcycle;
          done=1'b1;
          $fdisplay(fd,"STATUS = RESULT_OBSERVED");
          $fdisplay(fd,"ACTUAL = %08h",dut.device_wdata[0]);
          $fdisplay(fd,"EXPECTED = %08h",EXPECTED);
          $fdisplay(fd,"FETCH_START = %0d",bfetch);
          $fdisplay(fd,"RESULT_CYCLE = %0d",bresult);
          $fdisplay(fd,"FETCH_TO_RESULT = %0d",bresult-bfetch+1);
          $fdisplay(fd,"LATENCY_US_50MHZ = %0d.%02d",(bresult-bfetch+1)/50,((bresult-bfetch+1)%50)*2);
          $fdisplay(fd,"CPU_STORES = %0d",writes);
          $fdisplay(fd,"RESULT_PC = %08h",debug_pc);
          $fdisplay(fd,"MATCH = %0d",dut.device_wdata[0] === EXPECTED);
          $fflush(fd);
          $fclose(fd);
          $display("CPU_ONLY_RESULT TC05_NEG_WEIGHT ACTUAL=%08h EXPECTED=%08h CYCLES=%0d",dut.device_wdata[0], EXPECTED,bresult-bfetch+1);
          if (dut.device_wdata[0] !== EXPECTED) $fatal(1,"CPU_ONLY_GOLDEN_MISMATCH");
          $finish;
        end
      end
      // CPU-only must never use the Neural MMIO slot.
      if (dut.device_req[3] === 1'b1) $fatal(1,"CPU_ONLY_ACCESSED_NEURAL_MMIO");
      if (bcycle>TIMEOUT_CYCLES) $fatal(1,"CPU_ONLY_TIMEOUT");
    end
  end
endmodule
