`timescale 1ns/1ps
// Generated: ALIGNED CPU+NEURAL benchmark. DO NOT modify actual DUT RTL.
// Start: first asserted instruction fetch. Stop: genuine CPU SRAM write handshake.
// No hardcoded Golden answer or prefilled result is used in this testbench.
module tb_NEURAL_ALIGNED_TC06_ASYMMETRIC_INPUT;
  logic clk = 1'b0;
  logic rst_n = 1'b0;
  wire [31:0] debug_pc, debug_cpu_addr, debug_cpu_wdata, debug_neural_rdata;
  wire debug_instr_req, debug_neural_rvalid;
  integer cycle_count=0, first_fetch=-1, result_cycle=-1;
  integer neural_writes=0, neural_reads=0, stores=0, fd;
  bit pending_read=1'b0, read_seen=1'b0, done=1'b0;
  logic [31:0] neural_result=32'h0;
  localparam logic [31:0] RESULT_STORE_ADDR = 32'h00103FFC;
  localparam logic [31:0] NEURAL_RESULT_ADDR = 32'h0004002C;
  always #10 clk=~clk;  // 50 MHz
  ibex_simple_system_neural_synth #(.SRAMInitFile("C:/Users/admin/final_soc_compat/evidence/multicase/benchmark_neural_aligned/firmware/TC06_ASYMMETRIC_INPUT.vmem")) dut (
    .IO_CLK(clk), .IO_CLK_FAST(clk), .IO_RST_N(rst_n),
    .DEBUG_PC(debug_pc), .DEBUG_INSTR_REQ(debug_instr_req),
    .DEBUG_CPU_ADDR(debug_cpu_addr), .DEBUG_CPU_WDATA(debug_cpu_wdata),
    .DEBUG_NEURAL_RDATA(debug_neural_rdata),
    .DEBUG_NEURAL_RVALID(debug_neural_rvalid)
  );
  initial begin
    fd=$fopen("C:/Users/admin/final_soc_compat/evidence/multicase/benchmark_neural_aligned/results/TC06_ASYMMETRIC_INPUT.txt","w");
    if (fd==0) $fatal(1,"ALIGNED_BENCH_LOG_OPEN_FAILED");
    repeat (10) @(negedge clk);
    rst_n=1'b1;
  end
  always @(posedge clk) if (rst_n && !done) begin
    cycle_count=cycle_count+1;
    if (first_fetch<0 && debug_instr_req===1'b1)
      first_fetch=cycle_count;
    // CPU-to-Neural accepted transactions. Read response checked separately.
    if (dut.device_req[3]===1'b1 && dut.device_gnt[3]===1'b1) begin
      if (dut.device_we[3]===1'b1)
        neural_writes=neural_writes+1;
      else begin
        neural_reads=neural_reads+1;
        if (dut.device_addr[3]===NEURAL_RESULT_ADDR)
          pending_read=1'b1;
      end
    end
    if (debug_neural_rvalid===1'b1 && pending_read) begin
      read_seen=1'b1;
      neural_result=debug_neural_rdata;
      pending_read=1'b0;
    end
    // Same endpoint as verified CPU-only: SRAM device 0 accepted word store.
    if (dut.device_req[0]===1'b1 && dut.device_gnt[0]===1'b1 && dut.device_we[0]===1'b1) begin
      stores=stores+1;
      if (dut.device_addr[0]===RESULT_STORE_ADDR) begin
        if (first_fetch<0 || !read_seen || neural_writes<1 || neural_reads<1)
          $fatal(1,"SRAM_STORE_WITHOUT_CPU_NEURAL_COMPUTE");
        if (dut.device_be[0]!==4'hf)
          $fatal(1,"RESULT_STORE_NOT_32_BIT");
        if (dut.device_wdata[0]!==neural_result)
          $fatal(1,"SRAM_STORE_DOES_NOT_MATCH_CPU_READ_RESULT");
        result_cycle=cycle_count;
        done=1'b1;
        $fdisplay(fd,"RUN_ID = 3F0D06144E9F3F6955D0BFCF");
        $fdisplay(fd,"CASE = TC06_ASYMMETRIC_INPUT");
        $fdisplay(fd,"EVENT = CPU_SRAM_STORE");
        $fdisplay(fd,"ADDRESS = %08h",dut.device_addr[0]);
        $fdisplay(fd,"ACTUAL = %08h",dut.device_wdata[0]);
        $fdisplay(fd,"NEURAL_RESULT = %08h",neural_result);
        $fdisplay(fd,"FIRST_FETCH = %0d",first_fetch);
        $fdisplay(fd,"RESULT_CYCLE = %0d",result_cycle);
        $fdisplay(fd,"CYCLES = %0d",result_cycle-first_fetch+1);
        $fdisplay(fd,"STORES = %0d",stores);
        $fdisplay(fd,"NEURAL_WRITES = %0d",neural_writes);
        $fdisplay(fd,"NEURAL_READS = %0d",neural_reads);
        $fdisplay(fd,"END_PC = %08h",debug_pc);
        $fflush(fd);
        $fclose(fd);
        $display("ALIGNED_RAW TC06_ASYMMETRIC_INPUT ACTUAL=%08h CYCLES=%0d",dut.device_wdata[0],result_cycle-first_fetch+1);
        $finish;
      end
    end
    if (cycle_count > 30000) $fatal(1,"ALIGNED_NEURAL_TIMEOUT_NO_CPU_SRAM_STORE");
  end
endmodule
