
`timescale 1ns/1ps

module tb_int2_conv1_25_rtl;

    logic clk_i = 0;
    logic clk_i_fast = 0;

    always #10 clk_i = ~clk_i;
    always #5 clk_i_fast = ~clk_i_fast;

    logic rstn_i = 0;
    logic bias_in = 0;
    logic valid_in = 0;
    logic get_res = 0;

    logic [31:0] bias_shift_mode = 0;
    logic [31:0] weights = 0;
    logic [31:0] input_val = 0;
    logic [31:0] out_mul_vals = 0;
    logic [31:0] out_shift_rl = 0;

    wire [16:0] weights_out[4];
    wire [16:0] act_out[4];

    logic [31:0] par_prods_in[4];

    wire [31:0] output_val;
    wire valid_out;
    wire compressed_valid;

    neural_unit dut (
        .clk_i(clk_i),
        .clk_i_fast(clk_i_fast),
        .rstn_i(rstn_i),
        .bias_in(bias_in),
        .valid_in(valid_in),
        .get_res(get_res),
        .bias_shift_mode(bias_shift_mode),
        .weights(weights),
        .input_val(input_val),
        .out_mul_vals(out_mul_vals),
        .out_shift_rl(out_shift_rl),
        .par_prods_in(par_prods_in),
        .weights_out(weights_out),
        .act_out(act_out),
        .output_val(output_val),
        .valid_out(valid_out),
        .compressed_valid(compressed_valid)
    );

    // External multipliers used by the original RTL.
    always_comb begin
        for (int i = 0; i < 4; i++) begin
            par_prods_in[i] =
                {15'b0, weights_out[i]} *
                {15'b0, act_out[i]};
        end
    end

    integer mab_pulses = 0;

    always @(negedge clk_i) begin
        if (rstn_i && dut.mab_valid) begin
            mab_pulses = mab_pulses + 1;

            $display(
                "MAB_VALID t=%0t result0=%08h result1=%08h",
                $time,
                dut.mab_results[0],
                dut.mab_results[1]
            );
        end
    end


    initial begin : conv1_25_test
        reg [31:0] wmem [0:11];
        reg [7:0] amem [0:117599];
        reg [31:0] emem [0:4703];

        integer k;
        integer pos;
        integer signed w;
        integer unsigned a;
        integer signed reference_sum;
        reg [1:0] wbits;

        $readmemh(
            "C:/Users/admin/int2_conv1_test/int2_conv1_weights_rtl.mem",
            wmem
        );
        $readmemh(
            "C:/Users/admin/int2_conv1_test/int2_conv1_activations.mem",
            amem
        );
        $readmemh(
            "C:/Users/admin/int2_conv1_test/int2_conv1_expected_mac.mem",
            emem
        );

        $display("CONV1_25_RTL_START");

        repeat (4) @(negedge clk_i);
        rstn_i = 1;

        @(negedge clk_i);
        bias_in = 1;
        weights = 32'h00000018;
        bias_shift_mode = 32'h00000003;

        @(negedge clk_i);
        bias_in = 0;

        #1;
        $display("BIAS_LANE3 = %0d",
                 $signed(dut.out_reg[3]));

        reference_sum = 24;

        for (k = 0; k < 25; k = k + 1) begin
            wbits = (wmem[k/16] >> (30 - 2*(k%16))) & 3;
            w = (wbits >= 2) ? (integer'(wbits) - 4)
                             : integer'(wbits);

            pos = 68*25 + k;
            a = amem[pos];

            reference_sum = reference_sum + w*a;

            @(negedge clk_i);
            weights = {2'b00, wbits, 28'b0};
            input_val = {a[7:0], 24'b0};
            valid_in = 1;

            @(negedge clk_i);
            valid_in = 0;
            weights = 0;
            input_val = 0;

            repeat (14) @(negedge clk_i);
            #1;

            $display(
                "STEP=%0d W=%0d A=%0d REF=%0d L0=%0d L1=%0d L2=%0d L3=%0d PULSES=%0d",
                k, w, a, reference_sum,
                $signed(dut.out_reg[0]),
                $signed(dut.out_reg[1]),
                $signed(dut.out_reg[2]),
                $signed(dut.out_reg[3]),
                mab_pulses
            );
        end

        $display("================================");
        $display("CONV1_25_RTL_REPORT");
        $display("OUTPUT_INDEX = 68");
        $display("REFERENCE_CALCULATED = %0d", reference_sum);
        $display("EXPECTED_MAC = %0d", $signed(emem[68]));
        $display("ACTUAL_LANE3 = %0d", $signed(dut.out_reg[3]));
        $display("MAB_PULSES = %0d", mab_pulses);

        if (reference_sum != $signed(emem[68])) begin
            $display("CONV1_25_REFERENCE_FAIL");
        end
        else if (mab_pulses == 25 &&
                 $signed(dut.out_reg[3]) == reference_sum) begin
            $display("CONV1_25_RTL_PASS");
        end
        else begin
            $display("CONV1_25_RTL_FAIL");
        end

        $display("================================");
        $finish;
    end

    // RTL_MAC_DEBUG_BEGIN

    always @(negedge clk_i_fast) begin
        if (rstn_i && $time < 400000) begin
            $display(
                "FAST t=%0t en=%b iter=%b w0=%05h a0=%05h p0=%08h",
                $time,
                dut.MAB.enable,
                dut.MAB.iter,
                weights_out[0],
                act_out[0],
                par_prods_in[0]
            );
        end
    end

    always @(negedge clk_i) begin
        if (rstn_i && $time < 400000) begin
            $display(
                "SLOW t=%0t vin=%b mab_valid=%b dec_w0=%05h dec_a0=%05h acc0=%0d",
                $time,
                valid_in,
                dut.mab_valid,
                dut.weight_vals[0],
                dut.activations[0],
                $signed(dut.out_reg[0])
            );
        end
    end

    // RTL_MAC_DEBUG_END


    // MAB_PIPELINE_DEBUG_BEGIN

    always @(negedge clk_i_fast) begin
        if (rstn_i && $time >= 170 && $time <= 270) begin
            $display(
                "PIPE t=%0t iter=%b en=%b p0=%08h add0=%08h reg0=%08h wire0=%08h out0=%08h reg2=%08h wire2=%08h out2=%08h",
                $time,
                dut.MAB.iter,
                dut.MAB.enable,
                par_prods_in[0],
                dut.MAB.add_results[0],
                dut.MAB.add_res_reg[0],
                dut.MAB.add_res_wire[0],
                dut.MAB.add_res_out[0],
                dut.MAB.add_res_reg[2],
                dut.MAB.add_res_wire[2],
                dut.MAB.add_res_out[2]
            );
        end
    end

    always @(negedge clk_i) begin
        if (rstn_i && $time >= 170 && $time <= 270) begin
            $display(
                "ACC t=%0t valid=%b r0=%08h r1=%08h r2=%08h r3=%08h acc0=%0d acc1=%0d acc2=%0d acc3=%0d",
                $time,
                dut.mab_valid,
                dut.mab_results[0],
                dut.mab_results[1],
                dut.mab_results[2],
                dut.mab_results[3],
                $signed(dut.out_reg[0]),
                $signed(dut.out_reg[1]),
                $signed(dut.out_reg[2]),
                $signed(dut.out_reg[3])
            );
        end
    end

    // MAB_PIPELINE_DEBUG_END

endmodule
