
`timescale 1ns/1ps

module tb_int2_datapath;

    logic [1:0] iteration;
    logic [2:0] mode;
    logic [31:0] weights_dec;
    logic [31:0] input_vals;

    wire [16:0] weight_vals [8];
    wire [16:0] activations [8];

    logic [31:0] weights_mem [0:11];

    logic [31:0] p_a [2];
    logic [31:0] p_b [2];
    wire  [31:0] sums [2];

    logic signed [31:0] products [4];

    integer half;
    integer checks;
    integer failures;
    integer high_sum;
    integer low_sum;
    integer expected_high;
    integer expected_low;

    // Decoder
    neur_decoder DEC (
        .iteration(iteration),
        .mode(mode),
        .weights_dec(weights_dec),
        .input_vals(input_vals),
        .weight_vals(weight_vals),
        .activations(activations)
    );

    // External signed multipliers
    always_comb begin
        for (int i = 0; i < 4; i++) begin
            products[i] =
                $signed(weight_vals[4*half+i])
                * $signed(activations[4*half+i]);
        end

        p_a[0] = products[0];
        p_b[0] = products[1];
        p_a[1] = products[2];
        p_b[1] = products[3];
    end

    // Actual RTL adder
    add_block ADD (
        .p_a(p_a),
        .p_b(p_b),
        .mode_3(1'b1),
        .sums(sums)
    );

    // Signed 10-bit reference
    function automatic integer sext10(
        input logic [9:0] x
    );
        if (x[9])
            sext10 = integer'(x) - 1024;
        else
            sext10 = integer'(x);
    endfunction

    // Signed 12-bit reference with wrapping
    function automatic integer sext12(
        input integer x
    );
        integer y;
        begin
            y = x & 4095;
            sext12 = (y >= 2048) ? y - 4096 : y;
        end
    endfunction

    initial begin
        checks = 0;
        failures = 0;
        half = 0;

        iteration = 0;
        mode = 3'b011;
        input_vals = 32'h01020304;
        weights_dec = 0;

        $readmemh(
            "C:/Users/admin/int2_conv1_test/int2_conv1_weights_rtl.mem",
            weights_mem
        );

        $display("==================================");
        $display(" INT2 DATAPATH TEST START");
        $display("==================================");

        for (int k = 0; k < 12; k++) begin
            weights_dec = weights_mem[k];

            for (int h = 0; h < 2; h++) begin
                half = h;
                #2;

                high_sum = 0;
                low_sum = 0;

                // Independent arithmetic reference:
                // Decode the two signed 10-bit fields
                // from each multiplier product.
                for (int i = 0; i < 4; i++) begin
                    high_sum += sext10(products[i][21:12]);
                    low_sum  += sext10(products[i][9:0]);
                end

                expected_high = sext12(high_sum);
                expected_low  = sext12(low_sum);

                checks++;

                if ($signed(sums[0]) !== expected_high) begin
                    failures++;
                    $display(
                        "FAIL HIGH word=%0d half=%0d got=%0d exp=%0d",
                        k, h, $signed(sums[0]), expected_high
                    );
                end

                checks++;

                if ($signed(sums[1]) !== expected_low) begin
                    failures++;
                    $display(
                        "FAIL LOW word=%0d half=%0d got=%0d exp=%0d",
                        k, h, $signed(sums[1]), expected_low
                    );
                end
            end
        end

        $display("");
        $display("==================================");
        $display(" INT2 DATAPATH FINAL REPORT");
        $display("==================================");
        $display("TOTAL_CHECKS = %0d", checks);
        $display("TOTAL_FAILURES = %0d", failures);
        $display("TOTAL_PASSED = %0d", checks-failures);

        if (failures == 0)
            $display("INT2_DATAPATH_PASS");
        else begin
            $display("INT2_DATAPATH_FAIL");
            $fatal(1, "INT2 datapath mismatch");
        end

        $finish;
    end

endmodule
