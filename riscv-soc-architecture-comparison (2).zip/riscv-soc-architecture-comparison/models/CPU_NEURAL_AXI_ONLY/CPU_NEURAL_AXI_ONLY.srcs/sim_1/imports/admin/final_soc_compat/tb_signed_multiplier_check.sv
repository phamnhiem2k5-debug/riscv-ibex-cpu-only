
module tb_signed_multiplier_check;

    logic [16:0] w, a;
    logic [33:0] rtl_product;
    logic signed [33:0] signed_product;

    assign rtl_product =
        $unsigned(w) * $unsigned(a);

    assign signed_product =
        $signed(w) * $signed(a);

    task automatic check(input integer wi, input integer ai);
        begin
            w = wi;
            a = ai;
            #1;

            $display(
                "W=%0d A=%0d RTL=%08h EXPECTED=%08h %s",
                wi, ai,
                rtl_product[31:0],
                signed_product[31:0],
                rtl_product[31:0] == signed_product[31:0]
                    ? "MATCH" : "MISMATCH"
            );
        end
    endtask

    initial begin
        $display("========== SIGNED MULTIPLIER RTL TEST ==========");

        check(5, 3);
        check(-5, 3);
        check(5, -3);
        check(-5, -3);
        check(-8, 7);
        check(-128, -128);
        check(127, 127);

        $display("========== TEST COMPLETE ==========");
        $finish;
    end

endmodule

