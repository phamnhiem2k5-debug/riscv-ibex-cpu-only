
`timescale 1ns/1ps

module tb_wrapper_signed_mul;

    logic clk = 0;
    logic rstn = 0;

    always #5 clk = ~clk;

    neural_axi_wrapper dut (
        .s_axi_aclk(clk),
        .s_axi_aresetn(rstn),

        .s_axi_awaddr(32'b0),
        .s_axi_awvalid(1'b0),
        .s_axi_awready(),

        .s_axi_wdata(32'b0),
        .s_axi_wstrb(4'b0),
        .s_axi_wvalid(1'b0),
        .s_axi_wready(),

        .s_axi_bresp(),
        .s_axi_bvalid(),
        .s_axi_bready(1'b0),

        .s_axi_araddr(32'b0),
        .s_axi_arvalid(1'b0),
        .s_axi_arready(),

        .s_axi_rdata(),
        .s_axi_rresp(),
        .s_axi_rvalid(),
        .s_axi_rready(1'b0)
    );

    integer passed = 0;
    integer failed = 0;

    initial begin
        // Force decoded operands into the actual wrapper
        force dut.weights_out[0] = 17'sd5;
        force dut.act_out[0] = 17'sd3;

        force dut.weights_out[1] = -17'sd5;
        force dut.act_out[1] = 17'sd3;

        force dut.weights_out[2] = 17'sd5;
        force dut.act_out[2] = -17'sd3;

        force dut.weights_out[3] = -17'sd5;
        force dut.act_out[3] = -17'sd3;

        #2;

        if ($signed(dut.internal_products[0]) == 15) passed++; else failed++;
        if ($signed(dut.internal_products[1]) == -15) passed++; else failed++;
        if ($signed(dut.internal_products[2]) == -15) passed++; else failed++;
        if ($signed(dut.internal_products[3]) == 15) passed++; else failed++;

        $display("================================");
        $display("WRAPPER_SIGNED_PASSED = %0d", passed);
        $display("WRAPPER_SIGNED_FAILED = %0d", failed);
        $display("================================");

        $finish;
    end

endmodule

