
`timescale 1ns/1ps

module tb_int2_conv1_rtl_quant;

    localparam integer N = 4704;
    localparam integer GROUPS = N / 4;

    localparam logic [7:0] MULTIPLIER = 8'd201;
    localparam logic [4:0] SHIFT = 5'd10;

    logic clk_i = 0;
    logic clk_i_fast = 0;
    logic rst_ni = 0;
    logic get_res = 0;

    logic [31:0] out_mul_vals;
    logic [31:0] out_shift_rl;

    logic [31:0] out_results [4];
    logic [31:0] quant_products [4];

    wire [16:0] q_mul [4];
    wire [16:0] q_out [4];

    wire [31:0] compressed_out;
    wire valid_out;

    logic [31:0] mac_mem [0:N-1];
    logic [7:0] expected_mem [0:N-1];

    integer error_file;
    integer checks = 0;
    integer failures = 0;
    integer valid_failures = 0;
    integer first_mismatch = -1;

    // Clock slow = 20 ns
    always #10 clk_i = ~clk_i;

    // Clock fast = 10 ns
    always #5 clk_i_fast = ~clk_i_fast;

    neur_out_unit DUT (
        .clk_i(clk_i),
        .clk_i_fast(clk_i_fast),
        .rst_ni(rst_ni),
        .get_res(get_res),
        .out_mul_vals(out_mul_vals),
        .out_shift_rl(out_shift_rl),
        .out_results(out_results),
        .quant_products(quant_products),
        .q_mul(q_mul),
        .q_out(q_out),
        .compressed_out(compressed_out),
        .valid_out(valid_out)
    );

    // External multipliers.
    // RTL uses unsigned magnitudes for quantization.
    always_comb begin
        for (int i = 0; i < 4; i++) begin
            quant_products[i] =
                {15'b0, q_mul[i]} *
                {15'b0, q_out[i]};
        end
    end

    task automatic run_group(input integer g);

        logic [7:0] actual;
        integer idx;

        begin
            // Reset between groups to make each
            // transaction independent.
            @(negedge clk_i);
            get_res = 0;
            rst_ni = 0;

            for (int j = 0; j < 4; j++) begin
                out_results[j] = mac_mem[g*4+j];
            end

            repeat (2) @(negedge clk_i);

            rst_ni = 1;
            get_res = 1;

            // Five slow-clock edges advance
            // counter from 0 to 5.
            repeat (5) @(negedge clk_i);

            get_res = 0;
            #1;

            if (valid_out !== 1'b1) begin
                valid_failures++;

                    $fdisplay(
                        error_file,
                        "QUANT_FAIL idx=%0d MAC=%0d RTL=%0d C=%0d",
                        idx,
                        $signed(mac_mem[idx]),
                        actual,
                        expected_mem[idx]
                    );

                if (valid_failures <= 10)
                    $display(
                        "VALID_FAIL group=%0d time=%0t",
                        g, $time
                    );
            end

            for (int j = 0; j < 4; j++) begin

                idx = g*4+j;

                actual = compressed_out[31-8*j -: 8];

                checks++;

                if (actual !== expected_mem[idx]) begin
                    failures++;

                    $fdisplay(
                        error_file,
                        "QUANT_FAIL idx=%0d MAC=%0d RTL=%0d C=%0d",
                        idx,
                        $signed(mac_mem[idx]),
                        actual,
                        expected_mem[idx]
                    );

                    if (first_mismatch < 0)
                        first_mismatch = idx;

                    if (failures <= 20) begin
                        $display(
                            "QUANT_FAIL idx=%0d MAC=%0d RTL=%0d C=%0d",
                            idx,
                            $signed(mac_mem[idx]),
                            actual,
                            expected_mem[idx]
                        );
                    end
                end
            end

            if ((g+1) % 196 == 0) begin
                $display(
                    "PROGRESS groups=%0d/%0d checks=%0d failures=%0d",
                    g+1, GROUPS, checks, failures
                );
            end
        end
    endtask

    initial begin

        error_file = $fopen(
            "C:/Users/admin/int2_conv1_test/quant_failures.txt",
            "w"
        );

        if (error_file == 0) begin
            $display("ERROR: Cannot create quant_failures.txt");
            $finish;
        end


        // Same multiplier for all four lanes.
        out_mul_vals = {
            MULTIPLIER,
            MULTIPLIER,
            MULTIPLIER,
            MULTIPLIER
        };

        // Four 5-bit shift fields, ReLU enabled.
        out_shift_rl =
            (32'(SHIFT) << 27) |
            (32'(SHIFT) << 20) |
            (32'(SHIFT) << 13) |
            (32'(SHIFT) << 6)  |
            32'h1;

        for (int i = 0; i < 4; i++) begin
            out_results[i] = 0;
        end

        $readmemh(
            "C:/Users/admin/int2_conv1_test/int2_conv1_expected_mac.mem",
            mac_mem
        );

        $readmemh(
            "C:/Users/admin/int2_conv1_test/int2_conv1_expected_output.mem",
            expected_mem
        );

        $display("======================================");
        $display(" INT2 CONV1 RTL QUANTIZATION TEST");
        $display("======================================");

        $display("MULTIPLIER = %0d", MULTIPLIER);
        $display("SHIFT = %0d", SHIFT);
        $display("OUTPUTS = %0d", N);

        for (int g = 0; g < GROUPS; g++) begin
            run_group(g);
        end

        $display("");
        $display("======================================");
        $display(" INT2 CONV1 RTL QUANT REPORT");
        $display("======================================");

        $display("OUTPUT_CHECKS = %0d", checks);
        $display("OUTPUT_FAILURES = %0d", failures);
        $display("VALID_FAILURES = %0d", valid_failures);
        $display("OUTPUT_MATCHES = %0d", checks-failures);
        $display("FIRST_MISMATCH = %0d", first_mismatch);

        if (failures == 0 && valid_failures == 0)
            $display("INT2_CONV1_RTL_QUANT_EXACT_PASS");
        else
            $display("INT2_CONV1_RTL_QUANT_MISMATCH");

        $finish;
    end

endmodule
