
`timescale 1ns/1ps

module tb_int2_conv1_multi_rtl;

    logic clk_i = 0;
    logic clk_i_fast = 0;

    always #10 clk_i = ~clk_i;
    always #5 clk_i_fast = ~clk_i_fast;

    logic rstn_i = 0;
    logic bias_in = 0;
    logic valid_in = 0;
    logic get_res = 0;

    logic [31:0] bias_shift_mode = 0;
    logic [31:0] weights = 0;
    logic [31:0] input_val = 0;
    logic [31:0] out_mul_vals = 0;
    logic [31:0] out_shift_rl = 0;

    wire [16:0] weights_out[4];
    wire [16:0] act_out[4];

    logic [31:0] par_prods_in[4];

    wire [31:0] output_val;
    wire valid_out;
    wire compressed_valid;

    neural_unit dut (
        .clk_i(clk_i),
        .clk_i_fast(clk_i_fast),
        .rstn_i(rstn_i),
        .bias_in(bias_in),
        .valid_in(valid_in),
        .get_res(get_res),
        .bias_shift_mode(bias_shift_mode),
        .weights(weights),
        .input_val(input_val),
        .out_mul_vals(out_mul_vals),
        .out_shift_rl(out_shift_rl),
        .par_prods_in(par_prods_in),
        .weights_out(weights_out),
        .act_out(act_out),
        .output_val(output_val),
        .valid_out(valid_out),
        .compressed_valid(compressed_valid)
    );

    // External multipliers used by the original RTL.
    always_comb begin
        for (int i = 0; i < 4; i++) begin
            par_prods_in[i] =
                {15'b0, weights_out[i]} *
                {15'b0, act_out[i]};
        end
    end


    integer mab_pulses = 0;

    always @(negedge clk_i) begin
        if (!rstn_i)
            mab_pulses = 0;
        else if (dut.mab_valid)
            mab_pulses = mab_pulses + 1;
    end


    initial begin : multi_filter_test
        reg [31:0] wmem [0:11];
        reg [7:0] amem [0:117599];
        reg [31:0] emem [0:4703];

        integer signed biases [0:5];
        integer f, p, idx, k, selected;
        integer signed w, a, ref_sum;
        integer signed expected, actual;
        integer pulses_before;
        integer pass_count, fail_count;
        reg [1:0] wbits;

        biases[0] = 24;
        biases[1] = 11;
        biases[2] = 6;
        biases[3] = -8;
        biases[4] = 74;
        biases[5] = 19;

        $readmemh(
            "C:/Users/admin/int2_conv1_test/int2_conv1_weights_rtl.mem",
            wmem
        );
        $readmemh(
            "C:/Users/admin/int2_conv1_test/int2_conv1_activations.mem",
            amem
        );
        $readmemh(
            "C:/Users/admin/int2_conv1_test/int2_conv1_expected_mac.mem",
            emem
        );

        pass_count = 0;
        fail_count = 0;

        $display("CONV1_MULTI_RTL_START");

        for (f = 0; f < 6; f = f + 1) begin

            // Select a nontrivial output with a matching C reference
            selected = -1;

            for (p = 0; p < 784; p = p + 1) begin
                idx = f*784 + p;
                ref_sum = biases[f];

                for (k = 0; k < 25; k = k + 1) begin
                    wbits = (wmem[f*2 + k/16]
                             >> (30 - 2*(k%16))) & 3;

                    w = (wbits >= 2)
                        ? (integer'(wbits) - 4)
                        : integer'(wbits);

                    a = amem[idx*25+k];
                    ref_sum = ref_sum + w*a;
                end

                if (selected == -1 &&
                    ref_sum == $signed(emem[idx]) &&
                    ref_sum != biases[f])
                    selected = idx;
            end

            if (selected == -1) begin
                $display("FILTER=%0d NO_VALID_CASE", f);
                fail_count = fail_count + 1;
            end
            else begin
                idx = selected;
                expected = $signed(emem[idx]);

                // Reset before each output
                @(negedge clk_i);
                rstn_i = 0;
                bias_in = 0;
                valid_in = 0;
                weights = 0;
                input_val = 0;

                repeat (5) @(negedge clk_i);
                rstn_i = 1;

                // Load bias into lane 3
                @(negedge clk_i);
                bias_in = 1;
                weights = {24'b0, biases[f][7:0]};
                bias_shift_mode = 32'h00000003;

                @(negedge clk_i);
                bias_in = 0;

                #1;
                pulses_before = mab_pulses;

                // Process 25 INT2 elements
                for (k = 0; k < 25; k = k + 1) begin
                    wbits = (wmem[f*2 + k/16]
                             >> (30 - 2*(k%16))) & 3;

                    a = amem[idx*25+k];

                    @(negedge clk_i);
                    weights = {2'b00, wbits, 28'b0};
                    input_val = {a[7:0], 24'b0};
                    valid_in = 1;

                    @(negedge clk_i);
                    valid_in = 0;
                    weights = 0;
                    input_val = 0;

                    repeat (14) @(negedge clk_i);
                end

                #1;
                actual = $signed(dut.out_reg[3]);

                if (actual == expected &&
                    mab_pulses - pulses_before == 25) begin

                    pass_count = pass_count + 1;
                    $display(
                        "FILTER=%0d INDEX=%0d EXPECTED=%0d ACTUAL=%0d PULSES=%0d PASS",
                        f, idx, expected, actual,
                        mab_pulses - pulses_before
                    );
                end
                else begin
                    fail_count = fail_count + 1;
                    $display(
                        "FILTER=%0d INDEX=%0d EXPECTED=%0d ACTUAL=%0d PULSES=%0d FAIL",
                        f, idx, expected, actual,
                        mab_pulses - pulses_before
                    );
                end
            end
        end

        $display("================================");
        $display("CONV1_MULTI_RTL_REPORT");
        $display("TOTAL_FILTERS = 6");
        $display("PASS_COUNT = %0d", pass_count);
        $display("FAIL_COUNT = %0d", fail_count);

        if (pass_count == 6)
            $display("CONV1_MULTI_RTL_PASS");
        else
            $display("CONV1_MULTI_RTL_FAIL");

        $display("================================");
        $finish;
    end

endmodule
