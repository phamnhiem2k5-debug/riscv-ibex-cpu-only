
`timescale 1ns/1ps

module tb_int2_mab_pipeline;

    logic clk_i = 0;
    logic clk_i_fast = 0;
    logic rst_ni = 0;
    logic enable = 0;

    logic [1:0] iteration = 0;
    logic [2:0] mode = 3'b011;
    logic [31:0] weights_dec = 0;
    logic [31:0] input_vals = 32'h01020304;

    wire [16:0] weight_vals [8];
    wire [16:0] activations [8];

    wire [16:0] weights_out [4];
    wire [16:0] act_out [4];

    logic [31:0] par_prods_in [4];
    wire [31:0] results [4];

    wire occupied;
    wire valid_out;

    logic [31:0] weights_mem [0:11];

    integer valid_count = 0;
    integer unknown_count = 0;

    // Slow clock: 20 ns
    always #10 clk_i = ~clk_i;

    // Fast clock: 10 ns
    always #5 clk_i_fast = ~clk_i_fast;

    neur_decoder DEC (
        .iteration(iteration),
        .mode(mode),
        .weights_dec(weights_dec),
        .input_vals(input_vals),
        .weight_vals(weight_vals),
        .activations(activations)
    );

    mul_add_block MAB (
        .rst_ni(rst_ni),
        .clk_i(clk_i),
        .clk_i_fast(clk_i_fast),
        .enable(enable),
        .weight_vals(weight_vals),
        .activations(activations),
        .mode(mode[1:0]),
        .par_prods_in(par_prods_in),
        .weights_out(weights_out),
        .act_out(act_out),
        .results(results),
        .occupied(occupied),
        .valid_out(valid_out)
    );

    // External signed multiplication
    always_comb begin
        for (int i = 0; i < 4; i++) begin
            par_prods_in[i] =
                $signed(weights_out[i]) *
                $signed(act_out[i]);
        end
    end

    // Monitor outputs after nonblocking updates settle
    always @(negedge clk_i) begin
        if (rst_ni) begin
            $display(
                "TIME=%0t enable=%b occupied=%b valid=%b R=%0d,%0d,%0d,%0d",
                $time,
                enable,
                occupied,
                valid_out,
                $signed(results[0]),
                $signed(results[1]),
                $signed(results[2]),
                $signed(results[3])
            );

            if (valid_out === 1'b1) begin
                valid_count++;

                for (int i = 0; i < 4; i++) begin
                    if ($isunknown(results[i]))
                        unknown_count++;
                end
            end
        end
    end

    initial begin
        $readmemh(
            "C:/Users/admin/int2_conv1_test/int2_conv1_weights_rtl.mem",
            weights_mem
        );

        weights_dec = weights_mem[0];

        $display("==================================");
        $display(" INT2 MAB PIPELINE TEST");
        $display("==================================");

        // Release reset away from clock edges
        #23;
        rst_ni = 1;

        // Apply one slow-clock-wide enable pulse
        @(negedge clk_i);
        enable = 1;

        @(negedge clk_i);
        enable = 0;

        // Allow pipeline to complete
        repeat (12) @(negedge clk_i);

        $display("==================================");
        $display(" INT2 MAB PIPELINE REPORT");
        $display("==================================");

        $display("VALID_COUNT = %0d", valid_count);
        $display("UNKNOWN_COUNT = %0d", unknown_count);

        if (valid_count > 0 && unknown_count == 0)
            $display("INT2_MAB_PIPELINE_HANDSHAKE_PASS");
        else
            $display("INT2_MAB_PIPELINE_HANDSHAKE_FAIL");

        $finish;
    end

endmodule
