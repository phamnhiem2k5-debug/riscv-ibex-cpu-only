
`timescale 1ns/1ps

module tb_int2_conv1_c_compare;

    // =========================================================
    // CONFIGURATION
    // =========================================================

    localparam integer FILTERS     = 6;
    localparam integer POSITIONS   = 784;
    localparam integer OUTPUTS     = 4704;
    localparam integer KERNEL_SIZE = 25;
    localparam integer WEIGHT_WORDS = 12;
    localparam integer ACTIVATION_COUNT = 117600;

    // 0: Filter-major output indexing
    // 1: Pixel-major output indexing
    localparam integer PIXEL_MAJOR = 0;

    // =========================================================
    // REFERENCE MEMORIES
    // =========================================================

    logic [31:0] weights_mem [0:WEIGHT_WORDS-1];

    logic [7:0] activation_mem [0:ACTIVATION_COUNT-1];

    logic [31:0] expected_mac_mem [0:OUTPUTS-1];

    // =========================================================
    // DECODER SIGNALS
    // =========================================================

    logic [1:0] iteration;
    logic [2:0] mode;
    logic [31:0] weights_dec;
    logic [31:0] input_vals;

    wire [16:0] weight_vals [8];
    wire [16:0] activations [8];

    // =========================================================
    // TEST VARIABLES
    // =========================================================

    integer bias [0:FILTERS-1];
    integer kernel_weights [0:KERNEL_SIZE-1];
    integer lane_idx [0:7];

    integer checks;
    integer failures;
    integer decoder_checks;
    integer decoder_failures;
    integer mac_checks;
    integer mac_failures;

    integer output_index;
    integer activation_index;

    integer mac;
    integer expected_mac;

    integer first_mac;
    integer first_expected;

    // =========================================================
    // REAL RTL DECODER
    // =========================================================

    neur_decoder DUT (
        .iteration(iteration),
        .mode(mode),
        .weights_dec(weights_dec),
        .input_vals(input_vals),
        .weight_vals(weight_vals),
        .activations(activations)
    );

    // =========================================================
    // SIGNED INT2 REFERENCE UNPACKER
    //
    // RTL packing:
    // position 0 -> bits [31:30]
    // position 1 -> bits [29:28]
    // ...
    // position 15 -> bits [1:0]
    // =========================================================

    function automatic integer signed_int2(
        input logic [31:0] word,
        input integer position
    );

        logic [1:0] bits2;

        begin
            bits2 = (word >> (30 - 2*position)) & 2'b11;

            case (bits2)
                2'b00: signed_int2 = 0;
                2'b01: signed_int2 = 1;
                2'b10: signed_int2 = -2;
                2'b11: signed_int2 = -1;
                default: signed_int2 = 0;
            endcase
        end

    endfunction

    // =========================================================
    // SIGN EXTEND 12 BITS
    // =========================================================

    function automatic integer signed12(
        input logic [11:0] value
    );

        begin
            if (value[11])
                signed12 = integer'(value) - 4096;
            else
                signed12 = integer'(value);
        end

    endfunction

    // =========================================================
    // VERIFY REAL RTL DECODER
    // =========================================================

    task automatic check_decoder_word(
        input integer word_index
    );

        integer hi;
        integer lo;

        integer packed_value;
        integer actual_low;
        integer actual_high;

        begin

            weights_dec = weights_mem[word_index];

            #1;

            for (integer lane = 0; lane < 8; lane++) begin

                hi = signed_int2(
                    weights_mem[word_index],
                    lane_idx[lane]-1
                );

                lo = signed_int2(
                    weights_mem[word_index],
                    lane_idx[lane]
                );

                packed_value = $signed(weight_vals[lane]);

                actual_low = signed12(
                    weight_vals[lane][11:0]
                );

                actual_high =
                    (packed_value - actual_low) / 4096;

                decoder_checks += 2;

                if (actual_low !== lo) begin

                    decoder_failures++;

                    if (decoder_failures <= 10)
                        $display(
                            "DECODER_LOW_FAIL word=%0d lane=%0d got=%0d expected=%0d",
                            word_index,
                            lane,
                            actual_low,
                            lo
                        );

                end

                if (actual_high !== hi) begin

                    decoder_failures++;

                    if (decoder_failures <= 10)
                        $display(
                            "DECODER_HIGH_FAIL word=%0d lane=%0d got=%0d expected=%0d",
                            word_index,
                            lane,
                            actual_high,
                            hi
                        );

                end

            end

        end

    endtask

    // =========================================================
    // LOAD 25 WEIGHTS FOR ONE FILTER
    //
    // Each filter occupies 2 words = 32 INT2 slots.
    // Only first 25 weights are used.
    // =========================================================

    task automatic load_kernel(
        input integer filter_index
    );

        integer word_index;
        integer position;

        begin

            for (integer k = 0; k < KERNEL_SIZE; k++) begin

                word_index = filter_index*2 + k/16;
                position   = k%16;

                kernel_weights[k] = signed_int2(
                    weights_mem[word_index],
                    position
                );

            end

        end

    endtask

    // =========================================================
    // COMPUTE AND COMPARE ONE MAC
    // =========================================================

    task automatic check_one_output(
        input integer filter_index,
        input integer position_index
    );

        begin

            if (PIXEL_MAJOR != 0)
                output_index =
                    position_index*FILTERS + filter_index;
            else
                output_index =
                    filter_index*POSITIONS + position_index;

            load_kernel(filter_index);

            mac = bias[filter_index];

            for (integer k = 0; k < KERNEL_SIZE; k++) begin

                activation_index =
                    output_index*KERNEL_SIZE + k;

                mac = mac +
                    kernel_weights[k] *
                    integer'(activation_mem[activation_index]);

            end

            expected_mac = $signed(
                expected_mac_mem[output_index]
            );

            mac_checks++;

            if (mac !== expected_mac) begin

                mac_failures++;

                if (mac_failures <= 20) begin

                    $display(
                        "MAC_FAIL filter=%0d pos=%0d output=%0d RTL_MODEL=%0d C_EXPECTED=%0d",
                        filter_index,
                        position_index,
                        output_index,
                        mac,
                        expected_mac
                    );

                end

            end

            if (output_index == 0) begin

                first_mac = mac;
                first_expected = expected_mac;

                $display(
                    "FIRST_MAC = %0d",
                    first_mac
                );

                $display(
                    "FIRST_C_EXPECTED = %0d",
                    first_expected
                );

                if (first_mac == first_expected)
                    $display("FIRST_MAC_PASS");
                else
                    $display("FIRST_MAC_FAIL");

            end

        end

    endtask

    // =========================================================
    // MAIN TEST
    // =========================================================

    initial begin

        checks = 0;
        failures = 0;

        decoder_checks = 0;
        decoder_failures = 0;

        mac_checks = 0;
        mac_failures = 0;

        first_mac = 0;
        first_expected = 0;

        iteration = 0;
        mode = 3'b011;

        weights_dec = 0;
        input_vals = 32'h01020304;

        // Decoder lane mapping
        lane_idx[0] = 1;
        lane_idx[1] = 5;
        lane_idx[2] = 9;
        lane_idx[3] = 13;
        lane_idx[4] = 3;
        lane_idx[5] = 7;
        lane_idx[6] = 11;
        lane_idx[7] = 15;

        // Real CONV1 bias values
        bias[0] = 24;
        bias[1] = 11;
        bias[2] = 6;
        bias[3] = -8;
        bias[4] = 74;
        bias[5] = 19;

        // =====================================================
        // LOAD MEMORIES
        // =====================================================

        $readmemh(
            "C:/Users/admin/int2_conv1_test/int2_conv1_weights_rtl.mem",
            weights_mem
        );

        $readmemh(
            "C:/Users/admin/int2_conv1_test/int2_conv1_activations.mem",
            activation_mem
        );

        $readmemh(
            "C:/Users/admin/int2_conv1_test/int2_conv1_expected_mac.mem",
            expected_mac_mem
        );

        $display("");
        $display("==========================================");
        $display(" INT2 CONV1 FULL C REFERENCE TEST");
        $display("==========================================");

        $display("FILTERS = %0d", FILTERS);
        $display("POSITIONS = %0d", POSITIONS);
        $display("KERNEL_SIZE = %0d", KERNEL_SIZE);
        $display("OUTPUTS = %0d", OUTPUTS);
        $display("TEST_MODE = FULL_CONV1");

        if (PIXEL_MAJOR != 0)
            $display("OUTPUT_LAYOUT = PIXEL_MAJOR");
        else
            $display("OUTPUT_LAYOUT = FILTER_MAJOR");

        // =====================================================
        // TEST 1: DECODER
        // =====================================================

        $display("");
        $display("TEST_1 = RTL_DECODER");

        for (integer w = 0; w < WEIGHT_WORDS; w++) begin
            check_decoder_word(w);
        end

        $display(
            "DECODER_CHECKS = %0d",
            decoder_checks
        );

        $display(
            "DECODER_FAILURES = %0d",
            decoder_failures
        );

        if (decoder_failures == 0)
            $display("DECODER_PASS");
        else
            $display("DECODER_FAIL");

        // =====================================================
        // PRINT FIRST KERNEL
        // =====================================================

        load_kernel(0);

        $write("FIRST_KERNEL = ");

        for (integer k = 0; k < KERNEL_SIZE; k++) begin
            $write("%0d ", kernel_weights[k]);
        end

        $display("");

        $display(
            "FIRST_BIAS = %0d",
            bias[0]
        );

        // =====================================================
        // TEST 2: ALL 4704 MAC VALUES
        // =====================================================

        $display("");
        $display("TEST_2 = FULL_CONV1_MAC");

        for (integer f = 0; f < FILTERS; f++) begin

            for (integer p = 0; p < POSITIONS; p++) begin

                check_one_output(f, p);

            end

            $display(
                "FILTER_%0d_DONE MAC_CHECKS=%0d MAC_FAILURES=%0d",
                f,
                mac_checks,
                mac_failures
            );

        end

        // =====================================================
        // FINAL REPORT
        // =====================================================

        checks = decoder_checks + mac_checks;

        failures = decoder_failures + mac_failures;

        $display("");
        $display("==========================================");
        $display(" INT2 CONV1 FULL C COMPARE REPORT");
        $display("==========================================");

        $display(
            "DECODER_CHECKS = %0d",
            decoder_checks
        );

        $display(
            "DECODER_FAILURES = %0d",
            decoder_failures
        );

        $display(
            "MAC_CHECKS = %0d",
            mac_checks
        );

        $display(
            "MAC_FAILURES = %0d",
            mac_failures
        );

        $display(
            "TOTAL_CHECKS = %0d",
            checks
        );

        $display(
            "TOTAL_FAILURES = %0d",
            failures
        );

        $display(
            "TOTAL_PASSED = %0d",
            checks - failures
        );

        if (failures == 0) begin

            $display("INT2_CONV1_FULL_C_COMPARE_PASS");

        end
        else begin

            $display("INT2_CONV1_FULL_C_COMPARE_FAIL");

        end

        $display("==========================================");

        $finish;

    end

endmodule
