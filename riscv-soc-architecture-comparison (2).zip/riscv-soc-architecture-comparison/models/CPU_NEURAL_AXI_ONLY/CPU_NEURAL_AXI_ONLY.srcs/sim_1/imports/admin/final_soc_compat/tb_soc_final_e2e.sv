
`timescale 1ns/1ps

module tb_soc_final_e2e;

    localparam [31:0] BASE = 32'h00040000;
    localparam [31:0] END_PC = 32'h0010013C;

    // Regression reference: observed, not independent golden
    localparam [31:0] EXPECTED = 32'h24042904;

    localparam integer TIMEOUT = 20000;

    reg clk = 0;
    reg rst_n = 0;

    always #10 clk = ~clk;

    wire [31:0] debug_pc;
    wire debug_instr_req;
    wire [31:0] debug_cpu_addr;
    wire [31:0] debug_cpu_wdata;
    wire [31:0] debug_neural_rdata;
    wire debug_neural_rvalid;

    ibex_simple_system_neural_synth dut (
        .IO_CLK(clk),
        .IO_CLK_FAST(clk),
        .IO_RST_N(rst_n),
        .DEBUG_PC(debug_pc),
        .DEBUG_INSTR_REQ(debug_instr_req),
        .DEBUG_CPU_ADDR(debug_cpu_addr),
        .DEBUG_CPU_WDATA(debug_cpu_wdata),
        .DEBUG_NEURAL_RDATA(debug_neural_rdata),
        .DEBUG_NEURAL_RVALID(debug_neural_rvalid)
    );

    integer cycles = 0;
    integer errors = 0;
    integer writes = 0;
    integer reads = 0;
    integer status_reads = 0;
    integer result_reads = 0;
    integer result_responses = 0;
    integer end_cycles = 0;

    reg fetch_seen = 0;
    reg result_pending = 0;
    reg result_match = 0;
    reg finished = 0;

    reg [31:0] actual = 0;

    function automatic [31:0] exp_addr(input integer i);
        case (i)
            0: exp_addr = BASE + 'h10;
            1: exp_addr = BASE + 'h08;
            2: exp_addr = BASE + 'h00;
            3: exp_addr = BASE + 'h08;
            4: exp_addr = BASE + 'h0C;
            5: exp_addr = BASE + 'h14;
            6: exp_addr = BASE + 'h18;
            7: exp_addr = BASE + 'h00;
            8: exp_addr = BASE + 'h00;
            default: exp_addr = 'x;
        endcase
    endfunction

    function automatic [31:0] exp_data(input integer i);
        case (i)
            0: exp_data = 32'h00000003;
            1: exp_data = 32'h05000000;
            2: exp_data = 32'h00000001;
            3: exp_data = 32'h55555555;
            4: exp_data = 32'h01010101;
            5: exp_data = 32'h01010101;
            6: exp_data = 32'h00000000;
            7: exp_data = 32'h00000002;
            8: exp_data = 32'h00000004;
            default: exp_data = 'x;
        endcase
    endfunction

    task automatic summary;
        begin
            $display("======================================");
            $display("FINAL SOC END-TO-END REPORT");
            $display("======================================");
            $display("CYCLES           = %0d", cycles);
            $display("CPU_FETCH        = %0d", fetch_seen);
            $display("NEURAL_WRITES    = %0d", writes);
            $display("NEURAL_READS     = %0d", reads);
            $display("STATUS_READS     = %0d", status_reads);
            $display("RESULT_READS     = %0d", result_reads);
            $display("RESULT_RESPONSES = %0d", result_responses);
            $display("END_PC_CYCLES    = %0d", end_cycles);
            $display("EXPECTED         = %08h", EXPECTED);
            $display("ACTUAL           = %08h", actual);
            $display("ERRORS           = %0d", errors);
            $display("======================================");
        end
    endtask

    always @(posedge clk) begin
        if (rst_n && !finished) begin

            cycles = cycles + 1;

            if (debug_instr_req === 1'b1)
                fetch_seen = 1;

            if (debug_pc === END_PC)
                end_cycles = end_cycles + 1;

            // Accepted transactions only
            if (dut.device_req[3] === 1'b1 &&
                dut.device_gnt[3] === 1'b1) begin

                if (dut.device_addr[3][31:12] !== BASE[31:12]) begin
                    $display("FAIL: ADDRESS RANGE");
                    errors = errors + 1;
                end

                if (dut.device_we[3] === 1'b1) begin

                    if (writes >= 9 ||
                        dut.device_addr[3] !== exp_addr(writes) ||
                        dut.device_wdata[3] !== exp_data(writes)) begin

                        $display(
                            "FAIL WRITE[%0d] addr=%08h data=%08h",
                            writes,
                            dut.device_addr[3],
                            dut.device_wdata[3]
                        );

                        errors = errors + 1;
                    end

                    writes = writes + 1;

                end else if (dut.device_we[3] === 1'b0) begin

                    reads = reads + 1;

                    if (dut.device_addr[3] === BASE + 'h04)
                        status_reads = status_reads + 1;

                    else if (dut.device_addr[3] === BASE + 'h2C) begin
                        result_reads = result_reads + 1;
                        result_pending = 1;
                    end else begin
                        $display("FAIL: UNEXPECTED READ");
                        errors = errors + 1;
                    end

                end else begin
                    $display("FAIL: UNKNOWN WE");
                    errors = errors + 1;
                end
            end

            if (dut.device_rvalid[3] === 1'b1 &&
                result_pending) begin

                result_pending = 0;
                result_responses = result_responses + 1;
                actual = dut.device_rdata[3];

                if (dut.device_err[3] !== 1'b0) begin
                    $display("FAIL: BUS RESPONSE ERROR");
                    errors = errors + 1;
                end

                if (actual !== EXPECTED) begin
                    $display(
                        "FAIL RESULT expected=%08h actual=%08h",
                        EXPECTED, actual
                    );
                    errors = errors + 1;
                end else begin
                    result_match = 1;
                end
            end

            if (result_responses > 0 && end_cycles >= 3) begin

                finished = 1;
                summary();

                if (!fetch_seen ||
                    writes != 9 ||
                    status_reads == 0 ||
                    result_reads != 1 ||
                    result_responses != 1 ||
                    !result_match ||
                    errors != 0) begin

                    $fatal(1, "FINAL_SOC_E2E_FAIL");

                end else begin

                    $display("FINAL_SOC_E2E_REGRESSION_PASS");
                    $finish;
                end
            end

            if (cycles >= TIMEOUT) begin
                finished = 1;
                summary();
                $fatal(1, "FINAL_SOC_E2E_FAIL_TIMEOUT");
            end
        end
    end

    initial begin
        repeat (10) @(negedge clk);
        rst_n = 1'b1;
    end

endmodule

