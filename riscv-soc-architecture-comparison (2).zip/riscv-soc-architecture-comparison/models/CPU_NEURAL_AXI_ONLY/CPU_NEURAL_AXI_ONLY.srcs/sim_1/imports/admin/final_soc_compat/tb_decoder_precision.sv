
`timescale 1ns/1ps

module tb_decoder_precision;

    logic [1:0] iteration;
    logic [2:0] mode;
    logic [31:0] weights_dec;
    logic [31:0] input_vals;

    logic [16:0] weight_vals[8];
    logic [16:0] activations[8];

    integer passed = 0;
    integer failed = 0;

    neur_decoder dut (
        .iteration(iteration),
        .mode(mode),
        .weights_dec(weights_dec),
        .input_vals(input_vals),
        .weight_vals(weight_vals),
        .activations(activations)
    );

    task automatic check_value(
        input string label,
        input logic signed [16:0] actual,
        input logic signed [16:0] expected
    );
        if (actual === expected) begin
            passed++;
            $display("PASS %s actual=%0d", label, actual);
        end else begin
            failed++;
            $display("FAIL %s actual=%0d expected=%0d",
                     label, actual, expected);
        end
    endtask

    initial begin
        iteration = 0;
        weights_dec = 0;
        input_vals = 0;
        mode = 0;
        #1;

        // INT8: weights = -5, 3, -8, 7
        mode = 3'b001;
        weights_dec = 32'hFB03F807;
        input_vals = 32'h01020304;
        #1;

        check_value("INT8_W0", $signed(weight_vals[0]), -17'sd5);
        check_value("INT8_W2", $signed(weight_vals[2]), 17'sd3);
        check_value("INT8_W4", $signed(weight_vals[4]), -17'sd8);
        check_value("INT8_W6", $signed(weight_vals[6]), 17'sd7);

        // INT4: weights = -8, -1, 3, 7, ...
        mode = 3'b010;
        weights_dec = 32'h8F370000;
        #1;

        check_value("INT4_W0", $signed(weight_vals[0]), -17'sd8);
        check_value("INT4_W2", $signed(weight_vals[2]), -17'sd1);
        check_value("INT4_W4", $signed(weight_vals[4]), 17'sd3);
        check_value("INT4_W6", $signed(weight_vals[6]), 17'sd7);

        // INT2 special encoding:
        // Check decoded values against the RTL representation.
        mode = 3'b011;
        weights_dec = 32'h00000000;
        input_vals = 32'h00000000;
        #1;

        check_value("INT2_ZERO_W0", $signed(weight_vals[0]), 17'sd0);
        check_value("INT2_ZERO_W1", $signed(weight_vals[1]), 17'sd0);

        $display("================================");
        $display("DECODER_PASSED = %0d", passed);
        $display("DECODER_FAILED = %0d", failed);
        $display("================================");

        $finish;
    end

endmodule

