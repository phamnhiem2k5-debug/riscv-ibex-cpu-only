`ifndef DV_FCOV_MACROS_SVH
`define DV_FCOV_MACROS_SVH
`define DV_FCOV_SIGNAL(type, name, expr)
`define DV_FCOV_SIGNAL_GEN_IF(type, name, expr, cond)
`endif
