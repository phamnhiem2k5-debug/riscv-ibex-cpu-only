
`timescale 1ns/1ps

module tb_int2_mac_sweep;

    logic clk = 0;
    logic rst_ni = 0;
    logic enable = 0;

    logic [1:0] iteration = 0;
    logic [2:0] mode = 3'b111;
    logic [31:0] weights_dec = 0;
    logic [31:0] input_vals = 0;

    logic [16:0] weight_vals[8];
    logic [16:0] activations[8];

    logic [16:0] weights_out[4];
    logic [16:0] act_out[4];

    logic [31:0] par_prods_in[4];
    logic [31:0] results[4];

    logic occupied;
    logic valid_out;

    integer cases_completed = 0;
    integer missing_valid = 0;

    always #5 clk = ~clk;

    neur_decoder decoder (
        .iteration(iteration),
        .mode(mode),
        .weights_dec(weights_dec),
        .input_vals(input_vals),
        .weight_vals(weight_vals),
        .activations(activations)
    );

    for (genvar i = 0; i < 4; i++) begin : MULTIPLIERS
        assign par_prods_in[i] =
            $signed(weights_out[i]) * $signed(act_out[i]);
    end

    mul_add_block mac (
        .rst_ni(rst_ni),
        .clk_i(clk),
        .clk_i_fast(clk),
        .enable(enable),
        .weight_vals(weight_vals),
        .activations(activations),
        .mode(mode[1:0]),
        .par_prods_in(par_prods_in),
        .weights_out(weights_out),
        .act_out(act_out),
        .results(results),
        .occupied(occupied),
        .valid_out(valid_out)
    );

    function automatic integer signed_int2(input integer code);
        case (code)
            0: signed_int2 = 0;
            1: signed_int2 = 1;
            2: signed_int2 = -2;
            3: signed_int2 = -1;
            default: signed_int2 = 0;
        endcase
    endfunction

    task automatic run_case(
        input integer code,
        input integer activation
    );
        logic [31:0] packed_weights;
        logic [7:0] a8;
        logic [31:0] captured[4];
        bit found_valid;
        integer expected_product;

        begin
            packed_weights = 0;

            for (int i = 0; i < 16; i++) begin
                packed_weights[2*i +: 2] = code[1:0];
            end

            a8 = activation[7:0];

            @(negedge clk);
            rst_ni = 0;
            enable = 0;

            repeat (3) @(negedge clk);

            weights_dec = packed_weights;
            input_vals = {a8, a8, a8, a8};
            iteration = 0;

            rst_ni = 1;

            @(negedge clk);
            enable = 1;

            @(negedge clk);
            enable = 0;

            found_valid = 0;

            for (int cycle = 0; cycle < 12; cycle++) begin
                @(negedge clk);

                if (valid_out && !found_valid) begin
                    found_valid = 1;

                    for (int i = 0; i < 4; i++) begin
                        captured[i] = results[i];
                    end
                end
            end

            expected_product = signed_int2(code) * activation;

            if (found_valid) begin
                cases_completed++;

                $display(
                    "INT2_CASE CODE=%0d W=%0d A=%0d EXPECTED_PRODUCT=%0d",
                    code,
                    signed_int2(code),
                    activation,
                    expected_product
                );

                $display(
                    "MAC_RESULTS=%0d,%0d,%0d,%0d",
                    $signed(captured[0]),
                    $signed(captured[1]),
                    $signed(captured[2]),
                    $signed(captured[3])
                );

            end else begin
                missing_valid++;

                $display(
                    "INT2_NO_VALID CODE=%0d A=%0d",
                    code, activation
                );
            end
        end
    endtask

    initial begin
        repeat (2) @(negedge clk);

        for (int code = 0; code < 4; code++) begin
            run_case(code, 3);
            run_case(code, -3);
        end

        $display("================================");
        $display("INT2_CASES_COMPLETED=%0d", cases_completed);
        $display("INT2_MISSING_VALID=%0d", missing_valid);
        $display("================================");

        $finish;
    end

endmodule

