
`timescale 1ns/1ps

module tb_int2_decoder;

    // =====================================================
    // 1. SIGNALS
    // =====================================================

    logic [1:0] iteration;
    logic [2:0] mode;

    logic [31:0] weights_dec;
    logic [31:0] input_vals;

    wire [16:0] weight_vals [8];
    wire [16:0] activations [8];

    logic [31:0] weights_mem [0:11];

    integer idx [0:7];

    integer checks;
    integer failures;
    integer expected_weight;
    integer expected_act;

    // =====================================================
    // 2. DUT
    // =====================================================

    neur_decoder dut (
        .iteration   (iteration),
        .mode        (mode),
        .weights_dec (weights_dec),
        .input_vals  (input_vals),
        .weight_vals (weight_vals),
        .activations (activations)
    );

    // =====================================================
    // 3. EXTRACT SIGNED INT2 WEIGHT
    //
    // pos = 0: bits [31:30]
    // pos = 1: bits [29:28]
    // ...
    // pos = 15: bits [1:0]
    // =====================================================

    function automatic integer get_w2(
        input logic [31:0] word,
        input integer pos
    );
        logic [1:0] bits;

        begin
            bits = (word >> (30 - 2*pos)) & 2'b11;

            case (bits)
                2'b00: get_w2 = 0;
                2'b01: get_w2 = 1;
                2'b10: get_w2 = -2;
                2'b11: get_w2 = -1;
                default: get_w2 = 0;
            endcase
        end
    endfunction

    // =====================================================
    // 4. MAIN TEST
    // =====================================================

    initial begin

        checks = 0;
        failures = 0;

        // ---------------------------------------------
        // RTL INT2 LANE MAPPING
        // Each lane combines:
        //   weight[idx] + weight[idx-1] * 4096
        // ---------------------------------------------

        idx[0] = 1;
        idx[1] = 5;
        idx[2] = 9;
        idx[3] = 13;

        idx[4] = 3;
        idx[5] = 7;
        idx[6] = 11;
        idx[7] = 15;

        // ---------------------------------------------
        // LOAD REAL CONV1 WEIGHTS
        // ---------------------------------------------

        $readmemh(
            "C:/Users/admin/int2_conv1_test/int2_conv1_weights_rtl.mem",
            weights_mem
        );

        // ---------------------------------------------
        // INT2 + UNSIGNED ACTIVATIONS
        // mode[1:0] = 11 -> INT2
        // mode[2]   = 0  -> UINT8
        // ---------------------------------------------

        mode = 3'b011;
        iteration = 2'b00;

        // Input bytes:
        // input_values[0] = 1
        // input_values[1] = 2
        // input_values[2] = 3
        // input_values[3] = 4

        input_vals = 32'h01020304;
        weights_dec = 32'h00000000;

        #2;

        $display("======================================");
        $display(" REAL INT2 CONV1 DECODER TEST");
        $display("======================================");

        // ---------------------------------------------
        // CHECK FIRST WORD
        // ---------------------------------------------

        if (weights_mem[0] !== 32'h00014040) begin
            failures++;

            $display(
                "FAIL FIRST_WEIGHT_WORD got=%h exp=00014040",
                weights_mem[0]
            );
        end
        else begin
            $display("FIRST_WEIGHT_WORD_PASS");
        end

        // ---------------------------------------------
        // TEST ALL 12 WORDS
        // ---------------------------------------------

        for (int k = 0; k < 12; k++) begin

            weights_dec = weights_mem[k];

            #2;

            for (int i = 0; i < 8; i++) begin

                // -------------------------------------
                // EXPECTED INT2 PACKED WEIGHT
                // -------------------------------------

                expected_weight =
                    get_w2(weights_mem[k], idx[i])
                    + 4096 *
                      get_w2(weights_mem[k], idx[i]-1);

                checks++;

                if ($signed(weight_vals[i]) !== expected_weight) begin

                    failures++;

                    $display(
                        "FAIL WEIGHT word=%0d lane=%0d got=%0d exp=%0d",
                        k,
                        i,
                        $signed(weight_vals[i]),
                        expected_weight
                    );

                end

                // -------------------------------------
                // EXPECTED UINT8 ACTIVATION
                //
                // RTL:
                // {2'b01, 5'b0, input_values[x][9:0]}
                //
                // = 32768 + input
                // -------------------------------------

                expected_act = 32768 + 1 + (i % 4);

                checks++;

                if (activations[i] !== expected_act) begin

                    failures++;

                    $display(
                        "FAIL ACT word=%0d lane=%0d got=%0d exp=%0d",
                        k,
                        i,
                        activations[i],
                        expected_act
                    );

                end

            end
        end

        // =================================================
        // 5. FINAL REPORT
        // =================================================

        $display("");
        $display("======================================");
        $display(" INT2 DECODER FINAL REPORT");
        $display("======================================");

        $display("TOTAL_CHECKS = %0d", checks);
        $display("TOTAL_FAILURES = %0d", failures);
        $display("TOTAL_PASSED = %0d", checks - failures);

        $display(
            "INT2_DECODER_CHECKS=%0d FAILURES=%0d",
            checks,
            failures
        );

        if (failures == 0) begin

            $display("INT2_DECODER_PASS");

        end
        else begin

            $display("INT2_DECODER_FAIL");
            $fatal(1, "INT2 decoder mismatch");

        end

        $finish;

    end

endmodule
