
`timescale 1ns/1ps

module tb_int2_diagnostic;

    logic [1:0] iteration;
    logic [2:0] mode;
    logic [31:0] weights_dec;
    logic [31:0] input_vals;

    logic [16:0] weight_vals[8];
    logic [16:0] activations[8];

    neur_decoder dut (
        .iteration(iteration),
        .mode(mode),
        .weights_dec(weights_dec),
        .input_vals(input_vals),
        .weight_vals(weight_vals),
        .activations(activations)
    );

    task automatic show_case(
        input string name,
        input logic [31:0] w,
        input logic [31:0] a
    );
        begin
            weights_dec = w;
            input_vals = a;
            #1;

            $display("CASE=%s W=%08h A=%08h", name, w, a);

            for (int i = 0; i < 8; i++) begin
                $display(
                    "  LANE=%0d WEIGHT=%0d ACT=%0d",
                    i,
                    $signed(weight_vals[i]),
                    $signed(activations[i])
                );
            end
        end
    endtask

    initial begin
        iteration = 0;
        mode = 3'b011;

        show_case("ZERO", 32'h00000000, 32'h01020304);
        show_case("ALL_01", 32'h55555555, 32'h01020304);
        show_case("ALL_10", 32'hAAAAAAAA, 32'h01020304);
        show_case("ALL_11", 32'hFFFFFFFF, 32'h01020304);
        show_case("MIXED", 32'h1B1B1B1B, 32'h01020304);

        $display("INT2_DIAGNOSTIC_COMPLETE");
        $finish;
    end

endmodule

