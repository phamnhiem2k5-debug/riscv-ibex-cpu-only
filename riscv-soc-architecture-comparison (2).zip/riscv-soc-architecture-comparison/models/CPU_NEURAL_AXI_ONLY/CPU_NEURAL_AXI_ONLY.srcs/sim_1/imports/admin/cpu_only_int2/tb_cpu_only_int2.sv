
`timescale 1ns/1ps

module tb_cpu_only_int2;

    logic clk = 0;
    logic rst_n = 0;

    wire [31:0] debug_pc;
    wire debug_instr_req;
    wire [31:0] debug_cpu_addr;
    wire [31:0] debug_cpu_wdata;
    wire [31:0] debug_neural_rdata;
    wire debug_neural_rvalid;

    integer cycles = 0;
    integer neural_accesses = 0;
    integer result_cycle = -1;

    logic result_seen = 0;
    logic done_seen = 0;
    logic [31:0] result_value = 0;

    localparam integer TIMEOUT = 20000;

    always #10 clk = ~clk;

    ibex_simple_system_cpu_only #(
        .SRAMInitFile(
            "C:/Users/admin/cpu_only_int2/cpu_only_int2.vmem"
        )
    ) dut (
        .IO_CLK(clk),
        .IO_CLK_FAST(clk),
        .IO_RST_N(rst_n),
        .DEBUG_PC(debug_pc),
        .DEBUG_INSTR_REQ(debug_instr_req),
        .DEBUG_CPU_ADDR(debug_cpu_addr),
        .DEBUG_CPU_WDATA(debug_cpu_wdata),
        .DEBUG_NEURAL_RDATA(debug_neural_rdata),
        .DEBUG_NEURAL_RVALID(debug_neural_rvalid)
    );

    always @(posedge clk) begin
        if (rst_n) begin
            cycles = cycles + 1;

            // RAM is device index 0 in this SoC.
            if (dut.device_req[0] &&
                dut.device_we[0] &&
                dut.device_gnt[0]) begin

                if (dut.device_addr[0][19:0] == 20'h00400) begin
                    result_value = dut.device_wdata[0];
                    result_seen = 1;
                    result_cycle = cycles;

                    $display(
                        "CPU RESULT WRITE: %08h CYCLE=%0d",
                        result_value, cycles
                    );
                end

                if (dut.device_addr[0][19:0] == 20'h00404 &&
                    dut.device_wdata[0] == 32'd1) begin

                    done_seen = 1;
                    $display("CPU DONE: CYCLE=%0d", cycles);
                end
            end

            if (dut.device_req[3] &&
                dut.device_addr[3][31:12] == 20'h00040)
                neural_accesses = neural_accesses + 1;
        end
    end

    initial begin
        $display("TB_VERSION = CPU_ONLY_INT2_V1");

        repeat (10) @(negedge clk);
        rst_n = 1;

        for (integer i = 0; i < TIMEOUT; i++) begin
            @(negedge clk);

            if (done_seen) begin
                $display("");
                $display("===== CPU ONLY INT2 REPORT =====");
                $display("RESULT = %0d", $signed(result_value));
                $display("EXPECTED = 2");
                $display("RESULT_CYCLE = %0d", result_cycle);
                $display("TOTAL_CYCLES = %0d", cycles);
                $display("NEURAL_ACCESS_COUNT = %0d",
                         neural_accesses);
                $display("FINAL_PC = %08h", debug_pc);

                if (result_seen &&
                    result_value == 32'd2 &&
                    neural_accesses == 0) begin
                    $display("CPU_ONLY_INT2_PASS");
                end else begin
                    $display("CPU_ONLY_INT2_FAIL");
                end

                $finish;
            end
        end

        $display("CPU_ONLY_INT2_TIMEOUT");
        $display("FINAL_PC = %08h", debug_pc);
        $display("RESULT_SEEN = %0d", result_seen);
        $display("DONE_SEEN = %0d", done_seen);
        $finish;
    end

endmodule

