
`timescale 1ns/1ps

module tb_neural_accumulation;

    logic clk = 0;
    logic rstn = 0;
    logic bias_in = 0;
    logic valid_in = 0;
    logic get_res = 0;

    logic [31:0] bias_shift_mode = 0;
    logic [31:0] weights = 0;
    logic [31:0] input_val = 0;
    logic [31:0] out_mul_vals = 0;
    logic [31:0] out_shift_rl = 0;

    logic [31:0] par_prods_in[4];
    logic [16:0] weights_out[4];
    logic [16:0] act_out[4];

    logic [31:0] output_val;
    logic valid_out;
    logic compressed_valid;

    integer passed = 0;
    integer failed = 0;

    always #5 clk = ~clk;

    for (genvar i = 0; i < 4; i++) begin : MULT
        assign par_prods_in[i] =
            $signed(weights_out[i]) * $signed(act_out[i]);
    end

    neural_unit dut (
        .clk_i(clk),
        .clk_i_fast(clk),
        .rstn_i(rstn),

        .bias_in(bias_in),
        .valid_in(valid_in),
        .get_res(get_res),

        .bias_shift_mode(bias_shift_mode),
        .weights(weights),
        .input_val(input_val),

        .out_mul_vals(out_mul_vals),
        .out_shift_rl(out_shift_rl),

        .par_prods_in(par_prods_in),
        .weights_out(weights_out),
        .act_out(act_out),

        .output_val(output_val),
        .valid_out(valid_out),
        .compressed_valid(compressed_valid)
    );

    task automatic run_case(
        input string name,
        input logic [2:0] test_mode,
        input logic [31:0] test_weights,
        input logic [31:0] test_inputs
    );
        integer mac_count;
        logic [31:0] mac_sum[4];
        bit matched;

        begin
            @(negedge clk);
            rstn = 0;
            bias_in = 0;
            valid_in = 0;
            get_res = 0;

            repeat (4) @(negedge clk);
            rstn = 1;

            // Initialize accumulator and mode
            bias_shift_mode = {29'b0, test_mode};
            weights = 0;

            @(negedge clk);
            bias_in = 1;

            @(negedge clk);
            bias_in = 0;

            // Send one MAC transaction
            weights = test_weights;
            input_val = test_inputs;

            @(negedge clk);
            valid_in = 1;

            @(negedge clk);
            valid_in = 0;

            mac_count = 0;

            for (int i = 0; i < 4; i++) begin
                mac_sum[i] = 0;
            end

            // Capture each accepted MAC result
            repeat (16) begin
                @(posedge clk);

                if (dut.mab_valid) begin
                    $display("DEBUG_MAC_VALID TIME=%0t ITER=%0d MODE=%0d",
                             $time, dut.iteration, dut.mode_reg);
                    $display("DEBUG_MAB_ITER=%0d ENABLE=%0b",
                             dut.MAB.iter, dut.MAB.enable);
                    $display("DEBUG_MAB_REG=%0d,%0d,%0d,%0d",
                             $signed(dut.MAB.add_res_reg[0]),
                             $signed(dut.MAB.add_res_reg[1]),
                             $signed(dut.MAB.add_res_reg[2]),
                             $signed(dut.MAB.add_res_reg[3]));
                    for (int k = 0; k < 4; k++) begin
                        $display("DEBUG_MAC[%0d]=%0d ACC_BEFORE[%0d]=%0d",
                                 k, $signed(dut.mab_results[k]),
                                 k, $signed(dut.out_reg[k]));
                    end
                    mac_count++;

                    for (int i = 0; i < 4; i++) begin
                        mac_sum[i] = mac_sum[i] + dut.mab_results[i];
                    end
                end
            end

            @(negedge clk);

            $display("================================");
            $display("CASE=%s MODE=%0d", name, test_mode);
            $display("MAC_VALID_COUNT=%0d", mac_count);

            matched = 1;

            for (int i = 0; i < 4; i++) begin
                $display(
                    "ACC[%0d]=%0d EXPECTED_FROM_MAC=%0d",
                    i,
                    $signed(dut.out_reg[i]),
                    $signed(mac_sum[i])
                );

                if (dut.out_reg[i] !== mac_sum[i])
                    matched = 0;
            end

            if (mac_count == 1 && matched) begin
                passed++;
                $display("ACC_PASS %s", name);
            end else begin
                failed++;
                $display("ACC_FAIL %s", name);
            end
        end
    endtask

    initial begin
        repeat (2) @(negedge clk);

        run_case(
            "INT8_SIGNED",
            3'b101,
            32'hFB03F807,
            32'h03030303
        );

        run_case(
            "INT4_SIGNED",
            3'b110,
            32'h8F370000,
            32'h03030303
        );

        run_case(
            "INT2_PACKED",
            3'b111,
            32'h55555555,
            32'h03030303
        );

        $display("================================");
        $display("ACC_PASSED=%0d", passed);
        $display("ACC_FAILED=%0d", failed);
        $display("================================");

        $finish;
    end


    // Diagnostic monitor: first INT8 transaction
    always @(negedge clk) begin
        if ($time >= 95 && $time <= 175) begin
            $display(
                "PIPE T=%0t EN=%0b ITER=%0d VALID=%0b",
                $time,
                dut.MAB.enable,
                dut.MAB.iter,
                dut.mab_valid
            );

            for (int k = 0; k < 4; k++) begin
                $display(
                    "PIPE[%0d] REG=%0d WIRE=%0d OUT=%0d MAC=%0d",
                    k,
                    $signed(dut.MAB.add_res_reg[k]),
                    $signed(dut.MAB.add_res_wire[k]),
                    $signed(dut.MAB.add_res_out[k]),
                    $signed(dut.mab_results[k])
                );
            end
        end
    end


    // Compare MAC data at valid and one cycle later
    always @(negedge clk) begin
        if (dut.mab_valid) begin
            $display("ALIGN_VALID_TIME=%0t", $time);

            for (int k=0; k<4; k++) begin
                $display("ALIGN_NOW[%0d]=%0d",
                         k, $signed(dut.mab_results[k]));
            end

            @(negedge clk);

            $display("ALIGN_DELAYED_TIME=%0t", $time);

            for (int k=0; k<4; k++) begin
                $display("ALIGN_DELAYED[%0d]=%0d",
                         k, $signed(dut.mab_results[k]));
            end
        end
    end
    
endmodule

