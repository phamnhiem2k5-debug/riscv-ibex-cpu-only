
`timescale 1ns/1ps

module tb_soc_neural_integration;

initial $display("TB_VERSION = SOC_REGRESSION_V2");

    logic clk = 1'b0;
    logic rst_n = 1'b0;

    wire [31:0] debug_pc;
    wire        debug_instr_req;
    wire [31:0] debug_cpu_addr;
    wire [31:0] debug_cpu_wdata;
    wire [31:0] debug_neural_rdata;
    wire        debug_neural_rvalid;

    localparam logic [31:0] NEURAL_BASE =
        32'h00040000;

    localparam logic [31:0] RESULT_ADDR =
        32'h0004002C;

    // Observed reference, NOT independently verified golden
    localparam logic [31:0] REGRESSION_EXPECTED =
        32'h24042904;

    localparam integer TIMEOUT_CYCLES = 20000;

    integer cycle_count = 0;
    integer neural_access_count = 0;
    integer write_count = 0;
    integer read_count = 0;
    integer result_checks = 0;
    integer failures = 0;

    logic pending_result_read = 1'b0;
    logic result_received = 1'b0;
    logic [31:0] actual_result = 32'h0;
    logic [31:0] result_age = 32'h0;

    always #10 clk = ~clk;

    ibex_simple_system_neural_synth dut (
        .IO_CLK              (clk),
        .IO_CLK_FAST         (clk),
        .IO_RST_N            (rst_n),
        .DEBUG_PC            (debug_pc),
        .DEBUG_INSTR_REQ     (debug_instr_req),
        .DEBUG_CPU_ADDR      (debug_cpu_addr),
        .DEBUG_CPU_WDATA     (debug_cpu_wdata),
        .DEBUG_NEURAL_RDATA  (debug_neural_rdata),
        .DEBUG_NEURAL_RVALID (debug_neural_rvalid)
    );

    task automatic print_summary;
        begin
            $display("");
            $display("========================================");
            $display(" SOC INTEGRATION VERIFICATION REPORT");
            $display("========================================");
            $display("CYCLES              = %0d", cycle_count);
            $display("NEURAL_ACCESS_COUNT = %0d", neural_access_count);
            $display("AXI_WRITES          = %0d", write_count);
            $display("AXI_READS           = %0d", read_count);
            $display("RESULT_CHECKS       = %0d", result_checks);
            $display("EXPECTED_REGRESSION = %08h", REGRESSION_EXPECTED);
            $display("ACTUAL_RESULT       = %08h", actual_result);
            $display("FINAL_PC            = %08h", debug_pc);
            $display("FAILURES            = %0d", failures);

            if (failures == 0 &&
                neural_access_count > 0 &&
                write_count > 0 &&
                read_count > 0 &&
                result_checks > 0) begin

                $display("SOC_INTEGRATION_REGRESSION_PASS");

            end else begin

                $display("SOC_INTEGRATION_REGRESSION_FAIL");

            end

            $display("========================================");
        end
    endtask

    always @(posedge clk) begin
        if (rst_n) begin

            cycle_count <= cycle_count + 1;

            // Monitor neural bus requests
            if (dut.device_req[3] &&
                dut.device_addr[3][31:12] == 20'h00040) begin

                neural_access_count <= neural_access_count + 1;

                $display(
                    "NEURAL ACCESS t=%0t addr=%08h we=%b wdata=%08h",
                    $time,
                    dut.device_addr[3],
                    dut.device_we[3],
                    dut.device_wdata[3]
                );

                if (dut.device_we[3]) begin

                    write_count <= write_count + 1;

                end else begin

                    read_count <= read_count + 1;

                    if (dut.device_addr[3] == RESULT_ADDR)
                        pending_result_read <= 1'b1;

                end
            end

            // Check returned result when response is valid
            if (debug_neural_rvalid && pending_result_read) begin

                pending_result_read <= 1'b0;
                result_received <= 1'b1;
                actual_result <= debug_neural_rdata;

                result_checks <= result_checks + 1;

                $display(
                    "SOC RESULT READ: addr=%08h data=%08h",
                    RESULT_ADDR,
                    debug_neural_rdata
                );

                if (debug_neural_rdata === REGRESSION_EXPECTED) begin

                    $display("SOC_RESULT_REGRESSION_MATCH");

                end else begin

                    failures <= failures + 1;

                    $display(
                        "SOC_RESULT_REGRESSION_MISMATCH expected=%08h actual=%08h",
                        REGRESSION_EXPECTED,
                        debug_neural_rdata
                    );

                end
            end

            if (cycle_count % 1000 == 0) begin
                $display(
                    "TRACE cycle=%0d PC=%08h instr_req=%b CPU_ADDR=%08h",
                    cycle_count,
                    debug_pc,
                    debug_instr_req,
                    debug_cpu_addr
                );
            end

            // Finish after result has been received
            if (result_received) begin

                result_age <= result_age + 1;

                if (result_age >= 10) begin

                    print_summary();

                    if (failures == 0 &&
                        write_count > 0 &&
                        read_count > 0 &&
                        result_checks > 0)
                        $finish;
                    else
                        $fatal(1, "SOC INTEGRATION FAILED");

                end
            end

            // Timeout protection
            if (cycle_count >= TIMEOUT_CYCLES) begin

                $display("ERROR: SOC TIMEOUT");
                print_summary();
                $fatal(1, "SOC INTEGRATION TIMEOUT");

            end
        end
    end

    initial begin

        repeat (10) @(negedge clk);

        rst_n = 1'b1;

        $display("SOC INTEGRATION SIMULATION STARTED");

        #500000;

        $fatal(1, "GLOBAL TESTBENCH TIMEOUT");

    end

endmodule
