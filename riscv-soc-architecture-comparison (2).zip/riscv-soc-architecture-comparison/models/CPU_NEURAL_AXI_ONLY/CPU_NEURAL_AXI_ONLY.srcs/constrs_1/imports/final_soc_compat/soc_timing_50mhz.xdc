# Timing constraints for Ibex + Neural Accelerator
# Target frequency: 50 MHz
# No physical FPGA board required

create_clock -name sys_clk -period 20.000 [get_ports IO_CLK]
create_clock -name fast_clk -period 20.000 [get_ports IO_CLK_FAST]
