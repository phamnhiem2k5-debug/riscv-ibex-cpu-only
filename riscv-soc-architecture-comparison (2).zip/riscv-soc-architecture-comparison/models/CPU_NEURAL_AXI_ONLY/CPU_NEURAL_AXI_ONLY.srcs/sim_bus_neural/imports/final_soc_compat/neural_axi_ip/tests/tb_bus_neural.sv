
`timescale 1ns/1ps

module tb_bus_neural;

    localparam int N = 4;

    logic clk = 0;
    logic rst_n = 0;

    always #5 clk = ~clk;

    logic host_req [1];
    logic host_gnt [1];
    logic [31:0] host_addr [1];
    logic host_we [1];
    logic [3:0] host_be [1];
    logic [31:0] host_wdata [1];
    logic host_rvalid [1];
    logic [31:0] host_rdata [1];
    logic host_err [1];

    logic device_req [N];
    logic device_gnt [N];
    logic [31:0] device_addr [N];
    logic device_we [N];
    logic [3:0] device_be [N];
    logic [31:0] device_wdata [N];
    logic device_rvalid [N];
    logic [31:0] device_rdata [N];
    logic device_err [N];

    logic [31:0] cfg_base [N];
    logic [31:0] cfg_mask [N];

    bus_neural #(
        .NrDevices(N),
        .NrHosts(1),
        .DataWidth(32),
        .AddressWidth(32)
    ) dut (
        .clk_i(clk),
        .rst_ni(rst_n),

        .host_req_i(host_req),
        .host_gnt_o(host_gnt),
        .host_addr_i(host_addr),
        .host_we_i(host_we),
        .host_be_i(host_be),
        .host_wdata_i(host_wdata),
        .host_rvalid_o(host_rvalid),
        .host_rdata_o(host_rdata),
        .host_err_o(host_err),

        .device_req_o(device_req),
        .device_gnt_i(device_gnt),
        .device_addr_o(device_addr),
        .device_we_o(device_we),
        .device_be_o(device_be),
        .device_wdata_o(device_wdata),
        .device_rvalid_i(device_rvalid),
        .device_rdata_i(device_rdata),
        .device_err_i(device_err),

        .cfg_device_addr_base(cfg_base),
        .cfg_device_addr_mask(cfg_mask)
    );

    initial begin
        host_req[0] = 0;
        host_addr[0] = 0;
        host_we[0] = 0;
        host_be[0] = 4'hF;
        host_wdata[0] = 0;

        for (int i = 0; i < N; i++) begin
            device_gnt[i] = 1;
            device_rvalid[i] = 0;
            device_rdata[i] = 0;
            device_err[i] = 0;
        end

        cfg_base[0] = 32'h00100000;
        cfg_mask[0] = 32'hFFF00000;

        cfg_base[1] = 32'h00020000;
        cfg_mask[1] = 32'hFFFFFC00;

        cfg_base[2] = 32'h00030000;
        cfg_mask[2] = 32'hFFFFFC00;

        cfg_base[3] = 32'h00040000;
        cfg_mask[3] = 32'hFFFFF000;

        repeat (4) @(negedge clk);
        rst_n = 1;

        // Test 1: RAM request
        host_addr[0] = 32'h00100008;
        host_req[0] = 1;

        #1;
        if (!host_gnt[0] || !device_req[0])
            $fatal(1, "RAM REQUEST FAILED");

        @(posedge clk);
        @(negedge clk);
        host_req[0] = 0;

        device_rdata[0] = 32'h11223344;
        device_rvalid[0] = 1;

        #1;
        if (!host_rvalid[0] ||
            host_rdata[0] !== 32'h11223344)
            $fatal(1, "RAM RESPONSE FAILED");

        $display("PASS RAM RESPONSE");

        @(posedge clk);
        @(negedge clk);
        device_rvalid[0] = 0;

        // Test 2: Neural grant stall
        device_gnt[3] = 0;

        host_addr[0] = 32'h00040008;
        host_req[0] = 1;

        #1;
        if (host_gnt[0])
            $fatal(1, "GRANT SHOULD BE LOW");

        if (!device_req[3])
            $fatal(1, "NEURAL REQUEST MISSING");

        $display("PASS NEURAL GRANT STALL");

        repeat (3) @(negedge clk);

        device_gnt[3] = 1;

        #1;
        if (!host_gnt[0])
            $fatal(1, "GRANT NOT ASSERTED");

        @(posedge clk);
        @(negedge clk);
        host_req[0] = 0;

        // Test 3: Delayed neural response
        repeat (5) @(negedge clk);

        if (host_rvalid[0])
            $fatal(1, "EARLY RESPONSE");

        device_rdata[3] = 32'hAABBCCDD;
        device_rvalid[3] = 1;

        #1;
        if (!host_rvalid[0] ||
            host_rdata[0] !== 32'hAABBCCDD)
            $fatal(1, "NEURAL RESPONSE FAILED");

        $display("PASS DELAYED NEURAL RESPONSE");
        $display("BUS NEURAL TEST PASSED");

        $finish;
    end

    initial begin
        #10000;
        $fatal(1, "GLOBAL TIMEOUT");
    end

endmodule
