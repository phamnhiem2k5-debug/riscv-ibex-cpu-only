
module bus_neural #(
    parameter int NrDevices = 4,
    parameter int NrHosts = 1,
    parameter int DataWidth = 32,
    parameter int AddressWidth = 32
) (
    input logic clk_i,
    input logic rst_ni,

    input logic host_req_i [NrHosts],
    output logic host_gnt_o [NrHosts],

    input logic [AddressWidth-1:0] host_addr_i [NrHosts],
    input logic host_we_i [NrHosts],
    input logic [DataWidth/8-1:0] host_be_i [NrHosts],
    input logic [DataWidth-1:0] host_wdata_i [NrHosts],

    output logic host_rvalid_o [NrHosts],
    output logic [DataWidth-1:0] host_rdata_o [NrHosts],
    output logic host_err_o [NrHosts],

    output logic device_req_o [NrDevices],
    input logic device_gnt_i [NrDevices],

    output logic [AddressWidth-1:0] device_addr_o [NrDevices],
    output logic device_we_o [NrDevices],
    output logic [DataWidth/8-1:0] device_be_o [NrDevices],
    output logic [DataWidth-1:0] device_wdata_o [NrDevices],

    input logic device_rvalid_i [NrDevices],
    input logic [DataWidth-1:0] device_rdata_i [NrDevices],
    input logic device_err_i [NrDevices],

    input logic [AddressWidth-1:0] cfg_device_addr_base [NrDevices],
    input logic [AddressWidth-1:0] cfg_device_addr_mask [NrDevices]
);

    localparam int HostBits =
        (NrHosts > 1) ? $clog2(NrHosts) : 1;

    localparam int DeviceBits =
        (NrDevices > 1) ? $clog2(NrDevices) : 1;

    typedef enum logic {
        IDLE,
        WAIT_RESPONSE
    } state_t;

    state_t state;

    logic [HostBits-1:0] selected_host;
    logic [DeviceBits-1:0] selected_device;

    logic [HostBits-1:0] active_host;
    logic [DeviceBits-1:0] active_device;

    logic request_accepted;

    always_comb begin
        selected_host = '0;

        for (int h = NrHosts-1; h >= 0; h--) begin
            if (host_req_i[h])
                selected_host = HostBits'(h);
        end

        selected_device = '0;

        for (int d = 0; d < NrDevices; d++) begin
            if ((host_addr_i[selected_host] &
                 cfg_device_addr_mask[d]) ==
                 cfg_device_addr_base[d]) begin

                selected_device = DeviceBits'(d);
            end
        end
    end

    assign request_accepted =
        (state == IDLE) &&
        host_req_i[selected_host] &&
        device_gnt_i[selected_device];

    always_comb begin
        for (int h = 0; h < NrHosts; h++) begin
            host_gnt_o[h] = 1'b0;
            host_rvalid_o[h] = 1'b0;
            host_rdata_o[h] = '0;
            host_err_o[h] = 1'b0;
        end

        for (int d = 0; d < NrDevices; d++) begin
            device_req_o[d] = 1'b0;
            device_addr_o[d] = '0;
            device_we_o[d] = 1'b0;
            device_be_o[d] = '0;
            device_wdata_o[d] = '0;
        end

        if (state == IDLE) begin
            device_req_o[selected_device] =
                host_req_i[selected_host];

            device_addr_o[selected_device] =
                host_addr_i[selected_host];

            device_we_o[selected_device] =
                host_we_i[selected_host];

            device_be_o[selected_device] =
                host_be_i[selected_host];

            device_wdata_o[selected_device] =
                host_wdata_i[selected_host];

            host_gnt_o[selected_host] =
                request_accepted;
        end

        if (state == WAIT_RESPONSE) begin
            host_rvalid_o[active_host] =
                device_rvalid_i[active_device];

            host_rdata_o[active_host] =
                device_rdata_i[active_device];

            host_err_o[active_host] =
                device_err_i[active_device];
        end
    end

    always_ff @(posedge clk_i or negedge rst_ni) begin
        if (!rst_ni) begin
            state <= IDLE;
            active_host <= '0;
            active_device <= '0;
        end else begin
            case (state)
                IDLE: begin
                    if (request_accepted) begin
                        active_host <= selected_host;
                        active_device <= selected_device;
                        state <= WAIT_RESPONSE;
                    end
                end

                WAIT_RESPONSE: begin
                    if (device_rvalid_i[active_device])
                        state <= IDLE;
                end

                default: state <= IDLE;
            endcase
        end
    end

endmodule
