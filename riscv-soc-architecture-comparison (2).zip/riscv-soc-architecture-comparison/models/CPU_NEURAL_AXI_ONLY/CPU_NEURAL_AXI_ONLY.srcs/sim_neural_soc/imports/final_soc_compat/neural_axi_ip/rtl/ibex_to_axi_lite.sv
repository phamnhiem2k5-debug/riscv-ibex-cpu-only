
module ibex_to_axi_lite (
    input  logic        clk_i,
    input  logic        rst_ni,

    input  logic        req_i,
    output logic        gnt_o,
    input  logic        we_i,
    input  logic [3:0]  be_i,
    input  logic [31:0] addr_i,
    input  logic [31:0] wdata_i,
    output logic        rvalid_o,
    output logic [31:0] rdata_o,
    output logic        err_o,

    output logic [31:0] m_axi_awaddr,
    output logic        m_axi_awvalid,
    input  logic        m_axi_awready,

    output logic [31:0] m_axi_wdata,
    output logic [3:0]  m_axi_wstrb,
    output logic        m_axi_wvalid,
    input  logic        m_axi_wready,

    input  logic [1:0]  m_axi_bresp,
    input  logic        m_axi_bvalid,
    output logic        m_axi_bready,

    output logic [31:0] m_axi_araddr,
    output logic        m_axi_arvalid,
    input  logic        m_axi_arready,

    input  logic [31:0] m_axi_rdata,
    input  logic [1:0]  m_axi_rresp,
    input  logic        m_axi_rvalid,
    output logic        m_axi_rready
);

    typedef enum logic [2:0] {
        IDLE,
        WRITE_ADDR_DATA,
        WRITE_RESP,
        READ_ADDR,
        READ_RESP,
        COMPLETE
    } state_t;

    state_t state;

    logic [31:0] addr_q;
    logic [31:0] wdata_q;
    logic [3:0]  be_q;

    logic aw_done;
    logic w_done;

    assign gnt_o = (state == IDLE);

    assign m_axi_awaddr  = addr_q;
    assign m_axi_wdata   = wdata_q;
    assign m_axi_wstrb   = be_q;
    assign m_axi_araddr  = addr_q;

    assign m_axi_awvalid = (state == WRITE_ADDR_DATA) && !aw_done;
    assign m_axi_wvalid  = (state == WRITE_ADDR_DATA) && !w_done;
    assign m_axi_bready  = (state == WRITE_RESP);

    assign m_axi_arvalid = (state == READ_ADDR);
    assign m_axi_rready  = (state == READ_RESP);

    assign rvalid_o = (state == COMPLETE);

    always_ff @(posedge clk_i or negedge rst_ni) begin
        if (!rst_ni) begin
            state   <= IDLE;
            addr_q  <= '0;
            wdata_q <= '0;
            be_q    <= '0;
            aw_done <= 1'b0;
            w_done  <= 1'b0;
            rdata_o <= '0;
            err_o   <= 1'b0;
        end else begin
            case (state)
                IDLE: begin
                    if (req_i && gnt_o) begin
                        addr_q  <= addr_i;
                        wdata_q <= wdata_i;
                        be_q    <= be_i;
                        aw_done <= 1'b0;
                        w_done  <= 1'b0;
                        err_o   <= 1'b0;

                        if (we_i)
                            state <= WRITE_ADDR_DATA;
                        else
                            state <= READ_ADDR;
                    end
                end

                WRITE_ADDR_DATA: begin
                    if (m_axi_awvalid && m_axi_awready)
                        aw_done <= 1'b1;

                    if (m_axi_wvalid && m_axi_wready)
                        w_done <= 1'b1;

                    if ((aw_done || (m_axi_awvalid && m_axi_awready)) &&
                        (w_done || (m_axi_wvalid && m_axi_wready)))
                        state <= WRITE_RESP;
                end

                WRITE_RESP: begin
                    if (m_axi_bvalid && m_axi_bready) begin
                        err_o <= (m_axi_bresp != 2'b00);
                        state <= COMPLETE;
                    end
                end

                READ_ADDR: begin
                    if (m_axi_arvalid && m_axi_arready)
                        state <= READ_RESP;
                end

                READ_RESP: begin
                    if (m_axi_rvalid && m_axi_rready) begin
                        rdata_o <= m_axi_rdata;
                        err_o   <= (m_axi_rresp != 2'b00);
                        state <= COMPLETE;
                    end
                end

                COMPLETE: begin
                    state <= IDLE;
                end

                default: state <= IDLE;
            endcase
        end
    end

endmodule
