`timescale 1ns/1ps
// Verifier V2: NO GOLDEN OUTPUT CONSTANT / NO PRESET ACTUAL VALUE.
// Measures CPU's real native SRAM write. GOLDEN CHECK IS OFFLINE ONLY.
module tb_CPU_TC02_ZERO_INPUT;
  logic clk=1'b0, rst_n=1'b0;
  wire [31:0] debug_pc, debug_cpu_addr, debug_cpu_wdata, debug_neural_rdata;
  wire debug_instr_req, debug_neural_rvalid;
  integer cycle_count=0, first_fetch=-1, result_cycle=-1, stores=0, fd;
  bit done=1'b0;
  always #10 clk=~clk;
  ibex_simple_system_cpu_pure #(.SRAMInitFile("C:/Users/admin/final_soc_compat/evidence/multicase/benchmark_cpu_pure/firmware/TC02_ZERO_INPUT.vmem")) dut (
    .IO_CLK(clk), .IO_CLK_FAST(clk), .IO_RST_N(rst_n),
    .DEBUG_PC(debug_pc), .DEBUG_INSTR_REQ(debug_instr_req),
    .DEBUG_CPU_ADDR(debug_cpu_addr),.DEBUG_CPU_WDATA(debug_cpu_wdata),
    .DEBUG_NEURAL_RDATA(debug_neural_rdata),
    .DEBUG_NEURAL_RVALID(debug_neural_rvalid)
  );
  initial begin
    fd=$fopen("C:/Users/admin/final_soc_compat/evidence/multicase/benchmark_cpu_pure/results/TC02_ZERO_INPUT.txt", "w");
    if (!fd) $fatal(1,"NO_LOG_FILE");
    repeat (10) @(negedge clk);
    rst_n=1'b1;
  end
  always @(posedge clk) if (rst_n && !done) begin
    cycle_count=cycle_count+1;
    if (first_fetch<0 && debug_instr_req===1'b1)
      first_fetch=cycle_count;
    if (dut.host_req[0] === 1'b1 && dut.host_addr[0][31:12] === 20'h00040)
      $fatal(1, "CPU_PURE_ILLEGAL_NEURAL_MMIO");
    if (dut.device_req[0]===1'b1 && dut.device_gnt[0]===1'b1 && dut.device_we[0]===1'b1) begin
      stores=stores+1;
      if (dut.device_addr[0]===32'h00103FFC) begin
        if (first_fetch<0) $fatal(1,"NO_FIRST_FETCH");
        done=1'b1;
        result_cycle=cycle_count;
        // Raw observed data, not a self-reported PASS.
        $fdisplay(fd,"RUN_ID = 4E4A25499DBFD9EEC86A721E ");
        $fdisplay(fd,"CASE = TC02_ZERO_INPUT");
        $fdisplay(fd,"EVENT = CPU_SRAM_STORE");
        $fdisplay(fd,"ADDRESS = %08h",dut.device_addr[0]);
        $fdisplay(fd,"ACTUAL = %08h",dut.device_wdata[0]);
        $fdisplay(fd,"FIRST_FETCH = %0d",first_fetch);
        $fdisplay(fd,"RESULT_CYCLE = %0d",result_cycle);
        $fdisplay(fd,"CYCLES = %0d",result_cycle-first_fetch+1);
        $fdisplay(fd,"STORES = %0d",stores);
        $fdisplay(fd,"END_PC = %08h",debug_pc);
        $fflush(fd);
        $fclose(fd);
        $display("VERIFIED_RAW TC02_ZERO_INPUT ACTUAL=%08h CYCLES=%0d",dut.device_wdata[0],result_cycle-first_fetch+1);
        $finish;
      end
    end
    if(cycle_count>30000) $fatal(1,"CPU_ONLY_TIMEOUT");
  end
endmodule
