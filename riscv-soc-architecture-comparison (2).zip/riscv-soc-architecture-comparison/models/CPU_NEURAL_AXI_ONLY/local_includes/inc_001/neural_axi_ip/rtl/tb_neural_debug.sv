
`timescale 1ns/1ps

module tb_neural_debug;

    logic clk = 0;
    always #5 clk = ~clk;

    logic rstn = 0;

    logic [31:0] awaddr = 0;
    logic awvalid = 0;
    wire awready;

    logic [31:0] wdata = 0;
    logic [3:0] wstrb = 0;
    logic wvalid = 0;
    wire wready;

    wire [1:0] bresp;
    wire bvalid;
    logic bready = 0;

    logic [31:0] araddr = 0;
    logic arvalid = 0;
    wire arready;

    wire [31:0] rdata;
    wire [1:0] rresp;
    wire rvalid;
    logic rready = 0;

    integer passed = 0;
    integer failed = 0;

    neural_axi_wrapper dut (
        .s_axi_aclk(clk),
        .s_axi_aresetn(rstn),
        .s_axi_awaddr(awaddr),
        .s_axi_awvalid(awvalid),
        .s_axi_awready(awready),
        .s_axi_wdata(wdata),
        .s_axi_wstrb(wstrb),
        .s_axi_wvalid(wvalid),
        .s_axi_wready(wready),
        .s_axi_bresp(bresp),
        .s_axi_bvalid(bvalid),
        .s_axi_bready(bready),
        .s_axi_araddr(araddr),
        .s_axi_arvalid(arvalid),
        .s_axi_arready(arready),
        .s_axi_rdata(rdata),
        .s_axi_rresp(rresp),
        .s_axi_rvalid(rvalid),
        .s_axi_rready(rready)
    );

    task automatic axi_write(
        input logic [31:0] addr,
        input logic [31:0] data,
        input logic [3:0] strb,
        input integer delay_w
    );
        integer timeout;
        bit aw_done, w_done;
        begin
            aw_done = 0;
            w_done = 0;

            @(negedge clk);
            awaddr = addr;
            awvalid = 1;

            if (delay_w == 0) begin
                wdata = data;
                wstrb = strb;
                wvalid = 1;
            end

            timeout = 0;
            while (!aw_done || !w_done) begin
                @(posedge clk);

                if (awvalid && awready)
                    aw_done = 1;

                if (wvalid && wready)
                    w_done = 1;

                @(negedge clk);

                if (aw_done)
                    awvalid = 0;

                if (!wvalid && timeout >= delay_w) begin
                    wdata = data;
                    wstrb = strb;
                    wvalid = 1;
                end

                if (w_done)
                    wvalid = 0;

                timeout++;

                if (timeout > 100)
                    $fatal(1, "AXI WRITE TIMEOUT");
            end

            bready = 1;
            timeout = 0;

            do begin
                @(posedge clk);
                timeout++;
                if (timeout > 100)
                    $fatal(1, "AXI BRESP TIMEOUT");
            end while (!bvalid);

            if (bresp !== 2'b00)
                $fatal(1, "AXI WRITE RESPONSE ERROR");

            @(negedge clk);
            bready = 0;
        end
    endtask

    task automatic axi_read_check(
        input logic [31:0] addr,
        input logic [31:0] expected
    );
        integer timeout;
        logic [31:0] actual;
        begin
            @(negedge clk);
            araddr = addr;
            arvalid = 1;

            timeout = 0;
            do begin
                @(posedge clk);
                timeout++;
                if (timeout > 100)
                    $fatal(1, "AXI READ ADDRESS TIMEOUT");
            end while (!arready);

            @(negedge clk);
            arvalid = 0;

            timeout = 0;
            do begin
                @(posedge clk);
                timeout++;
                if (timeout > 100)
                    $fatal(1, "AXI READ DATA TIMEOUT");
            end while (!rvalid);

            actual = rdata;

            if (actual === expected && rresp === 2'b00) begin
                passed++;
                $display("PASS: addr=%h data=%h", addr, actual);
            end else begin
                failed++;
                $display("FAIL: addr=%h expected=%h actual=%h",
                         addr, expected, actual);
            end

            @(negedge clk);
            rready = 1;
            @(negedge clk);
            rready = 0;
        end
    endtask

    initial begin
        repeat (5) @(negedge clk);
        rstn = 1;

        $display("========== AXI4-LITE TEST ==========");

        axi_write(32'h08, 32'h12345678, 4'hF, 0);
        axi_read_check(32'h08, 32'h12345678);

        axi_write(32'h0C, 32'hAABBCCDD, 4'hF, 3);
        axi_read_check(32'h0C, 32'hAABBCCDD);

        axi_write(32'h08, 32'h0000EE00, 4'b0010, 0);
        axi_read_check(32'h08, 32'h1234EE78);

        axi_write(32'h10, 32'h00000003, 4'hF, 0);
        axi_read_check(32'h10, 32'h00000003);


        // Reset lai thanh ghi mode ve 0
        axi_write(32'h10, 32'h00000000, 4'hF, 0);

        // Bias = 5 tai byte cao nhat cua WEIGHTS
        axi_write(32'h08, 32'h05000000, 4'hF, 0);

        // CONTROL bit 0 = bias_in
        axi_write(32'h00, 32'h00000001, 4'hF, 0);

        repeat (5) @(negedge clk);

        // Khi get_res = 0, output_val lay tu out_reg[0]
        axi_read_check(32'h2C, 32'h00000005);



        $display("========== RESULT HANDSHAKE TEST ==========");

        // Khoi dong qua trinh xuat ket qua
        axi_write(32'h00, 32'h00000004, 4'hF, 0);

        // Cho mach xu ly
        repeat (15) @(negedge clk);

        $display("RESULT_BUSY = %b", dut.result_busy);
        $display("RESULT_DONE = %b", dut.result_done);
        $display("RESULT_REG  = %h", dut.result_reg);
        $display("COUNTER     = %d",
                 dut.u_neural.neur_output.counter);

        if (dut.result_done === 1'b1 &&
            dut.result_busy === 1'b0) begin
            passed++;
            $display("PASS: RESULT HANDSHAKE");
        end else begin
            failed++;
            $display("FAIL: RESULT HANDSHAKE");
        end

        axi_read_check(32'h04, 32'h00000001);

        $display("========== RESULT DATA ==========");
        $display("NEURAL_RESULT = %h", dut.neural_result);
        $display("RESULT_REG    = %h", dut.result_reg);

        $display("========== TEST SUMMARY ==========");
        $display("PASSED=%0d FAILED=%0d", passed, failed);

        if (failed != 0)
            $fatal(1, "AXI TEST FAILED");

        $display("AXI TEST PASSED");
        $finish;
    end

    initial begin
        #100000;
        $fatal(1, "GLOBAL TEST TIMEOUT");
    end


    integer debug_cycle = 0;

    always @(posedge clk) begin
        if (rstn) begin
            debug_cycle = debug_cycle + 1;

            if (dut.result_busy ||
                dut.result_pulse ||
                dut.result_done) begin

                $display(
                    "DBG cycle=%0d busy=%b done=%b get_res=%b counter=%0d out_valid=%b compressed=%h neural=%h latched=%h",
                    debug_cycle,
                    dut.result_busy,
                    dut.result_done,
                    dut.result_pulse,
                    dut.u_neural.neur_output.counter,
                    dut.u_neural.neur_output.valid_out,
                    dut.u_neural.neur_output.compressed_out,
                    dut.neural_result,
                    dut.result_reg
                );
            end
        end
    end

endmodule
