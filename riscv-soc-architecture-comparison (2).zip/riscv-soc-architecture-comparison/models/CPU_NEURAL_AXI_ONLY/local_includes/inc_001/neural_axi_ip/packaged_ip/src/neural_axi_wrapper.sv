
module neural_axi_wrapper (
    input  logic        s_axi_aclk,
    input  logic        s_axi_aresetn,

    input  logic [31:0] s_axi_awaddr,
    input  logic        s_axi_awvalid,
    output logic        s_axi_awready,

    input  logic [31:0] s_axi_wdata,
    input  logic [3:0]  s_axi_wstrb,
    input  logic        s_axi_wvalid,
    output logic        s_axi_wready,

    output logic [1:0]  s_axi_bresp,
    output logic        s_axi_bvalid,
    input  logic        s_axi_bready,

    input  logic [31:0] s_axi_araddr,
    input  logic        s_axi_arvalid,
    output logic        s_axi_arready,

    output logic [31:0] s_axi_rdata,
    output logic [1:0]  s_axi_rresp,
    output logic        s_axi_rvalid,
    input  logic        s_axi_rready
);

    logic [31:0] weights_reg, input_reg, mode_reg;
    logic [31:0] out_mul_reg, out_shift_reg;
    logic [31:0] par_reg [4];

    logic bias_pulse, valid_pulse, result_pulse;
    logic [31:0] neural_result;
    logic neural_valid;
    logic compressed_valid;
    logic result_busy, result_done;
    logic [31:0] result_reg;
    logic [16:0] weights_out [4];

    logic [16:0] act_out [4];

    // Four internal 17x17 multipliers.
    // The existing neural_unit interface accepts 32-bit products.
    logic [31:0] internal_products [4];

    for (genvar k = 0; k < 4; k++) begin : gen_internal_mul
        logic [33:0] full_product;

        assign full_product =
            $unsigned(weights_out[k]) * $unsigned(act_out[k]);

        assign internal_products[k] = full_product[31:0];
    end


    logic [31:0] awaddr_hold, wdata_hold;
    logic [3:0]  wstrb_hold;
    logic aw_pending, w_pending;

    logic [31:0] write_addr;
    logic [31:0] write_data;
    logic [3:0]  write_strb;
    logic write_fire;

    assign s_axi_awready = !aw_pending && !s_axi_bvalid;
    assign s_axi_wready  = !w_pending && !s_axi_bvalid;

    assign write_addr = aw_pending ? awaddr_hold : s_axi_awaddr;
    assign write_data = w_pending  ? wdata_hold  : s_axi_wdata;
    assign write_strb = w_pending  ? wstrb_hold  : s_axi_wstrb;

    assign write_fire =
        !s_axi_bvalid &&
        (aw_pending || (s_axi_awvalid && s_axi_awready)) &&
        (w_pending  || (s_axi_wvalid  && s_axi_wready));

    assign s_axi_bresp = 2'b00;

    assign s_axi_arready = !s_axi_rvalid;
    assign s_axi_rresp = 2'b00;

    function automatic [31:0] merge_bytes(
        input [31:0] old_data,
        input [31:0] new_data,
        input [3:0]  strb
    );
        reg [31:0] tmp;
        begin
            tmp = old_data;
            for (int i = 0; i < 4; i++) begin
                if (strb[i])
                    tmp[i*8 +: 8] = new_data[i*8 +: 8];
            end
            return tmp;
        end
    endfunction

    neural_unit u_neural (
        .clk_i           (s_axi_aclk),
        .clk_i_fast      (s_axi_aclk),
        .rstn_i          (s_axi_aresetn),
        .bias_in         (bias_pulse),
        .valid_in        (valid_pulse),
        .get_res         (result_pulse),
        .bias_shift_mode (mode_reg),
        .weights         (weights_reg),
        .input_val       (input_reg),
        .out_mul_vals    (out_mul_reg),
        .out_shift_rl    (out_shift_reg),
        .par_prods_in    (internal_products),
        .weights_out     (weights_out),
        .act_out         (act_out),
        .output_val      (neural_result),
        .valid_out       (neural_valid),
        .compressed_valid(compressed_valid)
    );

    always_ff @(posedge s_axi_aclk or negedge s_axi_aresetn) begin
        if (!s_axi_aresetn) begin
            weights_reg <= '0;
            input_reg <= '0;
            mode_reg <= '0;
            out_mul_reg <= '0;
            out_shift_reg <= '0;

            for (int i = 0; i < 4; i++)
                par_reg[i] <= '0;

            awaddr_hold <= '0;
            wdata_hold <= '0;
            wstrb_hold <= '0;
            aw_pending <= 1'b0;
            w_pending <= 1'b0;

            bias_pulse <= 1'b0;
            valid_pulse <= 1'b0;
            result_pulse <= 1'b0;
            result_busy <= 1'b0;
            result_done <= 1'b0;
            result_reg <= '0;

            s_axi_bvalid <= 1'b0;
            s_axi_rvalid <= 1'b0;
            s_axi_rdata <= '0;
        end else begin
            bias_pulse <= 1'b0;
            valid_pulse <= 1'b0;
            result_pulse <= 1'b0;

            if (result_busy) begin
                result_pulse <= 1'b1;
                if (compressed_valid && result_pulse) begin
                    result_reg <= neural_result;
                    result_done <= 1'b1;
                    result_busy <= 1'b0;
                    result_pulse <= 1'b0;
                end
            end

            if (s_axi_awvalid && s_axi_awready) begin
                awaddr_hold <= s_axi_awaddr;
                aw_pending <= 1'b1;
            end

            if (s_axi_wvalid && s_axi_wready) begin
                wdata_hold <= s_axi_wdata;
                wstrb_hold <= s_axi_wstrb;
                w_pending <= 1'b1;
            end

            if (write_fire) begin
                case (write_addr[7:0])
                    8'h00: begin
                        if (write_strb[0]) begin
                            bias_pulse   <= write_data[0];
                            valid_pulse  <= write_data[1];
                            if (write_data[2]) begin
                                result_busy <= 1'b1;
                                result_done <= 1'b0;
                                result_pulse <= 1'b1;
                            end
                        end
                    end
                    8'h08: weights_reg <= merge_bytes(weights_reg, write_data, write_strb);
                    8'h0C: input_reg <= merge_bytes(input_reg, write_data, write_strb);
                    8'h10: mode_reg <= merge_bytes(mode_reg, write_data, write_strb);
                    8'h14: out_mul_reg <= merge_bytes(out_mul_reg, write_data, write_strb);
                    8'h18: out_shift_reg <= merge_bytes(out_shift_reg, write_data, write_strb);
                    8'h1C: par_reg[0] <= merge_bytes(par_reg[0], write_data, write_strb);
                    8'h20: par_reg[1] <= merge_bytes(par_reg[1], write_data, write_strb);
                    8'h24: par_reg[2] <= merge_bytes(par_reg[2], write_data, write_strb);
                    8'h28: par_reg[3] <= merge_bytes(par_reg[3], write_data, write_strb);
                    default: ;
                endcase

                aw_pending <= 1'b0;
                w_pending <= 1'b0;
                s_axi_bvalid <= 1'b1;
            end

            if (s_axi_bvalid && s_axi_bready)
                s_axi_bvalid <= 1'b0;

            if (s_axi_arvalid && s_axi_arready) begin
                s_axi_rvalid <= 1'b1;

                case (s_axi_araddr[7:0])
                    8'h04: s_axi_rdata <= {30'b0, result_busy, result_done};
                    8'h08: s_axi_rdata <= weights_reg;
                    8'h0C: s_axi_rdata <= input_reg;
                    8'h10: s_axi_rdata <= mode_reg;
                    8'h14: s_axi_rdata <= out_mul_reg;
                    8'h18: s_axi_rdata <= out_shift_reg;
                    8'h1C: s_axi_rdata <= par_reg[0];
                    8'h20: s_axi_rdata <= par_reg[1];
                    8'h24: s_axi_rdata <= par_reg[2];
                    8'h28: s_axi_rdata <= par_reg[3];
                    8'h2C: s_axi_rdata <= result_done ? result_reg : neural_result;
                    default: s_axi_rdata <= 32'h00000000;
                endcase
            end

            if (s_axi_rvalid && s_axi_rready)
                s_axi_rvalid <= 1'b0;
        end
    end

endmodule
